package com.example.workercards;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BackupHelper {

    public static final String APP_FOLDER = "مخزون كروت الكامل";
    private static final String PREFS = "worker_cards_data_v12";
    private static final String DATA_KEY = "data";
    private static final String CHANNEL_ID = "backup_success";

    public static void createBackup(Context context) {
        try {
            SharedPreferences prefs =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            String json = prefs.getString(DATA_KEY, "");

            if (json == null || json.trim().isEmpty()) {
                showResultNotification(
                        context,
                        false,
                        "لا توجد بيانات محفوظة لإنشاء النسخة الاحتياطية."
                );
                return;
            }

            String stamp = new SimpleDateFormat(
                    "yyyy-MM-dd_HH-mm-ss",
                    Locale.US
            ).format(new Date());

            String fileName = "backup_" + stamp + ".json";

            File folder = getBackupFolder(context);

            if (folder == null) {
                showResultNotification(
                        context,
                        false,
                        "تعذر الوصول إلى الذاكرة الداخلية لإنشاء مجلد النسخ."
                );
                return;
            }

            if (!folder.exists() && !folder.mkdirs()) {
                showResultNotification(
                        context,
                        false,
                        "تعذر إنشاء مجلد: " + folder.getAbsolutePath()
                );
                return;
            }

            File backup = new File(folder, fileName);

            try (FileOutputStream out = new FileOutputStream(backup)) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

            if (!backup.exists() || backup.length() == 0) {
                showResultNotification(
                        context,
                        false,
                        "تم تشغيل النسخ لكن لم يتم إنشاء الملف."
                );
                return;
            }

            deleteOldBackups(folder);

            showResultNotification(
                    context,
                    true,
                    "تم حفظ النسخة الاحتياطية في:\n"
                            + folder.getAbsolutePath()
                            + "\n"
                            + fileName
            );

        } catch (Exception e) {
            showResultNotification(
                    context,
                    false,
                    "فشل النسخ الاحتياطي: "
                            + (e.getMessage() == null ? "خطأ غير معروف" : e.getMessage())
            );
        }
    }

    private static File getBackupFolder(Context context) {
        // Android 11+ يحتاج صلاحية إدارة الملفات إذا أردنا إنشاء مجلد
        // مباشر في جذر الذاكرة المشتركة.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                return null;
            }
        }

        File root = Environment.getExternalStorageDirectory();
        return new File(root, APP_FOLDER);
    }

    public static boolean hasRootStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }
        return true;
    }

    public static void openStorageAccessSettings(Context context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + context.getPackageName())
                );
                context.startActivity(intent);
            }
        } catch (Exception e) {
            try {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                );
                context.startActivity(intent);
            } catch (Exception ignored) {
            }
        }
    }

    private static void deleteOldBackups(File folder) {
        File[] backups = folder.listFiles(
                (dir, name) ->
                        name.startsWith("backup_")
                                && name.endsWith(".json")
        );

        if (backups == null || backups.length <= 30) return;

        java.util.Arrays.sort(
                backups,
                (a, b) -> Long.compare(a.lastModified(), b.lastModified())
        );

        for (int i = 0; i < backups.length - 30; i++) {
            backups[i].delete();
        }
    }

    private static void showResultNotification(
            Context context,
            boolean success,
            String message
    ) {
        try {
            NotificationManager nm =
                    (NotificationManager) context.getSystemService(
                            Context.NOTIFICATION_SERVICE
                    );

            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel =
                        new NotificationChannel(
                                CHANNEL_ID,
                                "النسخ الاحتياطي",
                                success
                                        ? NotificationManager.IMPORTANCE_DEFAULT
                                        : NotificationManager.IMPORTANCE_HIGH
                        );

                channel.setDescription(
                        "نتيجة النسخ الاحتياطي التلقائي"
                );

                nm.createNotificationChannel(channel);
            }

            Notification.Builder builder;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, CHANNEL_ID);
            } else {
                builder = new Notification.Builder(context);
            }

            builder.setSmallIcon(
                            success
                                    ? android.R.drawable.ic_menu_save
                                    : android.R.drawable.ic_dialog_alert
                    )
                    .setContentTitle(
                            success
                                    ? "✅ تم إنشاء النسخة الاحتياطية"
                                    : "❌ فشل النسخ الاحتياطي"
                    )
                    .setContentText(message)
                    .setStyle(
                            new Notification.BigTextStyle().bigText(message)
                    )
                    .setAutoCancel(true)
                    .setPriority(
                            success
                                    ? Notification.PRIORITY_DEFAULT
                                    : Notification.PRIORITY_HIGH
                    );

            nm.notify(
                    (int) (System.currentTimeMillis() & 0x7fffffff),
                    builder.build()
            );

        } catch (Exception ignored) {
        }
    }
}
