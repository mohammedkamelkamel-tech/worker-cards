package com.example.workercards;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.concurrent.Executor;

public class AuthActivity extends Activity {
    private static final String PREFS = "app_security";
    private static final String KEY_HASH = "password_hash";
    private static final String KEY_SALT = "password_salt";
    private static final String KEY_BIOMETRIC = "biometric_enabled";

    private SharedPreferences prefs;
    private EditText password;
    private TextView message;
    private Executor executor;
    private BiometricPrompt biometricPrompt;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        executor = ContextCompat.getMainExecutor(this);

        if (!hasPassword()) {
            showCreatePassword();
        } else {
            showLogin();
        }
    }

    private boolean hasPassword() {
        return prefs.contains(KEY_HASH) && prefs.contains(KEY_SALT);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(17); return b;
    }

    private LinearLayout base() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(20), dp(28), dp(20));
        return root;
    }

    private void showCreatePassword() {
        LinearLayout root = base();
        root.addView(text("🔐 مخزون كروت الكامل", 26));
        root.addView(text("إنشاء كلمة مرور للحماية", 19));
        password = new EditText(this);
        password.setHint("كلمة المرور");
        password.setGravity(Gravity.CENTER);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(password, new LinearLayout.LayoutParams(-1, dp(60)));

        EditText confirm = new EditText(this);
        confirm.setHint("تأكيد كلمة المرور"); confirm.setGravity(Gravity.CENTER);
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(confirm, new LinearLayout.LayoutParams(-1, dp(60)));
        message = text("", 15); root.addView(message);

        Button save = button("حفظ كلمة المرور والمتابعة"); root.addView(save);
        save.setOnClickListener(v -> {
            String p = password.getText().toString();
            String c = confirm.getText().toString();
            if (p.length() < 4) { message.setText("كلمة المرور يجب أن تكون 4 أحرف/أرقام على الأقل"); return; }
            if (!p.equals(c)) { message.setText("كلمتا المرور غير متطابقتين"); return; }
            byte[] salt = new byte[16]; new SecureRandom().nextBytes(salt);
            prefs.edit().putString(KEY_SALT, hex(salt)).putString(KEY_HASH, hash(p, salt)).putBoolean(KEY_BIOMETRIC, true).apply();
            showLogin();
        });
        setContentView(root);
    }

    private void showLogin() {
        LinearLayout root = base();
        root.addView(text("🔐 مخزون كروت الكامل", 26));
        root.addView(text("أثبت هويتك للدخول", 19));
        message = text("جارٍ تشغيل البصمة...", 15); root.addView(message);

        password = new EditText(this);
        password.setHint("كلمة المرور"); password.setGravity(Gravity.CENTER);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setVisibility(View.GONE);
        root.addView(password, new LinearLayout.LayoutParams(-1, dp(60)));

        Button enter = button("دخول بكلمة المرور"); enter.setVisibility(View.GONE); root.addView(enter);
        enter.setOnClickListener(v -> checkPassword());

        setContentView(root);

        if (prefs.getBoolean(KEY_BIOMETRIC, true)) {
            startBiometric();
        } else {
            showPasswordOnly();
        }
    }

    private void showPasswordOnly() {
        message.setText("أدخل كلمة المرور");
        password.setVisibility(View.VISIBLE);
        View parent = (View) password.getParent();
        if (parent instanceof LinearLayout) {
            LinearLayout l = (LinearLayout) parent;
            if (l.getChildCount() > 0) l.getChildAt(l.getChildCount()-1).setVisibility(View.VISIBLE);
        }
    }

    private void startBiometric() {
        BiometricManager bm = BiometricManager.from(this);
        int can = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (can != BiometricManager.BIOMETRIC_SUCCESS) { showPasswordOnly(); return; }

        biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { runOnUiThread(() -> openApp()); }
            @Override public void onAuthenticationFailed() { runOnUiThread(() -> { message.setText("لم يتم التعرف على البصمة. أدخل كلمة المرور."); if (biometricPrompt != null) biometricPrompt.cancelAuthentication(); showPasswordOnly(); }); }
            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                runOnUiThread(() -> { message.setText("تعذر استخدام البصمة: " + errString); showPasswordOnly(); });
            }
        });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("مخزون كروت الكامل")
                .setSubtitle("ضع إصبعك للدخول")
                .setDescription("إذا لم تتعرف البصمة، استخدم كلمة المرور")
                .setNegativeButtonText("استخدام كلمة المرور")
                .build();
        biometricPrompt.authenticate(info);
    }

    private void checkPassword() {
        String p = password.getText().toString();
        try {
            byte[] salt = fromHex(prefs.getString(KEY_SALT, ""));
            String expected = prefs.getString(KEY_HASH, "");
            if (MessageDigest.isEqual(hash(p, salt).getBytes(StandardCharsets.UTF_8), expected.getBytes(StandardCharsets.UTF_8))) openApp();
            else message.setText("❌ كلمة المرور غير صحيحة");
        } catch (Exception e) { message.setText("تعذر التحقق من كلمة المرور"); }
    }

    private String hash(String value, byte[] salt) {
        try {
            java.security.spec.PBEKeySpec spec = new java.security.spec.PBEKeySpec(value.toCharArray(), salt, 120000, 256);
            byte[] out = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return hex(out);
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    private String hex(byte[] b) { StringBuilder s=new StringBuilder(); for(byte x:b)s.append(String.format("%02x",x)); return s.toString(); }
    private byte[] fromHex(String s) { byte[] b=new byte[s.length()/2]; for(int i=0;i<b.length;i++) b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16); return b; }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i); finish();
    }
}
