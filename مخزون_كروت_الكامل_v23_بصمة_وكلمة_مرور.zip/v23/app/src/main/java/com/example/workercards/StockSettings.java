package com.example.workercards;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;

public class StockSettings {

    public static final String PREFS = "stock_settings";
    public static final String BACKUP_ENABLED = "backup_enabled";
    public static final String BACKUP_HOUR = "backup_hour";
    public static final String BACKUP_MINUTE = "backup_minute";
    public static final String DEFAULT_THRESHOLD = "default_threshold";

    public static void scheduleBackup(Context context) {
        android.content.SharedPreferences p =
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        if (!p.getBoolean(BACKUP_ENABLED, true)) {
            cancelBackup(context);
            return;
        }

        int hour = p.getInt(BACKUP_HOUR, 4);
        int minute = p.getInt(BACKUP_MINUTE, 0);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(context, DailyBackupReceiver.class);
        i.setAction("com.example.workercards.DAILY_BACKUP");

        PendingIntent pi = PendingIntent.getBroadcast(
                context, 4040, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);

        if (c.getTimeInMillis() <= System.currentTimeMillis()) {
            c.add(Calendar.DAY_OF_YEAR, 1);
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // لا يتطلب صلاحية المنبهات الدقيقة؛ قد يعمل خلال دقائق من الوقت المحدد.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }
    }

    public static void cancelBackup(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(context, DailyBackupReceiver.class);
        i.setAction("com.example.workercards.DAILY_BACKUP");
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 4040, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }

    public static void ensureNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(
                        "stock_alerts",
                        "تنبيهات مخزون الكروت",
                        NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("تنبيهات قرب نفاد أو نفاد مخزون الكروت");
                nm.createNotificationChannel(ch);
            }
        }
    }
}
