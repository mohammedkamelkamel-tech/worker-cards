package com.example.workercards;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "worker_cards_native";
    private static final String DATA_KEY = "data";
    private final int[] DENOMS = {100, 200, 250, 500};

    private JSONObject data;
    private LinearLayout root, workersContainer;
    private EditText workerName, message;
    private TextView result;
    private final int blue = Color.rgb(25,118,210);
    private final int green = Color.rgb(22,131,58);
    private final int red = Color.rgb(198,40,40);
    private final int gray = Color.rgb(95,95,95);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(blue);
        loadData();
        buildUi();
        renderAll();
    }

    private void loadData() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = p.getString(DATA_KEY, null);
        try {
            data = raw == null ? defaultData() : new JSONObject(raw);
            if (!data.has("stock")) data.put("stock", new JSONObject());
            if (!data.has("workers")) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = defaultData();
        }
    }

    private JSONObject defaultData() {
        JSONObject d = new JSONObject();
        try {
            JSONObject s = new JSONObject();
            s.put("100", 2000); s.put("200", 2000); s.put("250", 2000); s.put("500", 1000);
            JSONObject w = new JSONObject();
            JSONObject mw = new JSONObject();
            mw.put("100",432); mw.put("200",1000); mw.put("250",1000); mw.put("500",100);
            w.put("محمد ثابت", mw);
            d.put("stock", s);
            d.put("workers", w);
        } catch (Exception ignored) {}
        return d;
    }

    private void saveData() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(DATA_KEY, data.toString()).apply();
    }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(18, 14, 18, 14);
        t.setIncludeFontPadding(true);
        return t;
    }

    private EditText edit(String value, String hint, int inputType) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(18);
        e.setInputType(inputType);
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        e.setPadding(18, 10, 18, 10);
        e.setIncludeFontPadding(true);
        e.setBackgroundColor(Color.WHITE);
        return e;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundColor(color);
        b.setMinHeight(60);
        return b;
    }

    private LinearLayout section(String title) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 12, 14, 12);
        box.setBackgroundColor(Color.WHITE);

        TextView h = tv(title, 25, Color.rgb(35,35,35), true);
        h.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        box.addView(h, new LinearLayout.LayoutParams(-1, 68));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(8, 10, 8, 0);
        root.addView(box, lp);
        return box;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, 8, 0, 28);
        root.setBackgroundColor(Color.rgb(245,247,250));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void renderAll() {
        root.removeAllViews();

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(18, 18, 18, 18);
        header.setBackgroundColor(Color.WHITE);

        TextView h = tv("📦 إدارة كروت العامل", 29, Color.rgb(25,25,25), true);
        h.setGravity(Gravity.CENTER);
        header.addView(h, new LinearLayout.LayoutParams(-1, 70));

        TextView sub = tv("تطبيق Android أصلي لإدارة المخزون والعمال والخصم", 16, gray, false);
        sub.setGravity(Gravity.CENTER);
        header.addView(sub, new LinearLayout.LayoutParams(-1, 58));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        renderStock();
        renderWorkers();
        renderMessage();
        renderResult();
    }

    private void renderStock() {
        LinearLayout box = section("المخزون العام");
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        for (int row = 0; row < 2; row++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            for (int col = 0; col < 2; col++) {
                int d = DENOMS[row * 2 + col];
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);

                TextView label = tv(String.valueOf(d), 18, Color.DKGRAY, true);
                label.setGravity(Gravity.CENTER);
                EditText e = edit(String.valueOf(getStock(d)), "الكمية", InputType.TYPE_CLASS_NUMBER);
                e.setTag("stock_" + d);

                cell.addView(label, new LinearLayout.LayoutParams(-1, 52));
                cell.addView(e, new LinearLayout.LayoutParams(-1, 72));

                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
                cp.setMargins(6, 4, 6, 4);
                r.addView(cell, cp);
            }
            grid.addView(r);
        }
        box.addView(grid);

        Button save = button("حفظ المخزون", green);
        save.setOnClickListener(v -> saveStock());
        box.addView(save, new LinearLayout.LayoutParams(-1, 64));
    }

    private int getStock(int d) {
        try {
            return data.getJSONObject("stock").optInt(String.valueOf(d), 0);
        } catch(Exception e) {
            return 0;
        }
    }

    private void saveStock() {
        try {
            for (int d : DENOMS) {
                EditText e = root.findViewWithTag("stock_" + d);
                String text = e.getText().toString().trim();
                if (text.isEmpty()) throw new Exception();
                data.getJSONObject("stock").put(String.valueOf(d),
                        Math.max(0, Integer.parseInt(text)));
            }
            saveData();
            show("تم حفظ المخزون.");
        } catch (Exception ex) {
            show("تأكد من إدخال أرقام صحيحة.");
        }
    }

    private void renderWorkers() {
        LinearLayout box = section("العمال والكروت الخاصة بهم");

        box.addView(tv("اسم العامل", 17, gray, true),
                new LinearLayout.LayoutParams(-1, 52));

        workerName = edit("", "اكتب اسم العامل الجديد", InputType.TYPE_CLASS_TEXT);
        box.addView(workerName, new LinearLayout.LayoutParams(-1, 70));

        Button add = button("➕ إضافة عامل جديد", blue);
        add.setOnClickListener(v -> addWorker());
        box.addView(add, new LinearLayout.LayoutParams(-1, 64));

        TextView hint = tv(
                "بعد إضافة العامل، اكتب عدد الكروت الخاصة به لكل فئة ثم اضغط «حفظ كروت العامل».",
                15, gray, false);
        hint.setGravity(Gravity.RIGHT);
        box.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        box.addView(workersContainer);
        renderWorkerList();
    }

    private void addWorker() {
        String name = workerName.getText().toString().trim();
        if (name.isEmpty()) {
            show("اكتب اسم العامل أولًا.");
            return;
        }

        try {
            JSONObject workers = data.getJSONObject("workers");
            if (workers.has(name)) {
                show("العامل موجود بالفعل، تم اختياره.");
            } else {
                JSONObject w = new JSONObject();
                for (int d : DENOMS) w.put(String.valueOf(d), 0);
                workers.put(name, w);
                saveData();
                show("تمت إضافة العامل: " + name);
            }
            workerName.setText(name);
            renderWorkerList();
        } catch(Exception e) {
            show("تعذر إضافة العامل.");
        }
    }

    private void renderWorkerList() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();

        try {
            JSONObject workers = data.getJSONObject("workers");
            Iterator<String> it = workers.keys();

            while (it.hasNext()) {
                String name = it.next();
                JSONObject w = workers.getJSONObject(name);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(12, 14, 12, 14);
                card.setBackgroundColor(Color.rgb(250,250,250));

                TextView n = tv(name, 21, Color.rgb(30,30,30), true);
                n.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
                card.addView(n, new LinearLayout.LayoutParams(-1, 60));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

                EditText[] fields = new EditText[4];
                for (int i = 0; i < DENOMS.length; i++) {
                    int d = DENOMS[i];
                    LinearLayout cell = new LinearLayout(this);
                    cell.setOrientation(LinearLayout.VERTICAL);

                    TextView lab = tv(String.valueOf(d), 16, Color.DKGRAY, true);
                    lab.setGravity(Gravity.CENTER);
                    EditText e = edit(String.valueOf(w.optInt(String.valueOf(d), 0)),
                            "الكروت", InputType.TYPE_CLASS_NUMBER);
                    e.setGravity(Gravity.CENTER);
                    e.setTag("worker_" + safeTag(name) + "_" + d);
                    fields[i] = e;

                    cell.addView(lab, new LinearLayout.LayoutParams(-1, 42));
                    cell.addView(e, new LinearLayout.LayoutParams(-1, 68));

                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
                    cp.setMargins(3, 3, 3, 3);
                    row.addView(cell, cp);
                }
                card.addView(row);

                Button saveCards = button("💾 حفظ كروت العامل", green);
                saveCards.setOnClickListener(v -> saveWorkerCards(name, fields));
                card.addView(saveCards, new LinearLayout.LayoutParams(-1, 62));

                Button use = button("استخدام هذا العامل", blue);
                use.setOnClickListener(v -> {
                    workerName.setText(name);
                    if (message != null) message.requestFocus();
                    show("تم اختيار العامل: " + name);
                });
                card.addView(use, new LinearLayout.LayoutParams(-1, 62));

                Button del = button("حذف العامل", red);
                del.setOnClickListener(v -> deleteWorker(name));
                card.addView(del, new LinearLayout.LayoutParams(-1, 62));

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, 12, 0, 0);
                workersContainer.addView(card, lp);
            }
        } catch(Exception ignored) {}
    }

    private String safeTag(String name) {
        return Integer.toHexString(name.hashCode());
    }

    private void saveWorkerCards(String name, EditText[] fields) {
        try {
            JSONObject w = data.getJSONObject("workers").getJSONObject(name);

            for (int i = 0; i < DENOMS.length; i++) {
                String s = fields[i].getText().toString().trim();
                if (s.isEmpty()) throw new Exception();
                w.put(String.valueOf(DENOMS[i]),
                        Math.max(0, Integer.parseInt(s)));
            }

            saveData();
            renderWorkerList();
            show("تم حفظ كروت العامل: " + name);
        } catch(Exception e) {
            show("تأكد من إدخال أعداد صحيحة للكروت.");
        }
    }

    private void deleteWorker(String name) {
        try {
            data.getJSONObject("workers").remove(name);
            saveData();
            if (workerName != null && workerName.getText().toString().trim().equals(name))
                workerName.setText("");
            renderWorkerList();
            show("تم حذف العامل: " + name);
        } catch(Exception e) {
            show("تعذر حذف العامل.");
        }
    }

    private void renderMessage() {
        LinearLayout box = section("رسالة العامل");

        TextView info = tv(
                "الصق رسالة العامل كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500",
                16, gray, false);
        box.addView(info);

        message = new EditText(this);
        message.setHint("مثال:\n1-2-3-4\n2-1-0-3");
        message.setTextSize(17);
        message.setGravity(Gravity.TOP | Gravity.RIGHT);
        message.setMinLines(8);
        message.setIncludeFontPadding(true);
        message.setPadding(16, 14, 16, 14);
        message.setInputType(InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(message, new LinearLayout.LayoutParams(-1, 250));

        Button calc = button("احسب وخصم", green);
        calc.setOnClickListener(v -> calculate());
        box.addView(calc, new LinearLayout.LayoutParams(-1, 64));
    }

    private void renderResult() {
        LinearLayout box = section("النتيجة");
        result = tv("—", 17, Color.rgb(40,40,40), false);
        result.setGravity(Gravity.RIGHT | Gravity.TOP);
        result.setPadding(16, 16, 16, 16);
        box.addView(result, new LinearLayout.LayoutParams(-1, -2));
    }

    private void calculate() {
        String name = workerName == null ? "" : workerName.getText().toString().trim();
        String text = message == null ? "" : message.getText().toString();

        if (name.isEmpty()) {
            show("اختر العامل أولًا.");
            return;
        }

        try {
            JSONObject workers = data.getJSONObject("workers");
            if (!workers.has(name)) {
                show("العامل غير مضاف.");
                return;
            }

            int[] used = {0,0,0,0};
            String[] lines = text.split("\\r?\\n");
            int count = 0;

            Pattern p = Pattern.compile(
                    "(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)");

            for (String line : lines) {
                Matcher m = p.matcher(line);
                while (m.find()) {
                    for (int i = 0; i < 4; i++)
                        used[i] += Integer.parseInt(m.group(i + 1));
                    count++;
                }
            }

            if (count == 0) {
                show("لم أجد سطرًا بصيغة 100-200-250-500.");
                return;
            }

            JSONObject w = workers.getJSONObject(name);
            JSONObject s = data.getJSONObject("stock");

            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                int wb = w.optInt(k, 0);
                int sb = s.optInt(k, 0);

                if (used[i] > wb) {
                    show("رصيد العامل غير كافٍ في فئة " + k +
                            ". المطلوب " + used[i] + " والمتوفر " + wb +
                            "\nلم يتم الخصم.");
                    return;
                }

                if (used[i] > sb) {
                    show("المخزون العام غير كافٍ في فئة " + k +
                            ". المطلوب " + used[i] + " والمتوفر " + sb +
                            "\nلم يتم الخصم.");
                    return;
                }
            }

            StringBuilder out = new StringBuilder(
                    "تم الخصم بنجاح من العامل: ").append(name).append("\n\n");

            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                int nw = w.optInt(k,0) - used[i];
                int ns = s.optInt(k,0) - used[i];
                w.put(k, nw);
                s.put(k, ns);

                out.append(k)
                        .append(" : المطلوب ").append(used[i])
                        .append(" | رصيد العامل ").append(nw)
                        .append(" | المخزون ").append(ns)
                        .append("\n");
            }

            saveData();
            renderAll();
            show(out.toString());

        } catch(Exception e) {
            show("حدث خطأ أثناء الحساب.");
        }
    }

    private void show(String text) {
        if (result != null) result.setText(text);
        Toast.makeText(this, text.split("\\n")[0], Toast.LENGTH_SHORT).show();
    }
}
