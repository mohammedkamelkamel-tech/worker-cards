package com.example.workercards;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DailyBackupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("com.example.workercards.DAILY_BACKUP".equals(intent.getAction())) {
            android.content.SharedPreferences settings = context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE);
            if (settings.getBoolean(StockSettings.BACKUP_ENABLED, true)
                    && settings.getBoolean("internal_backups_enabled", false)) {
                BackupHelper.createBackup(context);
            }
        }
        StockSettings.scheduleBackup(context);
    }
}
