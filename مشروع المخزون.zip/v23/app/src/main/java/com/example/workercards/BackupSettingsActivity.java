package com.example.workercards;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONObject;

public class BackupSettingsActivity extends Activity {

    private CheckBox enabled;
    private TextView timeText;
    private final EditText[] thresholds = new EditText[4];
    private final int[] denominations = {100, 200, 250, 500};
    private final Map<String, EditText> workerThresholdInputs = new LinkedHashMap<>();

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private android.graphics.drawable.GradientDrawable rounded(int color, int stroke) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(16));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout section() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setBackground(rounded(0xFFFFFFFF, 0xFFE2E8F0));
        if (android.os.Build.VERSION.SDK_INT >= 21) card.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(7), 0, dp(7)); card.setLayoutParams(lp);
        return card;
    }

    private TextView heading(String text) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(18);
        v.setTextColor(0xFF123047); v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        v.setGravity(Gravity.RIGHT); v.setPadding(0, 0, 0, dp(10)); return v;
    }

    private void styleField(EditText field) {
        field.setTextSize(16); field.setSingleLine(true); field.setPadding(dp(12), dp(8), dp(12), dp(8));
        field.setTextColor(0xFF0F172A); field.setHintTextColor(0xFF94A3B8);
        field.setBackground(rounded(0xFFF8FAFC, 0xFFCBD5E1));
    }

    private void styleButton(Button button, int color) {
        button.setAllCaps(false); button.setTextSize(15); button.setTextColor(0xFFFFFFFF);
        button.setMinHeight(dp(48)); button.setPadding(dp(14), dp(10), dp(14), dp(10));
        android.graphics.drawable.GradientDrawable bg = rounded(color, 0);
        button.setBackground(bg);
    }

    @Override protected void onResume() {
        super.onResume();
        android.content.SharedPreferences p = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        if (p.getBoolean("internal_backups_enabled", false)
                && p.getBoolean("internal_backup_permission_pending", false)
                && BackupHelper.hasRootStorageAccess()) {
            p.edit().putBoolean("internal_backup_permission_pending", false).apply();
            BackupHelper.createBackup(this);
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        android.content.SharedPreferences p =
                getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);

        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(0xFFF1F5F9);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(18), dp(16), dp(24));
        box.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("إعدادات النسخ والتنبيهات");
        title.setTextSize(25);
        title.setTextColor(0xFF123047);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(18));
        box.addView(title);

        TextView location = new TextView(this);
        location.setText("📁 مكان النسخ: الذاكرة الداخلية / مخزون كروت الكامل");
        location.setTextSize(14); location.setTextColor(0xFF475569);
        location.setPadding(dp(12), dp(12), dp(12), dp(12)); location.setBackground(rounded(0xFFEAF4FF, 0));
        box.addView(location);

        TextView accessStatus = new TextView(this);
        accessStatus.setText(
                BackupHelper.hasRootStorageAccess()
                        ? "✅ الوصول إلى الذاكرة الداخلية مفعّل"
                        : "⚠️ يجب السماح للتطبيق بالوصول إلى الذاكرة الداخلية حتى يتم إنشاء المجلد مباشرة."
        );
        accessStatus.setTextSize(14); accessStatus.setTextColor(0xFF475569);
        accessStatus.setPadding(dp(4), dp(8), dp(4), dp(8));
        box.addView(accessStatus);

        CheckBox internalBackups = new CheckBox(this);
        internalBackups.setText("السماح بحفظ النسخ في الذاكرة الداخلية");
        internalBackups.setChecked(p.getBoolean("internal_backups_enabled", false));
        internalBackups.setOnCheckedChangeListener((button, checked) -> {
            p.edit().putBoolean("internal_backups_enabled", checked).apply();
            if (checked && !BackupHelper.hasRootStorageAccess()) {
                p.edit().putBoolean("internal_backup_permission_pending", true).apply();
                BackupHelper.openStorageAccessSettings(this);
            } else if (checked) {
                p.edit().putBoolean("internal_backup_permission_pending", false).apply();
                BackupHelper.createBackup(this);
            } else {
                p.edit().putBoolean("internal_backup_permission_pending", false).apply();
            }
            StockSettings.scheduleBackup(this);
        });
        internalBackups.setTextSize(15); internalBackups.setTextColor(0xFF123047); internalBackups.setPadding(0, dp(8), 0, dp(8));
        box.addView(internalBackups);

        Button testBackup = new Button(this);
        testBackup.setText("🧪 اختبار النسخ الآن");
        testBackup.setOnClickListener(v -> {
            BackupHelper.createBackup(this);
        });
        styleButton(testBackup, 0xFF2563EB); box.addView(testBackup);

        enabled = new CheckBox(this);
        enabled.setText("تفعيل النسخ الاحتياطي التلقائي يوميًا");
        enabled.setChecked(p.getBoolean(StockSettings.BACKUP_ENABLED, true));
        enabled.setTextSize(15); enabled.setTextColor(0xFF123047); enabled.setPadding(0, dp(8), 0, dp(8)); box.addView(enabled);

        timeText = new TextView(this);
        timeText.setText("وقت النسخ: " + String.format("%02d:%02d",
                p.getInt(StockSettings.BACKUP_HOUR,4),
                p.getInt(StockSettings.BACKUP_MINUTE,0)));
        timeText.setTextSize(16); timeText.setTextColor(0xFF334155);
        timeText.setPadding(dp(12),dp(12),dp(12),dp(12)); timeText.setBackground(rounded(0xFFF8FAFC, 0xFFE2E8F0));
        box.addView(timeText);

        Button choose = new Button(this);
        choose.setText("تحديد وقت النسخ");
        choose.setOnClickListener(v -> {
            int h = p.getInt(StockSettings.BACKUP_HOUR,4);
            int m = p.getInt(StockSettings.BACKUP_MINUTE,0);
            new TimePickerDialog(this, (view, hour, minute) -> {
                p.edit().putInt(StockSettings.BACKUP_HOUR,hour)
                        .putInt(StockSettings.BACKUP_MINUTE,minute).apply();
                timeText.setText("وقت النسخ: " + String.format("%02d:%02d",hour,minute));
                StockSettings.scheduleBackup(this);
            }, h, m, true).show();
        });
        styleButton(choose, 0xFF0F766E); box.addView(choose);

        TextView t = new TextView(this);
        t.setText("حدود تنبيه المخزون لكل فئة (تنبيه عند الحد أو أقل):");
        t.setTextSize(18); t.setTextColor(0xFF123047); t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(18), 0, dp(8));
        box.addView(t);
        for (int i=0; i<denominations.length; i++) {
            TextView label = new TextView(this);
            label.setText("فئة " + denominations[i]);
            label.setTextSize(14); label.setTextColor(0xFF475569); label.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
            label.setPadding(0, dp(8), 0, dp(3)); box.addView(label);
            thresholds[i] = new EditText(this);
            thresholds[i].setInputType(2); styleField(thresholds[i]);
            thresholds[i].setHint("الحد الأدنى لهذه الفئة");
            thresholds[i].setText(String.valueOf(p.getInt("threshold_" + denominations[i], p.getInt(StockSettings.DEFAULT_THRESHOLD, 10))));
            box.addView(thresholds[i]);
        }

        TextView workerTitle = new TextView(this);
        workerTitle.setText("حدود التنبيه لكل عامل بشكل مستقل");
        workerTitle.setTextSize(19); workerTitle.setTextColor(0xFF123047); workerTitle.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); workerTitle.setPadding(0, dp(22), 0, dp(8));
        box.addView(workerTitle);
        try {
            android.content.SharedPreferences dataPrefs = getSharedPreferences("worker_cards_pro_v24_data", MODE_PRIVATE);
            JSONObject appData = new JSONObject(dataPrefs.getString("data", "{}"));
            JSONObject workers = appData.optJSONObject("workers");
            if (workers == null || workers.length() == 0) {
                TextView empty = new TextView(this); empty.setText("أضف العمال أولًا لتحديد حدود تنبيه خاصة بكل عامل."); box.addView(empty);
            } else {
                java.util.Iterator<String> names = workers.keys();
                while (names.hasNext()) {
                    String workerName = names.next(); JSONObject worker = workers.optJSONObject(workerName);
                    LinearLayout workerCard = section();
                    TextView workerLabel = heading("👤 " + workerName);
                    workerCard.addView(workerLabel);
                    TextView workerHint = new TextView(this); workerHint.setText("حد التنبيه لكل فئة — مستقل عن بقية العمال");
                    workerHint.setTextSize(12); workerHint.setTextColor(0xFF64748B); workerHint.setPadding(0, 0, 0, dp(8));
                    workerCard.addView(workerHint);
                    for (int denomination : denominations) {
                        TextView denominationLabel = new TextView(this); denominationLabel.setText("فئة " + denomination);
                        denominationLabel.setTextSize(13); denominationLabel.setTextColor(0xFF475569);
                        denominationLabel.setPadding(0, dp(5), 0, 0); workerCard.addView(denominationLabel);
                        EditText field = new EditText(this); field.setInputType(2); styleField(field);
                        field.setHint("حد التنبيه لفئة " + denomination);
                        field.setText(String.valueOf(worker == null ? p.getInt("threshold_" + denomination, 10) : worker.optInt("threshold_" + denomination, p.getInt("threshold_" + denomination, 10))));
                        workerCard.addView(field); workerThresholdInputs.put(workerName + "|" + denomination, field);
                    }
                    box.addView(workerCard);
                }
            }
        } catch (Exception ex) {
            TextView error = new TextView(this); error.setText("تعذر قراءة قائمة العمال؛ أعد فتح الصفحة بعد التأكد من حفظ البيانات."); box.addView(error);
        }

        Button save = new Button(this);
        save.setText("حفظ الإعدادات");
        save.setTextSize(17);
        save.setTextColor(android.graphics.Color.WHITE);
        save.setAllCaps(false);
        save.setMinHeight(dp(54));
        styleButton(save, 0xFF0F766E);
        save.setOnClickListener(v -> {
            int[] globalLimits = new int[denominations.length];
            Map<String, Integer> workerLimits = new LinkedHashMap<>();
            android.content.SharedPreferences dataPrefs = getSharedPreferences("worker_cards_pro_v24_data", MODE_PRIVATE);
            JSONObject appData;
            JSONObject workers;
            try {
                for (int i = 0; i < denominations.length; i++) {
                    String raw = thresholds[i].getText().toString().trim();
                    globalLimits[i] = raw.isEmpty() ? 0 : Integer.parseInt(raw);
                    if (globalLimits[i] < 0) { thresholds[i].setError("أدخل صفرًا أو رقمًا أكبر"); return; }
                }
                appData = new JSONObject(dataPrefs.getString("data", "{}"));
                workers = appData.optJSONObject("workers");
                for (Map.Entry<String, EditText> entry : workerThresholdInputs.entrySet()) {
                    String[] parts = entry.getKey().split("\\|", 2);
                    if (parts.length != 2 || workers == null || !workers.has(parts[0])) continue;
                    String raw = entry.getValue().getText().toString().trim();
                    int limit = raw.isEmpty() ? 0 : Integer.parseInt(raw);
                    if (limit < 0) { entry.getValue().setError("أدخل صفرًا أو رقمًا أكبر"); return; }
                    workerLimits.put(entry.getKey(), limit);
                }
                if (workers != null) {
                    for (Map.Entry<String, Integer> entry : workerLimits.entrySet()) {
                        String[] parts = entry.getKey().split("\\|", 2);
                        workers.getJSONObject(parts[0]).put("threshold_" + parts[1], entry.getValue());
                    }
                }
            } catch (Exception ex) {
                new android.app.AlertDialog.Builder(this).setTitle("تعذر حفظ الإعدادات")
                        .setMessage("تحقق من جميع حدود التنبيه. يجب إدخال أعداد صحيحة غير سالبة؛ لم تُحفظ أي تغييرات.")
                        .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
                return;
            }

            // Persist only after every field has passed validation to avoid partial settings updates.
            android.content.SharedPreferences.Editor editor = p.edit()
                    .putBoolean(StockSettings.BACKUP_ENABLED, enabled.isChecked());
            for (int i = 0; i < denominations.length; i++) editor.putInt("threshold_" + denominations[i], globalLimits[i]);
            boolean globalSaved = editor.commit();
            boolean workersSaved = workers == null || dataPrefs.edit().putString("data", appData.toString()).commit();
            if (!globalSaved || !workersSaved) {
                new android.app.AlertDialog.Builder(this).setTitle("تعذر حفظ الإعدادات")
                        .setMessage("لم يتم تأكيد حفظ كل الإعدادات. أعد المحاولة.")
                        .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
                return;
            }
            StockSettings.scheduleBackup(this);
            Toast.makeText(this, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        pageScroll.addView(box);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF123047);
            getWindow().setNavigationBarColor(0xFF0B1726);
        }
        setContentView(pageScroll);
    }
}
