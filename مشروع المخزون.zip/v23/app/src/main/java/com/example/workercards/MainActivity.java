package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.graphics.Paint;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import androidx.core.content.FileProvider;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS = "worker_cards_pro_v24_data";
    private static final int CREATE_BACKUP = 1001;
    private static final int RESTORE_BACKUP = 1002;
    private final int[] DENOMS = {100, 200, 250, 500};

    private SharedPreferences prefs;
    private JSONObject data;
    private String selectedWorker = "";
    private LinearLayout workersContainer;
    private EditText[] stockInputs = new EditText[4];
    private EditText messageInput;
    private TextView selectedText;
    private boolean reloadAfterSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StockSettings.ensureNotificationChannel(this);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
        }
        StockSettings.scheduleBackup(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadData();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!reloadAfterSettings || prefs == null) return;
        reloadAfterSettings = false;
        loadData();
        JSONObject stock = data.optJSONObject("stock");
        if (stock != null) {
            for (int i = 0; i < DENOMS.length; i++) {
                if (stockInputs[i] != null) {
                    stockInputs[i].setText(String.valueOf(stock.optInt(String.valueOf(DENOMS[i]), 0)));
                }
            }
        }
        renderWorkers();
        updateSelectedText();
    }

    private void loadData() {
        try {
            String saved = prefs.getString("data", "");
            if (saved.isEmpty()) {
                // Start with an empty inventory. Never seed a real stock ledger with demo balances.
                data = new JSONObject();
                JSONObject stock = new JSONObject();
                for (int denom : DENOMS) stock.put(String.valueOf(denom), 0);
                data.put("stock", stock);
                data.put("workers", new JSONObject());
            } else {
                data = new JSONObject(saved);
            }
            if (data.optJSONObject("stock") == null) data.put("stock", new JSONObject());
            if (data.optJSONObject("workers") == null) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = new JSONObject();
        }
    }

    private void saveData() {
        // Keep per-worker alert limits saved from BackupSettingsActivity even when
        // this Activity still has an older in-memory copy of the worker records.
        try {
            JSONObject latest = new JSONObject(prefs.getString("data", "{}"));
            JSONObject latestWorkers = latest.optJSONObject("workers");
            JSONObject currentWorkers = data.optJSONObject("workers");
            if (latestWorkers != null && currentWorkers != null) {
                java.util.Iterator<String> names = currentWorkers.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    JSONObject current = currentWorkers.optJSONObject(name);
                    JSONObject saved = latestWorkers.optJSONObject(name);
                    if (current == null || saved == null) continue;
                    for (int denom : DENOMS) {
                        String key = "threshold_" + denom;
                        // Thresholds are edited only in BackupSettingsActivity. The persisted
                        // value is authoritative so an older Activity instance cannot overwrite it.
                        if (saved.has(key)) current.put(key, saved.optInt(key, 10));
                        else current.remove(key);
                    }
                }
            }
        } catch (Exception ignored) { }
        // Any successful data mutation invalidates an older undo snapshot.
        // The operation that created a new snapshot stores it immediately after saveData().
        prefs.edit().putString("data", data.toString()).putBoolean("last_undo_available", false).apply();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(0xFF222222);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(50));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setBackground(rounded(color, 14, color, 1));
        if (android.os.Build.VERSION.SDK_INT >= 21) b.setElevation(dp(2));
        return b;
    }

    private EditText numberInput(int value) {
        EditText e = new EditText(this);
        e.setText(String.valueOf(value));
        e.setTextSize(18);
        e.setGravity(Gravity.CENTER);
        e.setInputType(2);
        e.setSingleLine(true);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        e.setBackground(rounded(Color.WHITE, 12, 0xFFD6DEE8, 1));
        e.setIncludeFontPadding(true);
        return e;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(14), dp(14), dp(14));
        l.setBackground(rounded(Color.WHITE, 18, 0xFFE1E7EF, 1));
        if (android.os.Build.VERSION.SDK_INT >= 21) l.setElevation(dp(2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(5), dp(6), dp(5), dp(6));
        l.setLayoutParams(p);
        return l;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return r;
    }

    private void addCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(v, p);
    }

    // Larger cell used for denomination label + amount so neither is clipped at the top.
    private void addCategoryCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(118), 1f);
        p.setMargins(dp(3), dp(7), dp(3), dp(7));
        row.addView(v, p);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF1F5F9);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), dp(10), dp(10), dp(18));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.workercards.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setContentDescription("شعار شبكة الكامل");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(190));
        logoParams.setMargins(dp(8), dp(4), dp(8), dp(0));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(logo, logoParams);

        TextView header = title("إدارة كروت العامل", 28);
        header.setTextColor(0xFF123047);
        header.setGravity(Gravity.CENTER);
        content.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView sub = new TextView(this);
        sub.setText("تطبيق Android أصلي لإدارة المخزون والعمال والخصم");
        sub.setTextSize(15); sub.setTextColor(0xFF64748B);
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,0,0,dp(10));
        content.addView(sub);

        // Backup
        LinearLayout backup = box();
        backup.addView(title("النسخ الاحتياطي والاستعادة", 25));
        TextView info = new TextView(this);
        info.setText("النسخ التلقائية تحفظ مباشرة في الذاكرة الداخلية داخل مجلد «مخزون كروت الكامل»، واسم الملف يحتوي على تاريخ ووقت النسخ.");
        info.setTextSize(14); info.setTextColor(0xFF64748B);
        info.setGravity(Gravity.RIGHT); info.setPadding(0,0,0,dp(6));
        backup.addView(info);
        LinearLayout br = row();
        Button export = button("تصدير نسخة", 0xFF16833A);
        Button restore = button("استعادة نسخة", 0xFF1976D2);
        addCell(br, export); addCell(br, restore);
        backup.addView(br);
        export.setOnClickListener(v -> exportBackup());
        restore.setOnClickListener(v -> restoreBackup());
        content.addView(backup);

        Button settingsButton = button("⚙ إعدادات النسخ والتنبيهات", 0xFF7B1FA2);
        settingsButton.setOnClickListener(v -> {
            reloadAfterSettings = true;
            startActivity(new Intent(this, BackupSettingsActivity.class));
        });
        content.addView(settingsButton);

        // General stock
        LinearLayout stockBox = box();
        stockBox.addView(title("المخزون العام", 27));
        LinearLayout r1 = row(), r2 = row();
        for (int i = 0; i < 4; i++) {
            int val = data.optJSONObject("stock").optInt(String.valueOf(DENOMS[i]), 0);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(18); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            lab.setGravity(Gravity.CENTER);
            stockInputs[i] = numberInput(val);
            cell.addView(lab);
            cell.addView(stockInputs[i], new LinearLayout.LayoutParams(-1, dp(58)));
            if (i < 2) addCategoryCell(r1, cell); else addCategoryCell(r2, cell);
        }
        stockBox.addView(r1); stockBox.addView(r2);
        Button saveStock = button("حفظ المخزون العام", 0xFF16833A);
        saveStock.setOnClickListener(v -> saveGeneralStock());
        stockBox.addView(saveStock);
        content.addView(stockBox);

        // Workers
        LinearLayout workerBox = box();
        workerBox.addView(title("العمال ومخزون الكروت الخاص بهم", 27));
        TextView wi = new TextView(this);
        wi.setText("كل عامل له مخزون مستقل من كروت 100 و200 و250 و500. يمكنك إضافة عامل وتعديل مخزونه وحفظه في أي وقت.");
        wi.setTextSize(14); wi.setTextColor(0xFF64748B); wi.setGravity(Gravity.RIGHT);
        workerBox.addView(wi);

        Button addWorker = button("＋ إضافة عامل جديد", 0xFF1976D2);
        addWorker.setOnClickListener(v -> showAddWorkerDialog());
        workerBox.addView(addWorker);

        selectedText = new TextView(this);
        selectedText.setTextSize(18); selectedText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selectedText.setTextColor(0xFF1976D2); selectedText.setPadding(dp(5),dp(10),dp(5),dp(5));
        selectedText.setGravity(Gravity.RIGHT);
        workerBox.addView(selectedText);

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        workersContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        workerBox.addView(workersContainer);
        content.addView(workerBox);

        // Message
        LinearLayout msgBox = box();
        msgBox.addView(title("رسالة العامل", 27));
        TextView hint = new TextView(this);
        hint.setText("اختر العامل، ثم الصق الرسالة كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500\n\nمثال:\n1-2-3-4\n2-1-0-3");
        hint.setTextSize(17); hint.setTextColor(0xFF666666); hint.setGravity(Gravity.RIGHT);
        msgBox.addView(hint);
        messageInput = new EditText(this);
        messageInput.setTextSize(18);
        messageInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        messageInput.setHint("الصق رسالة العامل هنا");
        messageInput.setMinLines(7);
        messageInput.setInputType(1 | 0x00008000);
        msgBox.addView(messageInput, new LinearLayout.LayoutParams(-1, dp(190)));
        Button calc = button("تحقق ثم احسب وخصم", 0xFF1976D2);
        calc.setOnClickListener(v -> calculateAndDeduct());
        msgBox.addView(calc);
        Button undo = button("↶ تراجع عن آخر عملية", 0xFFC62828);
        undo.setOnClickListener(v -> undoLastOperation());
        msgBox.addView(undo);
        content.addView(msgBox);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        renderWorkers();
        updateSelectedText();
    }

    private void saveGeneralStock() {
        try {
            int[] values = new int[DENOMS.length];
            for (int i = 0; i < DENOMS.length; i++) {
                String raw = stockInputs[i].getText().toString().trim();
                if (raw.isEmpty()) raw = "0";
                if (!raw.matches("\\d+") || Integer.parseInt(raw) < 0) {
                    stockInputs[i].setError("أدخل عددًا صحيحًا غير سالب");
                    result("تعذر حفظ المخزون العام. أدخل أعدادًا صحيحة غير سالبة؛ لم يتم تغيير أي رصيد.", false);
                    return;
                }
                values[i] = Integer.parseInt(raw);
            }
            JSONObject stock = data.getJSONObject("stock");
            for (int i = 0; i < DENOMS.length; i++) stock.put(String.valueOf(DENOMS[i]), values[i]);
            saveData();
            checkAndNotifyStock("المخزون العام", data.getJSONObject("stock"));
            result("تم حفظ المخزون العام بنجاح.", true);
        } catch(Exception e) { result("حدث خطأ أثناء حفظ المخزون.", false); }
    }

    private int parse(EditText e) {
        String raw = e.getText().toString().trim();
        if (raw.isEmpty()) return 0;
        if (!raw.matches("\\d+")) throw new IllegalArgumentException("أدخل عددًا صحيحًا غير سالب");
        return Integer.parseInt(raw);
    }

    private void showAddWorkerDialog() {
        final EditText name = new EditText(this);
        name.setHint("مثال: أحمد محمد");
        name.setTextSize(18);
        name.setGravity(Gravity.RIGHT);
        name.setSingleLine(true);
        name.setPadding(dp(10),dp(5),dp(10),dp(5));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("إضافة عامل جديد")
                .setMessage("اكتب اسم العامل. سيتم إنشاء مخزون 0 لكل الفئات.")
                .setView(name)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إضافة", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("اكتب اسم العامل"); return; }
            try {
                JSONObject workers = data.getJSONObject("workers");
                if (workers.has(n)) {
                    selectedWorker = n;
                    saveData(); renderWorkers(); updateSelectedText();
                    result("العامل موجود مسبقًا، تم اختياره: " + n, true);
                    d.dismiss();
                    return;
                }
                JSONObject w = new JSONObject();
                for (int den : DENOMS) w.put(String.valueOf(den), 0);
                workers.put(n, w);
                selectedWorker = n;
                saveData(); renderWorkers(); updateSelectedText();
                result("تمت إضافة العامل «" + n + "» ومخزونه جاهز للتعبئة.", true);
                d.dismiss();
            } catch(Exception e) { result("تعذر إضافة العامل.", false); }
        }));
        d.show();
    }

    private void renderWorkers() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            JSONArray names = workers.names();
            if (names == null || names.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("لا يوجد عمال. اضغط «إضافة عامل جديد».");
                empty.setTextSize(17); empty.setPadding(dp(5),dp(12),dp(5),dp(12));
                workersContainer.addView(empty);
                return;
            }
            for (int x=0; x<names.length(); x++) {
                String name = names.getString(x);
                JSONObject w = workers.getJSONObject(name);
                addWorkerCard(name, w);
            }
        } catch(Exception ignored) {}
    }

    private void addWorkerCard(String name, JSONObject w) {
        LinearLayout card = box();
        card.setPadding(dp(10),dp(10),dp(10),dp(10));

        TextView nameTv = title(name, 23);
        card.addView(nameTv);
        EditText phoneInput = new EditText(this);
        phoneInput.setHint("رقم هاتف العامل (واتساب)");
        phoneInput.setSingleLine(true);
        phoneInput.setInputType(3);
        phoneInput.setText(w.optString("phone", ""));
        card.addView(phoneInput, new LinearLayout.LayoutParams(-1, dp(52)));


        Button use = button(selectedWorker.equals(name) ? "✓ العامل المختار" : "اختيار هذا العامل", 0xFF1976D2);
        use.setOnClickListener(v -> {
            selectedWorker = name;
            updateSelectedText();
            renderWorkers();
            result("تم اختيار العامل: " + name, true);
        });
        card.addView(use);

        LinearLayout rr1 = row(), rr2 = row();
        for (int i=0;i<4;i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(16); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD); lab.setGravity(Gravity.CENTER);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            EditText inp = numberInput(w.optInt(String.valueOf(DENOMS[i]),0));
            cell.addView(lab);
            cell.addView(inp, new LinearLayout.LayoutParams(-1,dp(58)));
            cell.setTag(inp);
            if(i<2) addCategoryCell(rr1,cell); else addCategoryCell(rr2,cell);
        }
        card.addView(rr1); card.addView(rr2);

        Button save = button("حفظ مخزون هذا العامل", 0xFF16833A);
        save.setOnClickListener(v -> {
            try {
                LinearLayout[] rows = {rr1, rr2};
                JSONObject nw = new JSONObject();
                int[] values = new int[DENOMS.length];
                int idx=0;
                for(LinearLayout row: rows) {
                    for(int j=0;j<row.getChildCount();j++) {
                        LinearLayout cell=(LinearLayout)row.getChildAt(j);
                        EditText inp=(EditText)cell.getTag();
                        try { values[idx] = parse(inp); }
                        catch (Exception invalid) {
                            inp.setError("أدخل عددًا صحيحًا غير سالب");
                            result("تعذر حفظ مخزون العامل. أدخل أعدادًا صحيحة غير سالبة؛ لم يتم تغيير أي رصيد.", false);
                            return;
                        }
                        idx++;
                    }
                }
                for (int i = 0; i < DENOMS.length; i++) nw.put(String.valueOf(DENOMS[i]), values[i]);
                nw.put("phone", phoneInput.getText().toString().trim());
                // Retain per-denomination alert thresholds when saving the stock card.
                for (int denom : DENOMS) {
                    String thresholdKey = "threshold_" + denom;
                    if (w.has(thresholdKey)) nw.put(thresholdKey, w.optInt(thresholdKey, 10));
                }
                data.getJSONObject("workers").put(name,nw);
                saveData(); renderWorkers();
                result("تم حفظ مخزون العامل «"+name+"».",true);
            } catch(Exception e) { result("تعذر حفظ مخزون العامل.",false); }
        });
        card.addView(save);

        Button addStock = button("＋ إضافة كميات جديدة لهذا العامل", 0xFF00897B);
        addStock.setOnClickListener(v -> showAddStockDialog(name));
        card.addView(addStock);

        LinearLayout actions = row();
        Button del = button("حذف العامل", 0xFFC62828);
        del.setOnClickListener(v -> confirmDelete(name));
        addCell(actions, del);
        Button choose = button("اختيار العامل", 0xFF1976D2);
        choose.setOnClickListener(v -> {
            selectedWorker=name; updateSelectedText(); renderWorkers();
            result("تم اختيار العامل: "+name,true);
        });
        addCell(actions, choose);
        card.addView(actions);

        workersContainer.addView(card);
    }

    private void showAddStockDialog(String name) {
        try {
            JSONObject worker = data.getJSONObject("workers").getJSONObject(name);
            android.app.Dialog screen = new android.app.Dialog(this);
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(16), dp(12), dp(16), dp(12));
            root.setBackgroundColor(0xFFF4F6F8);
            root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            TextView heading = title("إضافة كروت للعمال", 25);
            root.addView(heading);
            TextView workerLabel = title("العامل: " + name, 19);
            root.addView(workerLabel);
            TextView note = new TextView(this);
            note.setText("أدخل الكميات الجديدة فقط. ستُضاف إلى رصيد العامل وتُخصم من المخزون العام في عملية واحدة. إذا لم يتوفر رصيد كافٍ فلن تتغير أي كمية.");
            note.setTextSize(16); note.setTextColor(0xFF555555); note.setGravity(Gravity.RIGHT);
            note.setPadding(0, dp(4), 0, dp(12)); root.addView(note);

            ScrollView scroll = new ScrollView(this);
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            EditText[] adds = new EditText[4];
            TextView[] available = new TextView[4];
            JSONObject general = data.getJSONObject("stock");
            for (int i=0;i<4;i++) {
                LinearLayout category = box();
                TextView label = title("فئة " + DENOMS[i], 19);
                category.addView(label);
                available[i] = new TextView(this);
                available[i].setText("رصيد العامل: " + worker.optInt(String.valueOf(DENOMS[i]),0) + "   |   المتاح بالمخزون العام: " + general.optInt(String.valueOf(DENOMS[i]),0));
                available[i].setTextSize(15); available[i].setGravity(Gravity.RIGHT); category.addView(available[i]);
                adds[i] = new EditText(this); adds[i].setInputType(2); adds[i].setSingleLine(true);
                adds[i].setHint("الكمية الجديدة فقط"); adds[i].setText("0");
                category.addView(adds[i], new LinearLayout.LayoutParams(-1, dp(58)));
                panel.addView(category);
            }
            scroll.addView(panel); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
            LinearLayout actions = row();
            Button cancel = button("إلغاء", 0xFF757575);
            cancel.setOnClickListener(v -> screen.dismiss());
            Button apply = button("تأكيد الإضافة", 0xFF00897B);
            actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(54), 1f));
            actions.addView(apply, new LinearLayout.LayoutParams(0, dp(54), 1f));
            root.addView(actions);
            apply.setOnClickListener(v -> {
                try {
                    JSONObject currentWorker = data.getJSONObject("workers").getJSONObject(name);
                    JSONObject stock = data.getJSONObject("stock");
                    JSONObject oldWorker = new JSONObject(currentWorker.toString());
                    JSONObject oldStock = new JSONObject(stock.toString());
                    int[] amounts = new int[4];
                    boolean any = false;
                    for (int i=0;i<4;i++) {
                        String key = String.valueOf(DENOMS[i]);
                        String raw = adds[i].getText().toString().trim();
                        if (raw.isEmpty()) raw = "0";
                        if (!raw.matches("\\d+")) {
                            adds[i].setError("أدخل عددًا صحيحًا غير سالب");
                            new AlertDialog.Builder(this).setTitle("تعذر إكمال العملية")
                                    .setMessage("أدخل أعدادًا صحيحة غير سالبة في جميع الفئات. لم يتم تغيير المخزون.")
                                    .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
                            return;
                        }
                        amounts[i] = Integer.parseInt(raw);
                        any |= amounts[i] > 0;
                        if (amounts[i] > stock.optInt(key, 0)) {
                            adds[i].setError("المخزون العام لا يكفي؛ المتاح " + stock.optInt(key,0));
                            new AlertDialog.Builder(this).setTitle("تعذر إكمال العملية").setMessage("لم تُحفظ أي كمية؛ المخزون العام لا يكفي لفئة " + key).setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show(); return;
                        }
                        Math.addExact(currentWorker.optInt(key,0), amounts[i]);
                    }
                    if (!any) { new AlertDialog.Builder(this).setTitle("تعذر إكمال العملية").setMessage("أدخل كمية واحدة على الأقل.").setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show(); return; }
                    for (int i=0;i<4;i++) {
                        String key = String.valueOf(DENOMS[i]);
                        currentWorker.put(key, Math.addExact(currentWorker.optInt(key,0), amounts[i]));
                        stock.put(key, stock.optInt(key,0) - amounts[i]);
                    }
                    saveData();
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString("last_undo_worker", name)
                            .putString("last_undo_worker_json", oldWorker.toString())
                            .putString("last_undo_stock_json", oldStock.toString())
                            .putBoolean("last_undo_available", true).apply();
                    renderWorkers(); checkAndNotifyStock("مخزون العامل " + name, currentWorker); checkAndNotifyStock("المخزون العام", stock);
                    result("تمت إضافة الكميات إلى العامل وخصمها من المخزون العام بنجاح.", true);
                    screen.dismiss();
                    StringBuilder addReport = new StringBuilder("تفاصيل الكميات المضافة:\n");
                    int previousTotal = 0, addedTotal = 0, newTotal = 0;
                    addReport.append("الرصيد السابق حسب الفئة:\n");
                    for (int i=0;i<4;i++) {
                        int oldAmount = oldWorker.optInt(String.valueOf(DENOMS[i]), 0);
                        previousTotal = Math.addExact(previousTotal, oldAmount);
                        addReport.append("فئة ").append(DENOMS[i]).append(": ").append(oldAmount).append(" كرت\n");
                    }
                    addReport.append("\nالكميات المضافة حسب الفئة:\n");
                    for (int i=0;i<4;i++) {
                        addedTotal = Math.addExact(addedTotal, amounts[i]);
                        addReport.append("فئة ").append(DENOMS[i]).append(": أضيف ").append(amounts[i]).append(" كرت\n");
                    }
                    addReport.append("\nالرصيد الجديد حسب الفئة:\n");
                    for (int i=0;i<4;i++) {
                        int newAmount = currentWorker.optInt(String.valueOf(DENOMS[i]), 0);
                        newTotal = Math.addExact(newTotal, newAmount);
                        addReport.append("فئة ").append(DENOMS[i]).append(": ").append(newAmount).append(" كرت\n");
                    }
                    addReport.append("\nالإجمالي قبل الإضافة: ").append(previousTotal).append(" كرت")
                            .append("\nإجمالي الكروت المضافة: ").append(addedTotal).append(" كرت")
                            .append("\nالإجمالي بعد الإضافة: ").append(newTotal).append(" كرت\n");
                    sendWorkerReport(name, "إضافة كروت", addReport.toString());
                } catch (Exception ex) { new AlertDialog.Builder(this).setTitle("تعذر إكمال العملية").setMessage("لم تُحفظ الإضافة. تحقق من الأرقام وحدود الكميات.").setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show(); }
            });
            screen.setContentView(root);
            if (screen.getWindow() != null) screen.getWindow().setLayout(-1, -1);
            screen.show();
            if (screen.getWindow() != null) screen.getWindow().setLayout(-1, -1);
        } catch (Exception ex) { result("تعذر فتح شاشة إضافة الكروت.", false); }
    }

    private void confirmDelete(String name) {
        if (name.equals(selectedWorker)) selectedWorker = "";
        new AlertDialog.Builder(this)
                .setTitle("حذف العامل")
                .setMessage("هل تريد حذف «"+name+"» ومخزونه؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d,w) -> {
                    try {
                        data.getJSONObject("workers").remove(name);
                        saveData(); renderWorkers(); updateSelectedText();
                        result("تم حذف العامل.", true);
                    } catch(Exception e) { result("تعذر حذف العامل.", false); }
                }).show();
    }

    private void updateSelectedText() {
        if (selectedText != null)
            selectedText.setText(selectedWorker.isEmpty() ? "العامل المختار: لا يوجد" : "العامل المختار: " + selectedWorker);
    }

    private void calculateAndDeduct() {
        String name = selectedWorker;
        if (name.isEmpty()) { result("اختر العامل أولًا.", false); return; }
        String text = messageInput.getText().toString();
        if (text.trim().isEmpty()) { result("التقرير فارغ. لم يتم إجراء أي تغيير.", false); return; }

        int[] used = {0,0,0,0};
        int count = 0;
        String currentCustomer = null;
        Set<String> seenNames = new HashSet<>();
        StringBuilder errors = new StringBuilder();
        StringBuilder verticalUsed = new StringBuilder();
        String[] lines = text.split("\\r?\n", -1);
        Pattern valuesPattern = Pattern.compile("^(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)$");
        Pattern malformedValuesPattern = Pattern.compile("^\\d+(?:\\s*-\\s*\\d+){1,3}$");

        for (int li=0; li<lines.length; li++) {
            String raw = lines[li].trim();
            String line = raw.replace("……", "").replace("...", "").replace("......", "").trim();
            if (line.isEmpty()) continue;
            Matcher vm = valuesPattern.matcher(line);
            if (vm.matches()) {
                if (currentCustomer == null || currentCustomer.trim().isEmpty()) {
                    errors.append("السطر ").append(li+1).append(": توجد كميات دون اسم عامل/عميل قبلها.\n");
                    continue;
                }
                int[] row = new int[4];
                try {
                    for (int i=0;i<4;i++) {
                        row[i] = Integer.parseInt(vm.group(i+1));
                        if (row[i] < 0) throw new NumberFormatException();
                        used[i] = Math.addExact(used[i], row[i]);
                    }
                } catch (Exception ex) {
                    errors.append("السطر ").append(li+1).append(" (").append(currentCustomer).append("): كمية غير صالحة أو كبيرة جدًا.\n");
                    continue;
                }
                count++;
                verticalUsed.append("<b>").append(android.text.Html.escapeHtml(currentCustomer)).append("</b><br>");
                verticalUsed.append("100 : ").append(row[0]).append("<br>200 : ").append(row[1])
                        .append("<br>250 : ").append(row[2]).append("<br>500 : ").append(row[3]).append("<br><br>");
                currentCustomer = null;
            } else {
                if (malformedValuesPattern.matcher(line).matches()) {
                    errors.append("السطر ").append(li+1).append(": صيغة الكميات ناقصة؛ يجب إدخال أربع قيم بالضبط مفصولة بشرطات، مثل 40-10-10-0. القيمة المدخلة: ").append(line).append("\n");
                    continue;
                }
                if (currentCustomer != null) {
                    errors.append("السطر ").append(li+1).append(": اسم جديد «").append(line)
                            .append("» ظهر قبل إدخال كميات الاسم السابق «").append(currentCustomer).append("».\n");
                }
                currentCustomer = line;
                if (seenNames.contains(currentCustomer)) {
                    errors.append("السطر ").append(li+1).append(": الاسم «").append(currentCustomer).append("» مكرر.\n");
                } else seenNames.add(currentCustomer);
            }
        }
        if (currentCustomer != null) errors.append("لم توجد كميات من أربع قيم بعد الاسم «").append(currentCustomer).append("» في نهاية التقرير.\n");
        if (count == 0 && errors.length() == 0) errors.append("لم أجد أي مجموعة صحيحة. يجب كتابة اسم ثم أربعة أرقام مثل 40-10-10-0.\n");
        if (errors.length() > 0) {
            result("<b>تم رفض التقرير كاملًا، ولم يتم الخصم.</b><br><br>" + android.text.Html.escapeHtml(errors.toString()).toString().replace("\n", "<br>"), false);
            return;
        }

        try {
            JSONObject workers=data.getJSONObject("workers");
            JSONObject w=workers.getJSONObject(name);
            JSONObject stock=data.getJSONObject("stock");
            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                int wb=w.optInt(k,0), sb=stock.optInt(k,0);
                if(used[i]>wb) { result("رصيد العامل غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+wb+"، ولم يتم الخصم.",false); return; }
                if(used[i]>sb) { result("المخزون العام غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+sb+"، ولم يتم الخصم.",false); return; }
            }
            JSONObject oldWorker = new JSONObject(w.toString());
            JSONObject oldStock = new JSONObject(stock.toString());
            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                w.put(k,w.optInt(k,0)-used[i]);
                stock.put(k,stock.optInt(k,0)-used[i]);
            }
            saveData();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("last_undo_worker", name)
                    .putString("last_undo_worker_json", oldWorker.toString())
                    .putString("last_undo_stock_json", oldStock.toString())
                    .putBoolean("last_undo_available", true).apply();
            renderWorkers();
            checkAndNotifyStock("مخزون العامل " + name, w);
            checkAndNotifyStock("المخزون العام", stock);
            StringBuilder out=new StringBuilder("تم الخصم بنجاح<br><br><b>الكروت المستخدمة:</b><br><br>");
            out.append(verticalUsed).append("عدد المجموعات: ").append(count).append("<br><br><b>الإجمالي:</b><br>");
            for(int i=0;i<4;i++) out.append(DENOMS[i]).append(" : ").append(used[i]).append("<br>");
            result(out.toString(),true);
            String reportBody = "تم الخصم بنجاح\n"
                    + htmlToPlainText(out.toString())
                    + "\n\n" + buildWorkerBalanceText(w) + "\n" + buildStockBalanceText(stock);
            sendWorkerReport(name, "عملية خصم وتوزيع", reportBody);
        } catch(Exception e) { result("حدث خطأ أثناء الخصم؛ لم تكتمل العملية.",false); }
    }

    private String buildWorkerBalanceText(JSONObject worker) {
        return buildBalanceText("رصيد العامل المتبقي بعد العملية", worker);
    }

    private String buildStockBalanceText(JSONObject stock) {
        return buildBalanceText("المخزون العام المتبقي بعد العملية", stock);
    }

    private String buildBalanceText(String heading, JSONObject balances) {
        StringBuilder b = new StringBuilder(heading).append(":\n");
        for (int denom : DENOMS) b.append("فئة ").append(denom).append(": ").append(balances.optInt(String.valueOf(denom),0)).append(" كرت\n");
        return b.toString();
    }

    private void sendWorkerReport(String workerName, String operation, String body) {
        try {
            String phone = data.getJSONObject("workers").getJSONObject(workerName).optString("phone", "").replaceAll("[^0-9+]", "").trim();
            if (phone.isEmpty()) { new AlertDialog.Builder(this).setTitle("تعذر إرسال التقرير").setMessage("تم حفظ العملية، لكن رقم هاتف العامل غير مسجل. أضف رقم العامل ثم أعد إرسال التقرير.").setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show(); return; }
            File dir = new File(getCacheDir(), "reports");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("reports directory");
            String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
            String reportText = "مخزون كروت الكامل V24\nالعامل: " + workerName + "\nالعملية: " + operation + "\nالتاريخ: " + stamp + "\n\n" + body;
            int width = 900;
            TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            paint.setTextSize(30); paint.setColor(0xFF202938);
            StaticLayout layout = StaticLayout.Builder.obtain(reportText, 0, reportText.length(), paint, width - 100)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(true).build();
            int height = Math.max(520, layout.getHeight() + 190);
            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(0xFFF5F8FC);
            Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG); accent.setColor(0xFF147D92);
            canvas.drawRect(0, 0, width, 110, accent);
            TextPaint head = new TextPaint(Paint.ANTI_ALIAS_FLAG); head.setColor(Color.WHITE); head.setTextSize(34); head.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("تقرير مخزون كروت الكامل", width - 40 - head.measureText("تقرير مخزون كروت الكامل"), 68, head);
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG); line.setColor(0xFFD9E2EC); line.setStrokeWidth(2);
            Paint cardPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            cardPaint.setColor(Color.WHITE);
            canvas.drawRoundRect(24, 130, width - 24, height - 24, 24, 24, cardPaint);
            canvas.save(); canvas.translate(50, 155); layout.draw(canvas); canvas.restore();
            File file = new File(dir, "worker_report_" + System.currentTimeMillis() + ".png");
            try (FileOutputStream out = new FileOutputStream(file)) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); out.flush(); }
            bitmap.recycle();
            Uri uri = FileProvider.getUriForFile(this, "com.alkamel.workercards.pro24.fileprovider", file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, "تقرير " + operation + " للعامل " + workerName + " - " + stamp);
            // WhatsApp may use this JID hint to open the worker's chat directly. The
            // app still asks the user to confirm sending; this is not a silent send.
            String jidPhone = phone.replace("+", "").replaceAll("[^0-9]", "");
            if (!jidPhone.isEmpty()) share.putExtra("jid", jidPhone + "@s.whatsapp.net");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { share.setPackage("com.whatsapp"); startActivity(share); }
            catch (Exception noWhatsApp) { share.setPackage(null); startActivity(Intent.createChooser(share, "إرسال تقرير العامل")); }
        } catch (Exception ex) {
            new AlertDialog.Builder(this).setTitle("تعذر إرسال التقرير").setMessage("تم حفظ العملية، لكن تعذر تجهيز صورة التقرير أو فتح واتساب. تحقق من وجود واتساب وصلاحيات مشاركة الملفات.").setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
        }
    }

    private void undoLastOperation() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("last_undo_available", false)) {
            result("لا توجد عملية قابلة للتراجع.", false); return;
        }
        new AlertDialog.Builder(this).setTitle("التراجع عن آخر عملية")
                .setMessage("سيتم استعادة رصيد العامل والمخزون العام كما كانا قبل آخر عملية إضافة أو خصم. لا يمكن التراجع عنها مرة ثانية. هل تريد المتابعة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("تراجع", (d, which) -> {
                    try {
                        String n = p.getString("last_undo_worker", "");
                        JSONObject oldW = new JSONObject(p.getString("last_undo_worker_json", "{}"));
                        JSONObject oldS = new JSONObject(p.getString("last_undo_stock_json", "{}"));
                        JSONObject workers = data.getJSONObject("workers");
                        if (!workers.has(n)) throw new Exception("worker missing");
                        workers.put(n, oldW); data.put("stock", oldS);
                        saveData();
                        p.edit().putBoolean("last_undo_available", false)
                                .remove("last_undo_worker_json").remove("last_undo_stock_json").apply();
                        renderWorkers(); checkAndNotifyStock("مخزون العامل " + n, oldW); checkAndNotifyStock("المخزون العام", oldS);
                        result("تم التراجع عن آخر عملية واستعادة الأرصدة.", true);
                    } catch(Exception ex) { result("تعذر التراجع؛ لم يتم تغيير البيانات.", false); }
                }).show();
    }

    private String htmlToPlainText(String html) {
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            return android.text.Html.fromHtml(html, android.text.Html.FROM_HTML_MODE_LEGACY).toString();
        }
        // API 23 compatibility: the mode overload/constants are not available yet.
        return android.text.Html.fromHtml(html).toString();
    }

    private void result(String text, boolean ok) {
        if (ok) {
            String plain = htmlToPlainText(text).replaceAll("\\s+", " ").trim();
            Toast.makeText(this, plain.length() > 110 ? plain.substring(0, 107) + "..." : plain, Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("تعذر إكمال العملية")
                .setMessage(android.text.Html.fromHtml(text))
                .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void checkAndNotifyStock(String categoryPrefix, JSONObject stock) {
        try {
            SharedPreferences alertPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
            for (int denom : DENOMS) {
                String key = String.valueOf(denom);
                int threshold;
                if (categoryPrefix.startsWith("مخزون العامل ")) {
                    String workerName = categoryPrefix.substring("مخزون العامل ".length());
                    threshold = stock.optInt("threshold_" + denom,
                            alertPrefs.getInt("worker_" + workerName + "_threshold_" + denom,
                                    alertPrefs.getInt("threshold_" + denom, alertPrefs.getInt(StockSettings.DEFAULT_THRESHOLD, 10))));
                } else {
                    threshold = alertPrefs.getInt("threshold_" + denom, alertPrefs.getInt(StockSettings.DEFAULT_THRESHOLD, 10));
                }
                int remaining = stock.optInt(key, 0);
                Intent alert = new Intent(this, StockAlertReceiver.class);
                alert.setAction(StockAlertReceiver.ACTION);
                alert.putExtra(StockAlertReceiver.EXTRA_CATEGORY, categoryPrefix + " - فئة " + denom);
                alert.putExtra(StockAlertReceiver.EXTRA_REMAINING, remaining);
                alert.putExtra(StockAlertReceiver.EXTRA_THRESHOLD, threshold);
                sendBroadcast(alert);
            }
        } catch (Exception ignored) {}
    }

    private void exportBackup() {
        try {
            SharedPreferences backupPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
            if (backupPrefs.getBoolean("internal_backups_enabled", false)) {
                if (!BackupHelper.hasRootStorageAccess()) {
                    new AlertDialog.Builder(this).setTitle("إذن الوصول مطلوب")
                            .setMessage("فعّلت حفظ النسخ في مجلد مخزون كروت الكامل، لكن إذن الذاكرة الداخلية غير ممنوح. امنح الإذن ثم أعد النسخ.")
                            .setNegativeButton("إغلاق", (dialog, which) -> dialog.dismiss())
                            .setPositiveButton("فتح الإعدادات", (dialog, which) -> BackupHelper.openStorageAccessSettings(this)).show();
                    return;
                }
                BackupHelper.createBackup(this);
                return;
            }
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"نسخة_احتياطية_كروت_العامل.json");
            startActivityForResult(i,CREATE_BACKUP);
        } catch(Exception e){ result("تعذر فتح حفظ النسخة.",false); }
    }

    private void restoreBackup() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,RESTORE_BACKUP);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent intent) {
        super.onActivityResult(requestCode,resultCode,intent);
        if(resultCode!=RESULT_OK || intent==null || intent.getData()==null)return;
        Uri uri=intent.getData();
        try {
            if(requestCode==CREATE_BACKUP) {
                OutputStream out=getContentResolver().openOutputStream(uri);
                out.write(data.toString(2).getBytes(StandardCharsets.UTF_8)); out.close();
                result("تم تصدير النسخة الاحتياطية بنجاح.",true);
            } else if(requestCode==RESTORE_BACKUP) {
                InputStream in=getContentResolver().openInputStream(uri);
                ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] buf=new byte[4096]; int n;
                while((n=in.read(buf))!=-1)b.write(buf,0,n);
                in.close();
                JSONObject restored=new JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));
                if(restored.optJSONObject("stock")==null || restored.optJSONObject("workers")==null)
                    throw new Exception("invalid");
                data=restored; selectedWorker="";
                saveData(); buildUi();
                result("تمت استعادة البيانات بنجاح.",true);
            }
        } catch(Exception e) { result("ملف النسخة الاحتياطية غير صالح أو تعذر قراءته.",false); }
    }
}
