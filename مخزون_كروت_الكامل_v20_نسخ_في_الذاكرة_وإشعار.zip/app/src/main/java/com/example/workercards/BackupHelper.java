package com.example.workercards;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * النسخ الاحتياطي التلقائي.
 *
 * Android 10+:
 * يحفظ داخل الذاكرة الداخلية في:
 * Documents/مخزون كروت الكامل/
 *
 * Android 9 وأقدم:
 * يستخدم نفس المجلد داخل Documents.
 *
 * اسم الملف يحتوي على تاريخ ووقت إنشاء النسخة.
 */
public class BackupHelper {

    private static final String APP_FOLDER = "مخزون كروت الكامل";
    private static final String PREFS = "worker_cards_data_v12";

    public static void createBackup(Context context) {
        try {
            SharedPreferences prefs =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            String json = prefs.getString("data", "");

            if (json == null || json.trim().isEmpty()) {
                return;
            }

            String stamp = new SimpleDateFormat(
                    "yyyy-MM-dd_HH-mm-ss",
                    Locale.US
            ).format(new Date());

            String fileName = "backup_" + stamp + ".json";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveWithMediaStore(context, fileName, json);
            } else {
                saveLegacy(fileName, json);
            }

        } catch (Exception ignored) {
        }
    }

    /**
     * Android 10+ بدون الحاجة إلى WRITE_EXTERNAL_STORAGE.
     * المسار النهائي:
     * الذاكرة الداخلية/Documents/مخزون كروت الكامل/
     */
    private static void saveWithMediaStore(
            Context context,
            String fileName,
            String json
    ) throws Exception {

        ContentResolver resolver = context.getContentResolver();

        ContentValues values = new ContentValues();
        values.put(
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                fileName
        );
        values.put(
                MediaStore.Files.FileColumns.MIME_TYPE,
                "application/json"
        );
        values.put(
                MediaStore.Files.FileColumns.RELATIVE_PATH,
                
                        + APP_FOLDER
                        + "/"
        );
        values.put(
                MediaStore.Files.FileColumns.IS_PENDING,
                1
        );

        Uri uri = resolver.insert(
                MediaStore.Files.getContentUri("external"),
                values
        );

        if (uri == null) return;

        try {
            OutputStream out = resolver.openOutputStream(uri);

            if (out == null) {
                resolver.delete(uri, null, null);
                return;
            }

            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.close();

            ContentValues done = new ContentValues();
            done.put(
                    MediaStore.Files.FileColumns.IS_PENDING,
                    0
            );

            resolver.update(uri, done, null, null);

            showBackupNotification(context, fileName);

        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        deleteOldBackups(context);
    }

    /**
     * Android 9 وأقدم.
     */
    private static void saveLegacy(
            String fileName,
            String json
    ) throws Exception {

        File documents =
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOCUMENTS
                );

        File folder = new File(
                documents,
                APP_FOLDER
        );

        if (!folder.exists() && !folder.mkdirs()) {
            return;
        }

        File out = new File(folder, fileName);

        FileOutputStream fos =
                new FileOutputStream(out);

        fos.write(json.getBytes(StandardCharsets.UTF_8));
        fos.flush();
        fos.close();

        showBackupNotification(context, fileName);
        deleteOldLegacyBackups(folder);
    }

    /**
     * الاحتفاظ بآخر 30 نسخة في Android 10+.
     */
    private static void deleteOldBackups(Context context) {

        try {
            ContentResolver resolver =
                    context.getContentResolver();

            String relativePath =
                    
                            + APP_FOLDER
                            + "/";

            Uri collection =
                    MediaStore.Files.getContentUri("external");

            java.util.ArrayList<BackupItem> items =
                    new java.util.ArrayList<>();

            String[] projection = {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.DISPLAY_NAME,
                    MediaStore.Files.FileColumns.DATE_MODIFIED,
                    MediaStore.Files.FileColumns.RELATIVE_PATH
            };

            String selection =
                    MediaStore.Files.FileColumns.RELATIVE_PATH + "=? AND "
                            + MediaStore.Files.FileColumns.DISPLAY_NAME
                            + " LIKE ?";

            String[] args = {
                    relativePath,
                    "backup_%.json"
            };

            android.database.Cursor c =
                    resolver.query(
                            collection,
                            projection,
                            selection,
                            args,
                            MediaStore.Files.FileColumns.DATE_MODIFIED + " ASC"
                    );

            if (c != null) {

                int idIndex = c.getColumnIndex(
                        MediaStore.Files.FileColumns._ID
                );

                int nameIndex = c.getColumnIndex(
                        MediaStore.Files.FileColumns.DISPLAY_NAME
                );

                int dateIndex = c.getColumnIndex(
                        MediaStore.Files.FileColumns.DATE_MODIFIED
                );

                while (c.moveToNext()) {

                    long id = c.getLong(idIndex);
                    String name = c.getString(nameIndex);
                    long date = c.getLong(dateIndex);

                    items.add(
                            new BackupItem(id, name, date)
                    );
                }

                c.close();
            }

            while (items.size() > 30) {

                BackupItem old = items.remove(0);

                Uri oldUri = Uri.withAppendedPath(
                        collection,
                        String.valueOf(old.id)
                );

                resolver.delete(oldUri, null, null);
            }

        } catch (Exception ignored) {
        }
    }

    private static void deleteOldLegacyBackups(File folder) {

        File[] backups = folder.listFiles(
                (dir, name) ->
                        name.startsWith("backup_")
                                && name.endsWith(".json")
        );

        if (backups == null || backups.length <= 30) {
            return;
        }

        java.util.Arrays.sort(
                backups,
                (a, b) ->
                        Long.compare(
                                a.lastModified(),
                                b.lastModified()
                        )
        );

        for (int i = 0; i < backups.length - 30; i++) {
            backups[i].delete();
        }
    }

    private static class BackupItem {

        long id;
        String name;
        long date;

        BackupItem(long id, String name, long date) {
            this.id = id;
            this.name = name;
            this.date = date;
        }
    }
}
