package com.example.workercards;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "worker_cards_native";
    private static final String DATA_KEY = "data";

    private final int[] DENOMS = {100, 200, 250, 500};
    private JSONObject data;
    private LinearLayout root, workersContainer;
    private EditText workerName, message;
    private TextView result;
    private int blue = Color.rgb(25,118,210);
    private int green = Color.rgb(22,131,58);
    private int red = Color.rgb(198,40,40);
    private int gray = Color.rgb(95,95,95);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(blue);
        loadData();
        buildUi();
        renderAll();
    }

    private void loadData() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = p.getString(DATA_KEY, null);
        try {
            data = raw == null ? defaultData() : new JSONObject(raw);
            if (!data.has("stock")) data.put("stock", new JSONObject());
            if (!data.has("workers")) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = defaultData();
        }
    }

    private JSONObject defaultData() {
        JSONObject d = new JSONObject();
        try {
            JSONObject s = new JSONObject();
            s.put("100", 2000); s.put("200", 2000); s.put("250", 2000); s.put("500", 1000);
            JSONObject w = new JSONObject();
            JSONObject mw = new JSONObject();
            mw.put("100",432); mw.put("200",1000); mw.put("250",1000); mw.put("500",100);
            w.put("محمد ثابت", mw);
            d.put("stock", s); d.put("workers", w);
        } catch (Exception ignored) {}
        return d;
    }

    private void saveData() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(DATA_KEY, data.toString()).apply();
    }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(18, 12, 18, 12);
        return t;
    }

    private EditText edit(String value, String hint, int inputType) {
        EditText e = new EditText(this);
        e.setText(value); e.setHint(hint); e.setTextSize(18);
        e.setInputType(inputType);
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        e.setPadding(18, 12, 18, 12);
        e.setIncludeFontPadding(true);
        e.setBackgroundColor(Color.WHITE);
        return e;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(17); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundColor(color);
        return b;
    }

    private LinearLayout section(String title) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(14, 12, 14, 12);
        box.setBackgroundColor(Color.WHITE);
        TextView h = tv(title, 24, Color.rgb(35,35,35), true);
        h.setIncludeFontPadding(true);
        box.addView(h, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(12, 10, 12, 0);
        root.addView(box, lp);
        return box;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, 8, 0, 24);
        root.setBackgroundColor(Color.rgb(245,247,250));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void renderAll() {
        root.removeAllViews();

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(18, 18, 18, 18);
        header.setBackgroundColor(Color.WHITE);
        TextView h = tv("📦 إدارة كروت العامل", 29, Color.rgb(25,25,25), true);
        h.setGravity(Gravity.CENTER);
        h.setIncludeFontPadding(true);
        header.addView(h);
        TextView sub = tv("تطبيق Android أصلي لإدارة المخزون والعمال والخصم", 16, gray, false);
        sub.setGravity(Gravity.CENTER);
        sub.setIncludeFontPadding(true);
        header.addView(sub);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        renderStock();
        renderWorkers();
        renderMessage();
        renderResult();
    }

    private void renderStock() {
        LinearLayout box = section("المخزون العام");
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        for (int row=0; row<2; row++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for (int col=0; col<2; col++) {
                int d = DENOMS[row*2+col];
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                TextView label = tv(String.valueOf(d), 17, Color.DKGRAY, true);
                label.setGravity(Gravity.CENTER);
                EditText e = edit(String.valueOf(getStock(d)), "", android.text.InputType.TYPE_CLASS_NUMBER);
                e.setTag("stock_"+d);
                cell.addView(label);
                cell.addView(e, new LinearLayout.LayoutParams(-1, 78));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
                cp.setMargins(6, 4, 6, 4);
                r.addView(cell, cp);
            }
            grid.addView(r);
        }
        box.addView(grid);

        Button save = button("حفظ المخزون", green);
        save.setOnClickListener(v -> {
            try {
                for (int d : DENOMS) {
                    EditText e = root.findViewWithTag("stock_"+d);
                    data.getJSONObject("stock").put(String.valueOf(d), Math.max(0,Integer.parseInt(e.getText().toString().trim())));
                }
                saveData(); show("تم حفظ المخزون.");
            } catch (Exception ex) { show("تأكد من إدخال أرقام صحيحة."); }
        });
        box.addView(save);
    }

    private int getStock(int d) {
        try { return data.getJSONObject("stock").optInt(String.valueOf(d), 0); }
        catch(Exception e) { return 0; }
    }

    private void renderWorkers() {
        LinearLayout box = section("العامل");
        workerName = edit("", "اسم العامل", android.text.InputType.TYPE_CLASS_TEXT);
        box.addView(tv("اسم العامل", 16, gray, true));
        box.addView(workerName, new LinearLayout.LayoutParams(-1, 76));

        Button add = button("إضافة / اختيار العامل", blue);
        add.setOnClickListener(v -> addWorker());
        box.addView(add);

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        box.addView(workersContainer);
        renderWorkerList();
    }

    private void addWorker() {
        String name = workerName.getText().toString().trim();
        if (name.isEmpty()) { show("اكتب اسم العامل أولًا."); return; }
        try {
            JSONObject workers = data.getJSONObject("workers");
            if (!workers.has(name)) {
                JSONObject w = new JSONObject();
                for (int d: DENOMS) w.put(String.valueOf(d), 0);
                workers.put(name, w);
                saveData();
                show("تمت إضافة العامل: " + name);
            } else show("العامل موجود، تم اختياره.");
            workerName.setText(name);
            renderWorkerList();
        } catch(Exception e) { show("تعذر إضافة العامل."); }
    }

    private void renderWorkerList() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            Iterator<String> it = workers.keys();
            while (it.hasNext()) {
                String name = it.next();
                JSONObject w = workers.getJSONObject(name);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(14, 14, 14, 14);
                card.setBackgroundColor(Color.rgb(250,250,250));

                TextView n = tv(name, 20, Color.rgb(30,30,30), true);
                card.addView(n);
                Button use = button("استخدام هذا العامل", blue);
                use.setOnClickListener(v -> {
                    workerName.setText(name);
                    message.requestFocus();
                    show("تم اختيار العامل: " + name);
                });
                card.addView(use);

                LinearLayout balances = new LinearLayout(this);
                balances.setOrientation(LinearLayout.HORIZONTAL);
                for (int d: DENOMS) {
                    TextView b = tv(d + "\n" + w.optInt(String.valueOf(d),0), 15, Color.DKGRAY, true);
                    b.setGravity(Gravity.CENTER);
                    b.setIncludeFontPadding(true);
                    balances.addView(b, new LinearLayout.LayoutParams(0, 86, 1));
                }
                card.addView(balances);

                Button del = button("حذف العامل", red);
                del.setOnClickListener(v -> deleteWorker(name));
                card.addView(del);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
                lp.setMargins(0,10,0,0);
                workersContainer.addView(card, lp);
            }
        } catch(Exception ignored) {}
    }

    private void deleteWorker(String name) {
        try {
            data.getJSONObject("workers").remove(name);
            saveData(); renderWorkerList();
            show("تم حذف العامل: " + name);
        } catch(Exception e) { show("تعذر حذف العامل."); }
    }

    private void renderMessage() {
        LinearLayout box = section("رسالة العامل");
        TextView info = tv("الصق رسالة العامل كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500", 16, gray, false);
        box.addView(info);
        message = new EditText(this);
        message.setHint("مثال:\n1-2-3-4\n2-1-0-3");
        message.setTextSize(17);
        message.setGravity(Gravity.TOP | Gravity.RIGHT);
        message.setMinLines(8);
        message.setIncludeFontPadding(true);
        message.setPadding(16, 12, 16, 12);
        message.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(message, new LinearLayout.LayoutParams(-1, 250));

        Button calc = button("احسب وخصم", green);
        calc.setOnClickListener(v -> calculate());
        box.addView(calc);
    }

    private void renderResult() {
        LinearLayout box = section("النتيجة");
        result = tv("—", 17, Color.rgb(40,40,40), false);
        result.setGravity(Gravity.RIGHT | Gravity.TOP);
        result.setPadding(16,16,16,16);
        box.addView(result);
    }

    private void calculate() {
        String name = workerName == null ? "" : workerName.getText().toString().trim();
        String text = message == null ? "" : message.getText().toString();
        if (name.isEmpty()) { show("اختر العامل أولًا."); return; }
        try {
            JSONObject workers = data.getJSONObject("workers");
            if (!workers.has(name)) { show("العامل غير مضاف."); return; }
            int[] used = {0,0,0,0};
            String[] lines = text.split("\\r?\\n");
            int count = 0;
            java.util.regex.Pattern p = java.util.regex.Pattern.compile("(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)");
            for (String line: lines) {
                java.util.regex.Matcher m = p.matcher(line);
                while (m.find()) {
                    for (int i=0;i<4;i++) used[i] += Integer.parseInt(m.group(i+1));
                    count++;
                }
            }
            if (count == 0) { show("لم أجد سطرًا بصيغة 100-200-250-500."); return; }

            JSONObject w = workers.getJSONObject(name);
            JSONObject s = data.getJSONObject("stock");
            for (int i=0;i<4;i++) {
                String k = String.valueOf(DENOMS[i]);
                int wb = w.optInt(k,0), sb = s.optInt(k,0);
                if (used[i] > wb) { show("رصيد العامل غير كافٍ في فئة " + k + ". المطلوب " + used[i] + " والمتوفر " + wb + "\nلم يتم الخصم."); return; }
                if (used[i] > sb) { show("المخزون العام غير كافٍ في فئة " + k + ". المطلوب " + used[i] + " والمتوفر " + sb + "\nلم يتم الخصم."); return; }
            }
            StringBuilder out = new StringBuilder("تم الخصم بنجاح من العامل: ").append(name).append("\n\n");
            for (int i=0;i<4;i++) {
                String k = String.valueOf(DENOMS[i]);
                int nw = w.optInt(k,0)-used[i], ns = s.optInt(k,0)-used[i];
                w.put(k,nw); s.put(k,ns);
                out.append(k).append(" : المطلوب ").append(used[i])
                   .append(" | رصيد العامل ").append(nw)
                   .append(" | المخزون ").append(ns).append("\n");
            }
            saveData();
            renderAll();
            show(out.toString());
        } catch(Exception e) { show("حدث خطأ أثناء الحساب."); }
    }

    private void show(String text) {
        if (result != null) result.setText(text);
        Toast.makeText(this, text.split("\\n")[0], Toast.LENGTH_SHORT).show();
    }
}
