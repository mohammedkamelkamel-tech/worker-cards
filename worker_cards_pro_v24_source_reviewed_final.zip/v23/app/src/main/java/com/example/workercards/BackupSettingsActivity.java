package com.example.workercards;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONObject;

public class BackupSettingsActivity extends Activity {

    private CheckBox enabled;
    private TextView timeText;
    private final EditText[] thresholds = new EditText[4];
    private final int[] denominations = {100, 200, 250, 500};
    private final Map<String, EditText> workerThresholdInputs = new LinkedHashMap<>();

    @Override protected void onResume() {
        super.onResume();
        android.content.SharedPreferences p = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        if (p.getBoolean("internal_backups_enabled", false)
                && p.getBoolean("internal_backup_permission_pending", false)
                && BackupHelper.hasRootStorageAccess()) {
            p.edit().putBoolean("internal_backup_permission_pending", false).apply();
            BackupHelper.createBackup(this);
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        android.content.SharedPreferences p =
                getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);

        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(0xFFF1F5F9);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 36, 40, 44);
        box.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("إعدادات النسخ والتنبيهات");
        title.setTextSize(24);
        title.setTextColor(0xFF123047);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 18);
        box.addView(title);

        TextView location = new TextView(this);
        location.setText("📁 مكان النسخ: الذاكرة الداخلية / مخزون كروت الكامل");
        location.setTextSize(15);
        location.setPadding(0, 12, 0, 12);
        box.addView(location);

        TextView accessStatus = new TextView(this);
        accessStatus.setText(
                BackupHelper.hasRootStorageAccess()
                        ? "✅ الوصول إلى الذاكرة الداخلية مفعّل"
                        : "⚠️ يجب السماح للتطبيق بالوصول إلى الذاكرة الداخلية حتى يتم إنشاء المجلد مباشرة."
        );
        accessStatus.setTextSize(15);
        accessStatus.setPadding(0, 8, 0, 8);
        box.addView(accessStatus);

        CheckBox internalBackups = new CheckBox(this);
        internalBackups.setText("السماح بحفظ النسخ في الذاكرة الداخلية");
        internalBackups.setChecked(p.getBoolean("internal_backups_enabled", false));
        internalBackups.setOnCheckedChangeListener((button, checked) -> {
            p.edit().putBoolean("internal_backups_enabled", checked).apply();
            if (checked && !BackupHelper.hasRootStorageAccess()) {
                p.edit().putBoolean("internal_backup_permission_pending", true).apply();
                BackupHelper.openStorageAccessSettings(this);
            } else if (checked) {
                p.edit().putBoolean("internal_backup_permission_pending", false).apply();
                BackupHelper.createBackup(this);
            } else {
                p.edit().putBoolean("internal_backup_permission_pending", false).apply();
            }
            StockSettings.scheduleBackup(this);
        });
        box.addView(internalBackups);

        Button testBackup = new Button(this);
        testBackup.setText("🧪 اختبار النسخ الآن");
        testBackup.setOnClickListener(v -> {
            BackupHelper.createBackup(this);
        });
        box.addView(testBackup);

        enabled = new CheckBox(this);
        enabled.setText("تفعيل النسخ الاحتياطي التلقائي يوميًا");
        enabled.setChecked(p.getBoolean(StockSettings.BACKUP_ENABLED, true));
        box.addView(enabled);

        timeText = new TextView(this);
        timeText.setText("وقت النسخ: " + String.format("%02d:%02d",
                p.getInt(StockSettings.BACKUP_HOUR,4),
                p.getInt(StockSettings.BACKUP_MINUTE,0)));
        timeText.setTextSize(18);
        timeText.setPadding(0,24,0,24);
        box.addView(timeText);

        Button choose = new Button(this);
        choose.setText("تحديد وقت النسخ");
        choose.setOnClickListener(v -> {
            int h = p.getInt(StockSettings.BACKUP_HOUR,4);
            int m = p.getInt(StockSettings.BACKUP_MINUTE,0);
            new TimePickerDialog(this, (view, hour, minute) -> {
                p.edit().putInt(StockSettings.BACKUP_HOUR,hour)
                        .putInt(StockSettings.BACKUP_MINUTE,minute).apply();
                timeText.setText("وقت النسخ: " + String.format("%02d:%02d",hour,minute));
                StockSettings.scheduleBackup(this);
            }, h, m, true).show();
        });
        box.addView(choose);

        TextView t = new TextView(this);
        t.setText("حدود تنبيه المخزون لكل فئة (تنبيه عند الحد أو أقل):");
        t.setTextSize(17);
        t.setPadding(0, 16, 0, 6);
        box.addView(t);
        for (int i=0; i<denominations.length; i++) {
            TextView label = new TextView(this);
            label.setText("فئة " + denominations[i]);
            label.setTextSize(15);
            box.addView(label);
            thresholds[i] = new EditText(this);
            thresholds[i].setInputType(2);
            thresholds[i].setHint("الحد الأدنى لهذه الفئة");
            thresholds[i].setText(String.valueOf(p.getInt("threshold_" + denominations[i], p.getInt(StockSettings.DEFAULT_THRESHOLD, 10))));
            box.addView(thresholds[i]);
        }

        TextView workerTitle = new TextView(this);
        workerTitle.setText("حدود التنبيه لكل عامل بشكل مستقل");
        workerTitle.setTextSize(19); workerTitle.setPadding(0, 22, 0, 8);
        box.addView(workerTitle);
        try {
            android.content.SharedPreferences dataPrefs = getSharedPreferences("worker_cards_pro_v24_data", MODE_PRIVATE);
            JSONObject appData = new JSONObject(dataPrefs.getString("data", "{}"));
            JSONObject workers = appData.optJSONObject("workers");
            if (workers == null || workers.length() == 0) {
                TextView empty = new TextView(this); empty.setText("أضف العمال أولًا لتحديد حدود تنبيه خاصة بكل عامل."); box.addView(empty);
            } else {
                java.util.Iterator<String> names = workers.keys();
                while (names.hasNext()) {
                    String workerName = names.next(); JSONObject worker = workers.optJSONObject(workerName);
                    TextView workerLabel = new TextView(this); workerLabel.setText("العامل: " + workerName); workerLabel.setTextSize(17); workerLabel.setPadding(0, 12, 0, 4); box.addView(workerLabel);
                    for (int denomination : denominations) {
                        EditText field = new EditText(this); field.setInputType(2); field.setSingleLine(true);
                        field.setHint("حد التنبيه لفئة " + denomination);
                        field.setText(String.valueOf(worker == null ? p.getInt("threshold_" + denomination, 10) : worker.optInt("threshold_" + denomination, p.getInt("threshold_" + denomination, 10))));
                        box.addView(field); workerThresholdInputs.put(workerName + "|" + denomination, field);
                    }
                }
            }
        } catch (Exception ex) {
            TextView error = new TextView(this); error.setText("تعذر قراءة قائمة العمال؛ أعد فتح الصفحة بعد التأكد من حفظ البيانات."); box.addView(error);
        }

        Button save = new Button(this);
        save.setText("حفظ الإعدادات");
        save.setTextSize(17);
        save.setTextColor(android.graphics.Color.WHITE);
        save.setAllCaps(false);
        save.setMinHeight(56);
        save.setBackgroundColor(0xFF147D92);
        save.setOnClickListener(v -> {
            int[] globalLimits = new int[denominations.length];
            Map<String, Integer> workerLimits = new LinkedHashMap<>();
            android.content.SharedPreferences dataPrefs = getSharedPreferences("worker_cards_pro_v24_data", MODE_PRIVATE);
            JSONObject appData;
            JSONObject workers;
            try {
                for (int i = 0; i < denominations.length; i++) {
                    String raw = thresholds[i].getText().toString().trim();
                    globalLimits[i] = raw.isEmpty() ? 0 : Integer.parseInt(raw);
                    if (globalLimits[i] < 0) { thresholds[i].setError("أدخل صفرًا أو رقمًا أكبر"); return; }
                }
                appData = new JSONObject(dataPrefs.getString("data", "{}"));
                workers = appData.optJSONObject("workers");
                for (Map.Entry<String, EditText> entry : workerThresholdInputs.entrySet()) {
                    String[] parts = entry.getKey().split("\\|", 2);
                    if (parts.length != 2 || workers == null || !workers.has(parts[0])) continue;
                    String raw = entry.getValue().getText().toString().trim();
                    int limit = raw.isEmpty() ? 0 : Integer.parseInt(raw);
                    if (limit < 0) { entry.getValue().setError("أدخل صفرًا أو رقمًا أكبر"); return; }
                    workerLimits.put(entry.getKey(), limit);
                }
                if (workers != null) {
                    for (Map.Entry<String, Integer> entry : workerLimits.entrySet()) {
                        String[] parts = entry.getKey().split("\\|", 2);
                        workers.getJSONObject(parts[0]).put("threshold_" + parts[1], entry.getValue());
                    }
                }
            } catch (Exception ex) {
                new android.app.AlertDialog.Builder(this).setTitle("تعذر حفظ الإعدادات")
                        .setMessage("تحقق من جميع حدود التنبيه. يجب إدخال أعداد صحيحة غير سالبة؛ لم تُحفظ أي تغييرات.")
                        .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
                return;
            }

            // Persist only after every field has passed validation to avoid partial settings updates.
            android.content.SharedPreferences.Editor editor = p.edit()
                    .putBoolean(StockSettings.BACKUP_ENABLED, enabled.isChecked());
            for (int i = 0; i < denominations.length; i++) editor.putInt("threshold_" + denominations[i], globalLimits[i]);
            boolean globalSaved = editor.commit();
            boolean workersSaved = workers == null || dataPrefs.edit().putString("data", appData.toString()).commit();
            if (!globalSaved || !workersSaved) {
                new android.app.AlertDialog.Builder(this).setTitle("تعذر حفظ الإعدادات")
                        .setMessage("لم يتم تأكيد حفظ كل الإعدادات. أعد المحاولة.")
                        .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss()).show();
                return;
            }
            StockSettings.scheduleBackup(this);
            Toast.makeText(this, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        pageScroll.addView(box);
        setContentView(pageScroll);
    }
}
