package com.example.cards;
import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity {
 private WebView webView;
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);webView=findViewById(R.id.webView);WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);webView.setWebViewClient(new WebViewClient());webView.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
