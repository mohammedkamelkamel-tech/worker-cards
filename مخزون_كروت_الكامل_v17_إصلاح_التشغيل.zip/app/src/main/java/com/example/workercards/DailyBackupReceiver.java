package com.example.workercards;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DailyBackupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("com.example.workercards.DAILY_BACKUP".equals(intent.getAction())) {
            // تنفيذ النسخة الاحتياطية الموجودة في المشروع.
            // نستخدم نفس آلية DailyBackupReceiver الحالية عند تشغيل الموعد.
            BackupHelper.createBackup(context);
        }
        StockSettings.scheduleBackup(context);
    }
}
