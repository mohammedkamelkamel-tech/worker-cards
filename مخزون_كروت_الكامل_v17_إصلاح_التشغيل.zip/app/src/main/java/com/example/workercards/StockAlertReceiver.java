package com.example.workercards;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class StockAlertReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.example.workercards.STOCK_CHANGED";
    public static final String EXTRA_CATEGORY = "category";
    public static final String EXTRA_REMAINING = "remaining";
    public static final String EXTRA_THRESHOLD = "threshold";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!ACTION.equals(intent.getAction())) return;

        StockSettings.ensureNotificationChannel(context);

        String category = intent.getStringExtra(EXTRA_CATEGORY);
        if (category == null) category = "الكرت";

        int remaining = intent.getIntExtra(EXTRA_REMAINING, -1);
        int threshold = intent.getIntExtra(EXTRA_THRESHOLD,
                context.getSharedPreferences(StockSettings.PREFS, 0)
                        .getInt(StockSettings.DEFAULT_THRESHOLD, 10));

        if (remaining < 0) return;

        // 0 = نفاد كامل، 1..threshold = قرب النفاد.
        if (remaining > threshold) return;

        String title;
        String text;
        if (remaining == 0) {
            title = "🚨 نفاد مخزون الكروت";
            text = "نفد مخزون " + category + " بالكامل.";
        } else {
            title = "🔔 مخزون الكروت منخفض";
            text = "تبقى من " + category + " عدد " + remaining +
                    " كرت، والحد الأدنى المحدد " + threshold + ".";
        }

        android.app.Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new android.app.Notification.Builder(context, "stock_alerts");
        } else {
            builder = new android.app.Notification.Builder(context);
        }

        builder.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new android.app.Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setPriority(android.app.Notification.PRIORITY_HIGH);

        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(("stock_" + category).hashCode(), builder.build());
    }
}
