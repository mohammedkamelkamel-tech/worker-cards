package com.example.workercards;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class BackupHelper {

    private static final String APP_FOLDER = "مخزون كروت الكامل";
    private static final String PREFS = "worker_cards_data_v12";
    private static final String DATA_KEY = "data";
    private static final String CHANNEL_ID = "backup_success";

    public static void createBackup(Context context) {
        try {
            SharedPreferences prefs =
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

            String json = prefs.getString(DATA_KEY, "");
            if (json == null || json.trim().isEmpty()) return;

            String stamp = new SimpleDateFormat(
                    "yyyy-MM-dd_HH-mm-ss",
                    Locale.US
            ).format(new Date());

            String fileName = "backup_" + stamp + ".json";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveWithMediaStore(context, fileName, json);
            } else {
                saveLegacy(context, fileName, json);
            }

            showBackupNotification(context, fileName);

        } catch (Exception ignored) {
        }
    }

    private static void saveWithMediaStore(
            Context context,
            String fileName,
            String json
    ) throws Exception {

        ContentResolver resolver = context.getContentResolver();

        ContentValues values = new ContentValues();
        values.put(
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                fileName
        );
        values.put(
                MediaStore.Files.FileColumns.MIME_TYPE,
                "application/json"
        );

        // مجلد مباشر في جذر الذاكرة الداخلية المشتركة:
        // /storage/emulated/0/مخزون كروت الكامل/
        values.put(
                MediaStore.Files.FileColumns.RELATIVE_PATH,
                APP_FOLDER + "/"
        );

        values.put(
                MediaStore.Files.FileColumns.IS_PENDING,
                1
        );

        Uri uri = resolver.insert(
                MediaStore.Files.getContentUri("external"),
                values
        );

        if (uri == null) return;

        try {
            OutputStream out = resolver.openOutputStream(uri);
            if (out == null) {
                resolver.delete(uri, null, null);
                return;
            }

            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.close();

            ContentValues done = new ContentValues();
            done.put(
                    MediaStore.Files.FileColumns.IS_PENDING,
                    0
            );

            resolver.update(uri, done, null, null);

        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        deleteOldBackups(context);
    }

    private static void saveLegacy(
            Context context,
            String fileName,
            String json
    ) throws Exception {

        File root =
                Environment.getExternalStorageDirectory();

        File folder = new File(root, APP_FOLDER);

        if (!folder.exists() && !folder.mkdirs()) return;

        File out = new File(folder, fileName);

        FileOutputStream fos = new FileOutputStream(out);
        fos.write(json.getBytes(StandardCharsets.UTF_8));
        fos.flush();
        fos.close();

        deleteOldLegacyBackups(folder);
    }

    private static void showBackupNotification(
            Context context,
            String fileName
    ) {

        try {
            NotificationManager nm =
                    (NotificationManager)
                            context.getSystemService(
                                    Context.NOTIFICATION_SERVICE
                            );

            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel =
                        new NotificationChannel(
                                CHANNEL_ID,
                                "النسخ الاحتياطي",
                                NotificationManager.IMPORTANCE_DEFAULT
                        );

                channel.setDescription(
                        "إشعار عند إنشاء نسخة احتياطية تلقائية"
                );

                nm.createNotificationChannel(channel);
            }

            String text =
                    "تم حفظ النسخة الاحتياطية: " + fileName;

            Notification.Builder builder;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(
                        context,
                        CHANNEL_ID
                );
            } else {
                builder = new Notification.Builder(context);
            }

            builder
                    .setSmallIcon(android.R.drawable.ic_menu_save)
                    .setContentTitle("تم أخذ نسخة احتياطية")
                    .setContentText(text)
                    .setStyle(
                            new Notification.BigTextStyle()
                                    .bigText(text)
                    )
                    .setAutoCancel(true)
                    .setPriority(
                            Notification.PRIORITY_DEFAULT
                    );

            nm.notify(
                    (int) (System.currentTimeMillis() & 0x7fffffff),
                    builder.build()
            );

        } catch (Exception ignored) {
        }
    }

    private static void deleteOldBackups(Context context) {

        try {
            ContentResolver resolver =
                    context.getContentResolver();

            Uri collection =
                    MediaStore.Files.getContentUri("external");

            String relativePath =
                    APP_FOLDER + "/";

            String[] projection = {
                    MediaStore.Files.FileColumns._ID,
                    MediaStore.Files.FileColumns.DATE_MODIFIED
            };

            String selection =
                    MediaStore.Files.FileColumns.RELATIVE_PATH
                            + "=? AND "
                            + MediaStore.Files.FileColumns.DISPLAY_NAME
                            + " LIKE ?";

            String[] args = {
                    relativePath,
                    "backup_%.json"
            };

            ArrayList<BackupItem> items =
                    new ArrayList<>();

            android.database.Cursor cursor =
                    resolver.query(
                            collection,
                            projection,
                            selection,
                            args,
                            MediaStore.Files.FileColumns.DATE_MODIFIED
                                    + " ASC"
                    );

            if (cursor != null) {

                int idIndex = cursor.getColumnIndex(
                        MediaStore.Files.FileColumns._ID
                );

                int dateIndex = cursor.getColumnIndex(
                        MediaStore.Files.FileColumns.DATE_MODIFIED
                );

                while (cursor.moveToNext()) {
                    items.add(
                            new BackupItem(
                                    cursor.getLong(idIndex),
                                    cursor.getLong(dateIndex)
                            )
                    );
                }

                cursor.close();
            }

            while (items.size() > 30) {
                BackupItem old = items.remove(0);

                Uri oldUri = Uri.withAppendedPath(
                        collection,
                        String.valueOf(old.id)
                );

                resolver.delete(oldUri, null, null);
            }

        } catch (Exception ignored) {
        }
    }

    private static void deleteOldLegacyBackups(File folder) {

        File[] backups =
                folder.listFiles(
                        (dir, name) ->
                                name.startsWith("backup_")
                                        && name.endsWith(".json")
                );

        if (backups == null || backups.length <= 30) return;

        Arrays.sort(
                backups,
                (a, b) ->
                        Long.compare(
                                a.lastModified(),
                                b.lastModified()
                        )
        );

        for (int i = 0; i < backups.length - 30; i++) {
            backups[i].delete();
        }
    }

    private static class BackupItem {
        long id;
        long date;

        BackupItem(long id, long date) {
            this.id = id;
            this.date = date;
        }
    }
}
