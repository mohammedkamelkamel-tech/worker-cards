package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS = "worker_cards_data_v12";
    private static final int CREATE_BACKUP = 1001;
    private static final int RESTORE_BACKUP = 1002;
    private final int[] DENOMS = {100, 200, 250, 500};

    private SharedPreferences prefs;
    private JSONObject data;
    private String selectedWorker = "";
    private LinearLayout workersContainer;
    private EditText[] stockInputs = new EditText[4];
    private EditText messageInput;
    private TextView resultText;
    private TextView selectedText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadData();
        buildUi();
    }

    private void loadData() {
        try {
            String saved = prefs.getString("data", "");
            if (saved.isEmpty()) {
                data = new JSONObject();
                JSONObject stock = new JSONObject();
                stock.put("100", 2000); stock.put("200", 2000);
                stock.put("250", 2000); stock.put("500", 1000);
                JSONObject workers = new JSONObject();
                JSONObject mohammed = new JSONObject();
                mohammed.put("100", 432); mohammed.put("200", 1000);
                mohammed.put("250", 1000); mohammed.put("500", 100);
                workers.put("محمد ثابت", mohammed);
                data.put("stock", stock);
                data.put("workers", workers);
            } else {
                data = new JSONObject(saved);
            }
            if (data.optJSONObject("stock") == null) data.put("stock", new JSONObject());
            if (data.optJSONObject("workers") == null) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = new JSONObject();
        }
    }

    private void saveData() {
        prefs.edit().putString("data", data.toString()).apply();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(0xFF222222);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(50));
        b.setBackgroundColor(color);
        return b;
    }

    private EditText numberInput(int value) {
        EditText e = new EditText(this);
        e.setText(String.valueOf(value));
        e.setTextSize(18);
        e.setGravity(Gravity.CENTER);
        e.setInputType(2);
        e.setSingleLine(true);
        e.setPadding(dp(4), dp(8), dp(4), dp(8));
        e.setIncludeFontPadding(true);
        return e;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(10), dp(10), dp(10), dp(10));
        l.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(5), dp(6), dp(5), dp(6));
        l.setLayoutParams(p);
        return l;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return r;
    }

    private void addCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(v, p);
    }

    // Larger cell used for denomination label + amount so neither is clipped at the top.
    private void addCategoryCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(118), 1f);
        p.setMargins(dp(3), dp(7), dp(3), dp(7));
        row.addView(v, p);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6F8);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(5), dp(5), dp(5), dp(12));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.workercards.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setContentDescription("شعار شبكة الكامل");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(190));
        logoParams.setMargins(dp(8), dp(4), dp(8), dp(0));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(logo, logoParams);

        TextView header = title("إدارة كروت العامل", 30);
        header.setGravity(Gravity.CENTER);
        content.addView(header, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView sub = new TextView(this);
        sub.setText("تطبيق Android أصلي لإدارة المخزون والعمال والخصم");
        sub.setTextSize(18); sub.setTextColor(0xFF666666);
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,0,0,dp(10));
        content.addView(sub);

        // Backup
        LinearLayout backup = box();
        backup.addView(title("النسخ الاحتياطي والاستعادة", 25));
        TextView info = new TextView(this);
        info.setText("البيانات محفوظة داخل التطبيق. يمكنك تصدير نسخة احتياطية واستعادتها لاحقًا.");
        info.setTextSize(16); info.setTextColor(0xFF666666);
        info.setGravity(Gravity.RIGHT); info.setPadding(0,0,0,dp(6));
        backup.addView(info);
        LinearLayout br = row();
        Button export = button("تصدير نسخة", 0xFF16833A);
        Button restore = button("استعادة نسخة", 0xFF1976D2);
        addCell(br, export); addCell(br, restore);
        backup.addView(br);
        export.setOnClickListener(v -> exportBackup());
        restore.setOnClickListener(v -> restoreBackup());
        content.addView(backup);

        // General stock
        LinearLayout stockBox = box();
        stockBox.addView(title("المخزون العام", 27));
        LinearLayout r1 = row(), r2 = row();
        for (int i = 0; i < 4; i++) {
            int val = data.optJSONObject("stock").optInt(String.valueOf(DENOMS[i]), 0);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(18); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            lab.setGravity(Gravity.CENTER);
            stockInputs[i] = numberInput(val);
            cell.addView(lab);
            cell.addView(stockInputs[i], new LinearLayout.LayoutParams(-1, dp(58)));
            if (i < 2) addCategoryCell(r1, cell); else addCategoryCell(r2, cell);
        }
        stockBox.addView(r1); stockBox.addView(r2);
        Button saveStock = button("حفظ المخزون العام", 0xFF16833A);
        saveStock.setOnClickListener(v -> saveGeneralStock());
        stockBox.addView(saveStock);
        content.addView(stockBox);

        // Workers
        LinearLayout workerBox = box();
        workerBox.addView(title("العمال ومخزون الكروت الخاص بهم", 27));
        TextView wi = new TextView(this);
        wi.setText("كل عامل له مخزون مستقل من كروت 100 و200 و250 و500. يمكنك إضافة عامل وتعديل مخزونه وحفظه في أي وقت.");
        wi.setTextSize(16); wi.setTextColor(0xFF666666); wi.setGravity(Gravity.RIGHT);
        workerBox.addView(wi);

        Button addWorker = button("＋ إضافة عامل جديد", 0xFF1976D2);
        addWorker.setOnClickListener(v -> showAddWorkerDialog());
        workerBox.addView(addWorker);

        selectedText = new TextView(this);
        selectedText.setTextSize(18); selectedText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selectedText.setTextColor(0xFF1976D2); selectedText.setPadding(dp(5),dp(10),dp(5),dp(5));
        selectedText.setGravity(Gravity.RIGHT);
        workerBox.addView(selectedText);

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        workersContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        workerBox.addView(workersContainer);
        content.addView(workerBox);

        // Message
        LinearLayout msgBox = box();
        msgBox.addView(title("رسالة العامل", 27));
        TextView hint = new TextView(this);
        hint.setText("اختر العامل، ثم الصق الرسالة كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500\n\nمثال:\n1-2-3-4\n2-1-0-3");
        hint.setTextSize(17); hint.setTextColor(0xFF666666); hint.setGravity(Gravity.RIGHT);
        msgBox.addView(hint);
        messageInput = new EditText(this);
        messageInput.setTextSize(18);
        messageInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        messageInput.setHint("الصق رسالة العامل هنا");
        messageInput.setMinLines(7);
        messageInput.setInputType(1 | 0x00008000);
        msgBox.addView(messageInput, new LinearLayout.LayoutParams(-1, dp(190)));
        Button calc = button("احسب وخصم", 0xFF1976D2);
        calc.setOnClickListener(v -> calculateAndDeduct());
        msgBox.addView(calc);
        content.addView(msgBox);

        LinearLayout resultBox = box();
        resultBox.addView(title("النتيجة", 25));
        resultText = new TextView(this);
        resultText.setText("—");
        resultText.setTextSize(17); resultText.setGravity(Gravity.RIGHT);
        resultText.setPadding(dp(5),dp(5),dp(5),dp(5));
        resultBox.addView(resultText);
        content.addView(resultBox);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        renderWorkers();
        updateSelectedText();
    }

    private void saveGeneralStock() {
        try {
            JSONObject stock = data.getJSONObject("stock");
            for (int i=0;i<4;i++) stock.put(String.valueOf(DENOMS[i]), Math.max(0, parse(stockInputs[i])));
            saveData();
            result("تم حفظ المخزون العام بنجاح.", true);
        } catch(Exception e) { result("حدث خطأ أثناء حفظ المخزون.", false); }
    }

    private int parse(EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch(Exception ex) { return 0; }
    }

    private void showAddWorkerDialog() {
        final EditText name = new EditText(this);
        name.setHint("مثال: أحمد محمد");
        name.setTextSize(18);
        name.setGravity(Gravity.RIGHT);
        name.setSingleLine(true);
        name.setPadding(dp(10),dp(5),dp(10),dp(5));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("إضافة عامل جديد")
                .setMessage("اكتب اسم العامل. سيتم إنشاء مخزون 0 لكل الفئات.")
                .setView(name)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إضافة", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("اكتب اسم العامل"); return; }
            try {
                JSONObject workers = data.getJSONObject("workers");
                if (workers.has(n)) {
                    selectedWorker = n;
                    saveData(); renderWorkers(); updateSelectedText();
                    result("العامل موجود مسبقًا، تم اختياره: " + n, true);
                    d.dismiss();
                    return;
                }
                JSONObject w = new JSONObject();
                for (int den : DENOMS) w.put(String.valueOf(den), 0);
                workers.put(n, w);
                selectedWorker = n;
                saveData(); renderWorkers(); updateSelectedText();
                result("تمت إضافة العامل «" + n + "» ومخزونه جاهز للتعبئة.", true);
                d.dismiss();
            } catch(Exception e) { result("تعذر إضافة العامل.", false); }
        }));
        d.show();
    }

    private void renderWorkers() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            JSONArray names = workers.names();
            if (names == null || names.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("لا يوجد عمال. اضغط «إضافة عامل جديد».");
                empty.setTextSize(17); empty.setPadding(dp(5),dp(12),dp(5),dp(12));
                workersContainer.addView(empty);
                return;
            }
            for (int x=0; x<names.length(); x++) {
                String name = names.getString(x);
                JSONObject w = workers.getJSONObject(name);
                addWorkerCard(name, w);
            }
        } catch(Exception ignored) {}
    }

    private void addWorkerCard(String name, JSONObject w) {
        LinearLayout card = box();
        card.setPadding(dp(10),dp(10),dp(10),dp(10));

        TextView nameTv = title(name, 23);
        card.addView(nameTv);

        Button use = button(selectedWorker.equals(name) ? "✓ العامل المختار" : "اختيار هذا العامل", 0xFF1976D2);
        use.setOnClickListener(v -> {
            selectedWorker = name;
            updateSelectedText();
            renderWorkers();
            result("تم اختيار العامل: " + name, true);
        });
        card.addView(use);

        LinearLayout rr1 = row(), rr2 = row();
        for (int i=0;i<4;i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(16); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD); lab.setGravity(Gravity.CENTER);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            EditText inp = numberInput(w.optInt(String.valueOf(DENOMS[i]),0));
            cell.addView(lab);
            cell.addView(inp, new LinearLayout.LayoutParams(-1,dp(58)));
            cell.setTag(inp);
            if(i<2) addCategoryCell(rr1,cell); else addCategoryCell(rr2,cell);
        }
        card.addView(rr1); card.addView(rr2);

        Button save = button("حفظ مخزون هذا العامل", 0xFF16833A);
        save.setOnClickListener(v -> {
            try {
                LinearLayout[] rows = {rr1, rr2};
                JSONObject nw = new JSONObject();
                int idx=0;
                for(LinearLayout row: rows) {
                    for(int j=0;j<row.getChildCount();j++) {
                        LinearLayout cell=(LinearLayout)row.getChildAt(j);
                        EditText inp=(EditText)cell.getTag();
                        nw.put(String.valueOf(DENOMS[idx++]), Math.max(0,parse(inp)));
                    }
                }
                data.getJSONObject("workers").put(name,nw);
                saveData(); renderWorkers();
                result("تم حفظ مخزون العامل «"+name+"».",true);
            } catch(Exception e) { result("تعذر حفظ مخزون العامل.",false); }
        });
        card.addView(save);

        LinearLayout actions = row();
        Button del = button("حذف العامل", 0xFFC62828);
        del.setOnClickListener(v -> confirmDelete(name));
        addCell(actions, del);
        Button choose = button("اختيار العامل", 0xFF1976D2);
        choose.setOnClickListener(v -> {
            selectedWorker=name; updateSelectedText(); renderWorkers();
            result("تم اختيار العامل: "+name,true);
        });
        addCell(actions, choose);
        card.addView(actions);

        workersContainer.addView(card);
    }

    private void confirmDelete(String name) {
        if (name.equals(selectedWorker)) selectedWorker = "";
        new AlertDialog.Builder(this)
                .setTitle("حذف العامل")
                .setMessage("هل تريد حذف «"+name+"» ومخزونه؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d,w) -> {
                    try {
                        data.getJSONObject("workers").remove(name);
                        saveData(); renderWorkers(); updateSelectedText();
                        result("تم حذف العامل.", true);
                    } catch(Exception e) { result("تعذر حذف العامل.", false); }
                }).show();
    }

    private void updateSelectedText() {
        if (selectedText != null)
            selectedText.setText(selectedWorker.isEmpty() ? "العامل المختار: لا يوجد" : "العامل المختار: " + selectedWorker);
    }

    private void calculateAndDeduct() {
        String name = selectedWorker;
        if (name.isEmpty()) {
            result("اختر العامل أولًا.", false); return;
        }

        String text = messageInput.getText().toString();
        Pattern linePattern = Pattern.compile("^\\s*(.*?)\\s+(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*$");
        Pattern numbersOnly = Pattern.compile("^\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*$");

        int[] used = {0,0,0,0};
        int count = 0;
        StringBuilder verticalUsed = new StringBuilder();

        String[] lines = text.split("\\r?\\n");
        for (String raw : lines) {
            String line = raw.replace("……", "").replace("...", "").trim();
            if (line.isEmpty()) continue;

            Matcher lm = linePattern.matcher(line);
            String customer = null;
            Matcher nm = numbersOnly.matcher(line);
            Matcher m;

            if (lm.matches()) {
                customer = lm.group(1).trim();
                m = lm;
            } else if (nm.matches()) {
                m = nm;
            } else {
                continue;
            }

            count++;
            int[] row = new int[4];
            for (int i=0; i<4; i++) {
                // named line: groups 2..5 are the four quantities
                // numbers-only line: groups 1..4 are the four quantities
                int group = (customer != null) ? (i + 2) : (i + 1);
                row[i] = Integer.parseInt(m.group(group));
                used[i] += row[i];
            }

            // كتابة الكروت المستخدمة بشكل عمودي لكل اسم
            if (customer != null && !customer.isEmpty()) {
                verticalUsed.append("<b>").append(customer).append("</b><br>");
                verticalUsed.append("100 : ").append(row[0]).append("<br>");
                verticalUsed.append("200 : ").append(row[1]).append("<br>");
                verticalUsed.append("250 : ").append(row[2]).append("<br>");
                verticalUsed.append("500 : ").append(row[3]).append("<br><br>");
            }
        }

        if(count==0) {
            result("لم أجد أي سطر صحيح. اكتب كل عميل بهذا الشكل:<br>اسم العميل 24-9-0-0", false);
            return;
        }

        try {
            JSONObject workers=data.getJSONObject("workers");
            JSONObject w=workers.getJSONObject(name);
            JSONObject stock=data.getJSONObject("stock");
            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                int wb=w.optInt(k,0), sb=stock.optInt(k,0);
                if(used[i]>wb) {
                    result("رصيد العامل غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+wb+"، ولم يتم الخصم.",false);
                    return;
                }
                if(used[i]>sb) {
                    result("المخزون العام غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+sb+"، ولم يتم الخصم.",false);
                    return;
                }
            }

            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                w.put(k,w.optInt(k,0)-used[i]);
                stock.put(k,stock.optInt(k,0)-used[i]);
            }

            saveData();
            renderWorkers();

            StringBuilder s=new StringBuilder();
            s.append("تم الخصم بنجاح<br><br>");
            s.append("<b>الكروت المستخدمة:</b><br><br>");
            if (verticalUsed.length() > 0) {
                s.append(verticalUsed);
            } else {
                s.append("100 : ").append(used[0]).append("<br>");
                s.append("200 : ").append(used[1]).append("<br>");
                s.append("250 : ").append(used[2]).append("<br>");
                s.append("500 : ").append(used[3]).append("<br><br>");
            }
            s.append("عدد الأسطر: ").append(count).append("<br><br>");
            s.append("الإجمالي:<br>");
            s.append("100 : ").append(used[0]).append("<br>");
            s.append("200 : ").append(used[1]).append("<br>");
            s.append("250 : ").append(used[2]).append("<br>");
            s.append("500 : ").append(used[3]);
            result(s.toString(),true);
        } catch(Exception e) { result("حدث خطأ أثناء الخصم.",false); }
    }

    private void result(String text, boolean ok) {
        if(resultText==null)return;
        resultText.setText(android.text.Html.fromHtml(text));
        resultText.setTextColor(ok?0xFF16833A:0xFFC62828);
    }

    private void exportBackup() {
        try {
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"نسخة_احتياطية_كروت_العامل.json");
            startActivityForResult(i,CREATE_BACKUP);
        } catch(Exception e){ result("تعذر فتح حفظ النسخة.",false); }
    }

    private void restoreBackup() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,RESTORE_BACKUP);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent intent) {
        super.onActivityResult(requestCode,resultCode,intent);
        if(resultCode!=RESULT_OK || intent==null || intent.getData()==null)return;
        Uri uri=intent.getData();
        try {
            if(requestCode==CREATE_BACKUP) {
                OutputStream out=getContentResolver().openOutputStream(uri);
                out.write(data.toString(2).getBytes(StandardCharsets.UTF_8)); out.close();
                result("تم تصدير النسخة الاحتياطية بنجاح.",true);
            } else if(requestCode==RESTORE_BACKUP) {
                InputStream in=getContentResolver().openInputStream(uri);
                ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] buf=new byte[4096]; int n;
                while((n=in.read(buf))!=-1)b.write(buf,0,n);
                in.close();
                JSONObject restored=new JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));
                if(restored.optJSONObject("stock")==null || restored.optJSONObject("workers")==null)
                    throw new Exception("invalid");
                data=restored; selectedWorker="";
                saveData(); buildUi();
                result("تمت استعادة البيانات بنجاح.",true);
            }
        } catch(Exception e) { result("ملف النسخة الاحتياطية غير صالح أو تعذر قراءته.",false); }
    }
}
