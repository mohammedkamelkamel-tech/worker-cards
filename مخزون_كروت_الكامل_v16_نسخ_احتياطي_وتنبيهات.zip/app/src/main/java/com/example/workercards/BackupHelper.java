package com.example.workercards;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BackupHelper {
    public static void createBackup(Context context) {
        try {
            File source = context.getFilesDir();
            File backupRoot = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                    "مخزون كروت الكامل/النسخ الاحتياطية");

            if (!backupRoot.exists() && !backupRoot.mkdirs()) return;

            String stamp = new SimpleDateFormat(
                    "yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());

            File out = new File(backupRoot, "backup_" + stamp + ".zip");
            zipDirectory(source, out);

            File[] backups = backupRoot.listFiles(
                    (d, n) -> n.startsWith("backup_") && n.endsWith(".zip"));

            if (backups != null && backups.length > 30) {
                java.util.Arrays.sort(
                        backups, (a,b) -> Long.compare(a.lastModified(), b.lastModified()));
                for (int i = 0; i < backups.length - 30; i++) backups[i].delete();
            }
        } catch (Exception ignored) {}
    }

    private static void zipDirectory(File dir, File out) throws Exception {
        java.util.zip.ZipOutputStream zos =
                new java.util.zip.ZipOutputStream(new FileOutputStream(out));
        addToZip(dir, dir, zos);
        zos.close();
    }

    private static void addToZip(
            File root, File file, java.util.zip.ZipOutputStream zos) throws Exception {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) addToZip(root, child, zos);
            return;
        }

        String name = root.toURI().relativize(file.toURI()).getPath();
        zos.putNextEntry(new java.util.zip.ZipEntry(name));

        FileInputStream in = new FileInputStream(file);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        in.close();
        zos.closeEntry();
    }
}
