package com.example.workercards;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DailyBackupReceiver extends BroadcastReceiver {
    private static final int REQ = 4040;
    private static final String CHANNEL = "daily_backup";

    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                && !"com.example.workercards.DAILY_BACKUP".equals(intent.getAction())) return;

        if ("com.example.workercards.DAILY_BACKUP".equals(intent.getAction())) {
            createBackup(context);
        }
        schedule(context);
    }

    public static void schedule(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        Intent i = new Intent(context, DailyBackupReceiver.class);
        i.setAction("com.example.workercards.DAILY_BACKUP");
        PendingIntent pi = PendingIntent.getBroadcast(
                context, REQ, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, 4);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        }
    }

    private static void createBackup(Context context) {
        try {
            File source = context.getFilesDir();
            File backupRoot = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                    "إدارة كروت العامل/النسخ الاحتياطية");
            if (!backupRoot.exists() && !backupRoot.mkdirs()) return;

            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
            File out = new File(backupRoot, "backup_" + stamp + ".zip");

            zipDirectory(source, out);

            // Keep the 30 newest backups.
            File[] backups = backupRoot.listFiles((d, n) -> n.startsWith("backup_") && n.endsWith(".zip"));
            if (backups != null && backups.length > 30) {
                java.util.Arrays.sort(backups, (a,b) -> Long.compare(a.lastModified(), b.lastModified()));
                for (int x = 0; x < backups.length - 30; x++) backups[x].delete();
            }
        } catch (Exception ignored) {
        }
    }

    private static void zipDirectory(File dir, File out) throws Exception {
        java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(new FileOutputStream(out));
        addToZip(dir, dir, zos);
        zos.close();
    }

    private static void addToZip(File root, File file, java.util.zip.ZipOutputStream zos) throws Exception {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) addToZip(root, child, zos);
            return;
        }
        String name = root.toURI().relativize(file.toURI()).getPath();
        zos.putNextEntry(new java.util.zip.ZipEntry(name));
        FileInputStream in = new FileInputStream(file);
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
        in.close();
        zos.closeEntry();
    }
}
