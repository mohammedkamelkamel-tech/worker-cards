package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.net.Uri;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final String PREFS = "worker_cards_native";
    private static final String DATA_KEY = "data";
    private final int[] DENOMS = {100, 200, 250, 500};
    private static final int REQUEST_EXPORT = 7001;
    private static final int REQUEST_IMPORT = 7002;

    private JSONObject data;
    private LinearLayout root, workersContainer;
    private EditText workerName, message;
    private TextView result;
    private final int blue = Color.rgb(25, 118, 210);
    private final int green = Color.rgb(22, 131, 58);
    private final int red = Color.rgb(198, 40, 40);
    private final int dark = Color.rgb(35, 35, 35);
    private final int gray = Color.rgb(90, 90, 90);
    private final int bg = Color.rgb(245, 247, 250);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(blue);
        loadData();
        buildUi();
        renderAll();
    }

    private void loadData() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = p.getString(DATA_KEY, null);
        try {
            data = raw == null ? defaultData() : new JSONObject(raw);
            if (!data.has("stock")) data.put("stock", new JSONObject());
            if (!data.has("workers")) data.put("workers", new JSONObject());
        } catch (Exception e) { data = defaultData(); }
    }

    private JSONObject defaultData() {
        JSONObject d = new JSONObject();
        try {
            JSONObject s = new JSONObject();
            s.put("100", 2000); s.put("200", 2000); s.put("250", 2000); s.put("500", 1000);
            JSONObject w = new JSONObject();
            JSONObject mw = new JSONObject();
            mw.put("100", 432); mw.put("200", 1000); mw.put("250", 1000); mw.put("500", 100);
            w.put("محمد ثابت", mw);
            d.put("stock", s); d.put("workers", w);
        } catch (Exception ignored) {}
        return d;
    }

    private void saveData() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(DATA_KEY, data.toString()).apply();
    }

    private Typeface normalFont() { return Typeface.create("sans-serif", Typeface.NORMAL); }
    private Typeface mediumFont() { return Typeface.create("sans-serif-medium", Typeface.NORMAL); }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(bold ? mediumFont() : normalFont());
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        t.setPadding(18, 14, 18, 14);
        t.setIncludeFontPadding(true);
        t.setLineSpacing(2f, 1.05f);
        t.setMinHeight((int)(size * 2.0f));
        return t;
    }

    private EditText edit(String value, String hint, int inputType) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(18);
        e.setTextColor(dark);
        e.setHintTextColor(Color.rgb(145,145,145));
        e.setInputType(inputType);
        e.setTypeface(normalFont());
        e.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_RTL);
        e.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        e.setPadding(16, 12, 16, 12);
        e.setIncludeFontPadding(true);
        e.setSingleLine(true);
        e.setBackgroundColor(Color.WHITE);
        return e;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTypeface(mediumFont());
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(60);
        b.setPadding(8, 0, 8, 0);
        b.setBackgroundColor(color);
        return b;
    }

    private LinearLayout section(String title) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(10, 10, 10, 12);
        box.setBackgroundColor(Color.WHITE);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView h = tv(title, 25, dark, true);
        h.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        h.setMinHeight(60);
        box.addView(h, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(7, 7, 7, 7);
        root.addView(box, lp);
        return box;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(0, 12, 0, 36);
        root.setBackgroundColor(bg);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void renderAll() {
        root.removeAllViews();

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(12, 12, 12, 12);
        header.setBackgroundColor(Color.WHITE);

        TextView h = tv("إدارة كروت العامل", 30, dark, true);
        h.setGravity(Gravity.CENTER);
        h.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        h.setMinHeight(68);
        header.addView(h, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = tv("تطبيق Android أصلي لإدارة المخزون والعمال والخصم", 16, gray, false);
        sub.setGravity(Gravity.CENTER);
        sub.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        sub.setMinHeight(48);
        header.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        renderBackup();
        renderStock();
        renderWorkers();
        renderMessage();
        renderResult();
    }

    private void renderBackup() {
        LinearLayout box = section("النسخ الاحتياطي والاستعادة");
        TextView info = tv("البيانات محفوظة داخل التطبيق. صدّر نسخة احتياطية واحفظها في مكان آمن، ويمكنك استعادتها لاحقًا.", 15, gray, false);
        info.setGravity(Gravity.RIGHT);
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        Button export = button("تصدير نسخة", green);
        export.setOnClickListener(v -> exportBackup());
        Button importBtn = button("استعادة نسخة", blue);
        importBtn.setOnClickListener(v -> importBackup());

        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, 62, 1);
        p1.setMargins(4, 5, 4, 5);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, 62, 1);
        p2.setMargins(4, 5, 4, 5);
        row.addView(export, p1); row.addView(importBtn, p2);
        box.addView(row);
    }

    private void exportBackup() {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "worker_cards_backup.json");
            startActivityForResult(intent, REQUEST_EXPORT);
        } catch (Exception e) { show("تعذر فتح حفظ النسخة الاحتياطية."); }
    }

    private void importBackup() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            startActivityForResult(intent, REQUEST_IMPORT);
        } catch (Exception e) { show("تعذر فتح اختيار النسخة الاحتياطية."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (resultCode != RESULT_OK || intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        if (requestCode == REQUEST_EXPORT) {
            try {
                java.io.OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new Exception();
                out.write(data.toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.close();
                show("تم حفظ النسخة الاحتياطية بنجاح.");
            } catch (Exception e) { show("تعذر حفظ النسخة الاحتياطية."); }
        } else if (requestCode == REQUEST_IMPORT) {
            try {
                java.io.InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception();
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] bytes = new byte[4096]; int n;
                while ((n = in.read(bytes)) != -1) buffer.write(bytes, 0, n);
                in.close();
                JSONObject restored = new JSONObject(new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
                if (!restored.has("stock") || !restored.has("workers")) throw new Exception();
                data = restored; saveData(); renderAll(); show("تمت استعادة البيانات بنجاح.");
            } catch (Exception e) { show("الملف غير صالح أو تالف. لم يتم تغيير البيانات."); }
        }
    }

    private void renderStock() {
        LinearLayout box = section("المخزون العام");
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // 2 x 2 keeps every field wide enough on a phone.
        for (int row = 0; row < 2; row++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for (int col = 0; col < 2; col++) {
                int d = DENOMS[row * 2 + col];
                LinearLayout cell = cardCell();
                TextView label = tv("فئة " + d, 18, dark, true);
                label.setGravity(Gravity.CENTER);
                EditText e = edit(String.valueOf(getStock(d)), "الكمية", InputType.TYPE_CLASS_NUMBER);
                e.setGravity(Gravity.CENTER);
                e.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                e.setTag("stock_" + d);
                label.setMinHeight(46);
                cell.addView(label, new LinearLayout.LayoutParams(-1, -2));
                cell.addView(e, new LinearLayout.LayoutParams(-1, 64));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
                cp.setMargins(5, 5, 5, 5);
                r.addView(cell, cp);
            }
            grid.addView(r);
        }
        box.addView(grid);
        Button save = button("حفظ المخزون العام", green);
        save.setOnClickListener(v -> saveStock());
        box.addView(save, new LinearLayout.LayoutParams(-1, 62));
    }

    private LinearLayout cardCell() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(5, 4, 5, 4);
        c.setBackgroundColor(Color.rgb(250,250,250));
        return c;
    }

    private int getStock(int d) {
        try { return data.getJSONObject("stock").optInt(String.valueOf(d), 0); }
        catch (Exception e) { return 0; }
    }

    private void saveStock() {
        try {
            for (int d : DENOMS) {
                EditText e = root.findViewWithTag("stock_" + d);
                String text = e.getText().toString().trim();
                if (text.isEmpty()) throw new Exception();
                data.getJSONObject("stock").put(String.valueOf(d), Math.max(0, Integer.parseInt(text)));
            }
            saveData(); show("تم حفظ المخزون العام.");
        } catch (Exception ex) { show("تأكد من إدخال أرقام صحيحة."); }
    }

    private void renderWorkers() {
        LinearLayout box = section("العمال ومخزون الكروت الخاص بهم");

        TextView info = tv("كل عامل له مخزون مستقل من كروت 100 و200 و250 و500. يمكنك تعديله وحفظه في أي وقت.", 15, gray, false);
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        workerName = edit("", "اسم العامل الجديد", InputType.TYPE_CLASS_TEXT);
        workerName.setVisibility(View.GONE); // Addition is done through a clear dialog.
        box.addView(workerName, new LinearLayout.LayoutParams(-1, 1));

        Button add = button("إضافة عامل جديد", blue);
        add.setOnClickListener(v -> addWorkerDialog());
        box.addView(add, new LinearLayout.LayoutParams(-1, 62));

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        workersContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.addView(workersContainer);
        renderWorkerList();
    }

    private void addWorkerDialog() {
        final EditText input = edit("", "اكتب اسم العامل", InputType.TYPE_CLASS_TEXT);
        input.setSelectAllOnFocus(false);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(20, 5, 20, 0);
        wrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        wrap.addView(input, new LinearLayout.LayoutParams(-1, 70));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("إضافة عامل جديد")
                .setView(wrap)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إضافة", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("اكتب اسم العامل"); return; }
            try {
                JSONObject workers = data.getJSONObject("workers");
                if (workers.has(name)) { input.setError("العامل موجود بالفعل"); return; }
                JSONObject w = new JSONObject();
                for (int d : DENOMS) w.put(String.valueOf(d), 0);
                workers.put(name, w);
                saveData();
                workerName.setText(name);
                renderWorkerList();
                dialog.dismiss();
                show("تمت إضافة العامل: " + name);
            } catch (Exception e) { input.setError("تعذر إضافة العامل"); }
        }));
        dialog.show();
    }

    private void renderWorkerList() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            Iterator<String> it = workers.keys();
            while (it.hasNext()) {
                String name = it.next();
                JSONObject w = workers.getJSONObject(name);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(10, 10, 10, 10);
                card.setBackgroundColor(Color.rgb(250,250,250));

                TextView n = tv(name, 22, dark, true);
                n.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
                n.setMinHeight(56);
                card.addView(n, new LinearLayout.LayoutParams(-1, -2));

                TextView balanceTitle = tv("مخزون هذا العامل", 15, gray, false);
                balanceTitle.setMinHeight(42);
                card.addView(balanceTitle, new LinearLayout.LayoutParams(-1, -2));

                LinearLayout grid = new LinearLayout(this);
                grid.setOrientation(LinearLayout.VERTICAL);
                grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                EditText[] fields = new EditText[4];

                for (int row = 0; row < 2; row++) {
                    LinearLayout r = new LinearLayout(this);
                    r.setOrientation(LinearLayout.HORIZONTAL);
                    r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                    for (int col = 0; col < 2; col++) {
                        int i = row * 2 + col;
                        int d = DENOMS[i];
                        LinearLayout cell = cardCell();
                        TextView lab = tv("فئة " + d, 16, dark, true);
                        lab.setGravity(Gravity.CENTER);
                        EditText e = edit(String.valueOf(w.optInt(String.valueOf(d), 0)), "عدد الكروت", InputType.TYPE_CLASS_NUMBER);
                        e.setGravity(Gravity.CENTER);
                        e.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        e.setTag("worker_" + safeTag(name) + "_" + d);
                        fields[i] = e;
                        lab.setMinHeight(42);
                        cell.addView(lab, new LinearLayout.LayoutParams(-1, -2));
                        cell.addView(e, new LinearLayout.LayoutParams(-1, 62));
                        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1);
                        cp.setMargins(4, 4, 4, 4);
                        r.addView(cell, cp);
                    }
                    grid.addView(r);
                }
                card.addView(grid);

                Button saveCards = button("حفظ مخزون هذا العامل", green);
                saveCards.setOnClickListener(v -> saveWorkerCards(name, fields));
                card.addView(saveCards, new LinearLayout.LayoutParams(-1, 60));

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                Button use = button("اختيار العامل", blue);
                use.setOnClickListener(v -> {
                    workerName.setText(name);
                    if (message != null) message.requestFocus();
                    show("تم اختيار العامل: " + name);
                });
                Button del = button("حذف العامل", red);
                del.setOnClickListener(v -> deleteWorker(name));
                LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, 58, 1);
                ap.setMargins(4, 4, 4, 4);
                actions.addView(use, ap);
                LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, 58, 1);
                dp.setMargins(4, 4, 4, 4);
                actions.addView(del, dp);
                card.addView(actions);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, 10, 0, 10);
                workersContainer.addView(card, lp);
            }
        } catch (Exception ignored) {}
    }

    private String safeTag(String name) { return Integer.toHexString(name.hashCode()); }

    private void saveWorkerCards(String name, EditText[] fields) {
        try {
            JSONObject w = data.getJSONObject("workers").getJSONObject(name);
            for (int i = 0; i < DENOMS.length; i++) {
                String s = fields[i].getText().toString().trim();
                if (s.isEmpty()) throw new Exception();
                w.put(String.valueOf(DENOMS[i]), Math.max(0, Integer.parseInt(s)));
            }
            saveData(); renderWorkerList(); show("تم حفظ مخزون العامل: " + name);
        } catch (Exception e) { show("تأكد من إدخال أعداد صحيحة للكروت."); }
    }

    private void deleteWorker(String name) {
        new AlertDialog.Builder(this)
                .setTitle("حذف العامل")
                .setMessage("هل تريد حذف العامل «" + name + "» ومخزونه؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d, w) -> {
                    try {
                        data.getJSONObject("workers").remove(name);
                        saveData();
                        if (workerName != null && workerName.getText().toString().trim().equals(name)) workerName.setText("");
                        renderWorkerList(); show("تم حذف العامل: " + name);
                    } catch (Exception e) { show("تعذر حذف العامل."); }
                }).show();
    }

    private void renderMessage() {
        LinearLayout box = section("رسالة العامل");
        TextView info = tv("اختر العامل، ثم الصق رسالة العامل كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500", 16, gray, false);
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        message = new EditText(this);
        message.setHint("مثال:\n1-2-3-4\n2-1-0-3");
        message.setTextSize(17);
        message.setTextColor(dark);
        message.setHintTextColor(Color.rgb(145,145,145));
        message.setGravity(Gravity.TOP | Gravity.RIGHT);
        message.setTextDirection(View.TEXT_DIRECTION_RTL);
        message.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
        message.setMinLines(8);
        message.setPadding(16, 14, 16, 14);
        message.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        box.addView(message, new LinearLayout.LayoutParams(-1, 240));

        Button calc = button("احسب وخصم من العامل", green);
        calc.setOnClickListener(v -> calculate());
        box.addView(calc, new LinearLayout.LayoutParams(-1, 64));
    }

    private void renderResult() {
        LinearLayout box = section("النتيجة");
        result = tv("—", 17, dark, false);
        result.setGravity(Gravity.RIGHT | Gravity.TOP);
        result.setTextDirection(View.TEXT_DIRECTION_RTL);
        result.setPadding(16, 16, 16, 16);
        box.addView(result, new LinearLayout.LayoutParams(-1, -2));
    }

    private void calculate() {
        String name = workerName == null ? "" : workerName.getText().toString().trim();
        String text = message == null ? "" : message.getText().toString();
        if (name.isEmpty()) { show("اختر العامل أولًا من زر «اختيار العامل». "); return; }
        try {
            JSONObject workers = data.getJSONObject("workers");
            if (!workers.has(name)) { show("العامل غير مضاف."); return; }
            int[] used = {0,0,0,0};
            String[] lines = text.split("\\r?\\n");
            int count = 0;
            Pattern p = Pattern.compile("(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)");
            for (String line : lines) {
                Matcher m = p.matcher(line);
                while (m.find()) {
                    for (int i = 0; i < 4; i++) used[i] += Integer.parseInt(m.group(i + 1));
                    count++;
                }
            }
            if (count == 0) { show("لم أجد سطرًا بصيغة 100-200-250-500."); return; }
            JSONObject w = workers.getJSONObject(name);
            JSONObject s = data.getJSONObject("stock");
            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                int wb = w.optInt(k, 0), sb = s.optInt(k, 0);
                if (used[i] > wb) { show("مخزون العامل غير كافٍ في فئة " + k + ". المطلوب " + used[i] + " والمتوفر " + wb + "\nلم يتم الخصم."); return; }
                if (used[i] > sb) { show("المخزون العام غير كافٍ في فئة " + k + ". المطلوب " + used[i] + " والمتوفر " + sb + "\nلم يتم الخصم."); return; }
            }
            StringBuilder out = new StringBuilder("تم الخصم بنجاح من العامل: ").append(name).append("\n\n");
            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                int nw = w.optInt(k,0) - used[i];
                int ns = s.optInt(k,0) - used[i];
                w.put(k, nw); s.put(k, ns);
                out.append("فئة ").append(k).append(" : خصم ").append(used[i]).append(" | العامل ").append(nw).append(" | العام ").append(ns).append("\n");
            }
            saveData(); renderAll(); show(out.toString());
        } catch (Exception e) { show("حدث خطأ أثناء الحساب."); }
    }

    private void show(String text) {
        if (result != null) result.setText(text);
        Toast.makeText(this, text.split("\\n")[0], Toast.LENGTH_SHORT).show();
    }
}
