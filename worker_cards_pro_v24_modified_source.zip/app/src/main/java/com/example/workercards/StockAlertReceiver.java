package com.example.workercards;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class StockAlertReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.example.workercards.STOCK_CHANGED";
    public static final String EXTRA_CATEGORY = "category";
    public static final String EXTRA_REMAINING = "remaining";
    public static final String EXTRA_THRESHOLD = "threshold";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ACTION.equals(intent.getAction())) return;

        StockSettings.ensureNotificationChannel(context);

        String category = intent.getStringExtra(EXTRA_CATEGORY);
        if (category == null || category.trim().isEmpty()) {
            category = "الكرت";
        }

        int remaining = intent.getIntExtra(EXTRA_REMAINING, -1);
        int threshold = intent.getIntExtra(EXTRA_THRESHOLD,
                context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE)
                        .getInt(StockSettings.DEFAULT_THRESHOLD, 10));

        if (remaining < 0) return;

        // Trigger notification only if remaining is at or below threshold
        if (remaining > threshold) return;

        String title;
        String text;
        if (remaining == 0) {
            title = "🚨 نفاد مخزون الكروت بالكامل!";
            text = "تنبيه حرج: نفد رصيد " + category + " تمامًا (المتبقي 0 كرت). يرجى التغذية العاجلة.";
        } else {
            title = "🔔 تنبيه: مخزون الكروت منخفض";
            text = "تنبيه: تبقى من " + category + " عدد " + remaining + " كرت فقط، والحد الأدنى المعين للتنبيه هو " + threshold + " كرت.";
        }

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(context, "stock_alerts");
        } else {
            builder = new Notification.Builder(context);
        }

        builder.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            int notifId = ("stock_alert_" + category).hashCode();
            nm.notify(notifId, builder.build());
        }
    }
}
