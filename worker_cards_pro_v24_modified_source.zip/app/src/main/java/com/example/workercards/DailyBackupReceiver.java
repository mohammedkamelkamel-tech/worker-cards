package com.example.workercards;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class DailyBackupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("com.example.workercards.DAILY_BACKUP".equals(intent.getAction())) {
            SharedPreferences settings = context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE);
            if (settings.getBoolean(StockSettings.BACKUP_ENABLED, true)) {
                BackupHelper.createBackup(context);
            }
        }
        StockSettings.scheduleBackup(context);
    }
}
