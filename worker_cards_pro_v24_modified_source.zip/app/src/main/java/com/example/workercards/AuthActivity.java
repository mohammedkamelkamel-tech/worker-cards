package com.example.workercards;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.concurrent.Executor;

public class AuthActivity extends FragmentActivity {
    private static final String PREFS = "app_security";
    private static final String KEY_HASH = "password_hash";
    private static final String KEY_SALT = "password_salt";
    private static final String KEY_BIOMETRIC = "biometric_enabled";

    private SharedPreferences prefs;
    private EditText password;
    private TextView message;
    private Executor executor;
    private BiometricPrompt biometricPrompt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF0F172A);
            getWindow().setNavigationBarColor(0xFFF8FAFC);
        }

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        executor = ContextCompat.getMainExecutor(this);

        if (!hasPassword()) {
            showCreatePassword();
        } else {
            showLogin();
        }
    }

    private boolean hasPassword() {
        return prefs.contains(KEY_HASH) && prefs.contains(KEY_SALT);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(0xFF334155);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    private Button button(String s, int bgColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(52));
        b.setBackground(rounded(bgColor, 14, bgColor, 1));
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            b.setElevation(dp(3));
        }
        return b;
    }

    private void styleField(EditText field, String hint) {
        field.setHint(hint);
        field.setGravity(Gravity.CENTER);
        field.setTextSize(16);
        field.setTextColor(0xFF0F172A);
        field.setHintTextColor(0xFF94A3B8);
        field.setBackground(rounded(0xFFF8FAFC, 12, 0xFFCBD5E1, 1));
        field.setPadding(dp(16), dp(12), dp(16), dp(12));
    }

    private LinearLayout base() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(20), dp(24), dp(24));
        root.setBackgroundColor(0xFFF8FAFC);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return root;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(24), dp(24), dp(24), dp(26));
        c.setBackground(rounded(Color.WHITE, 20, 0xFFE2E8F0, 1));
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            c.setElevation(dp(6));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(4), dp(12), dp(4), dp(12));
        c.setLayoutParams(lp);
        return c;
    }

    private void addBranding(LinearLayout parent) {
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.workercards.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("شعار مخزون كروت الكامل");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(110));
        logoParams.setMargins(0, 0, 0, dp(12));
        parent.addView(logo, logoParams);

        TextView brand = new TextView(this);
        brand.setText("مخزون كروت الكامل V24");
        brand.setTextSize(24);
        brand.setTextColor(0xFF0F172A);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, 0, 0, dp(4));
        parent.addView(brand);

        TextView sub = new TextView(this);
        sub.setText("نظام إدارة المخزون وتوزيع الكروت");
        sub.setTextSize(14);
        sub.setTextColor(0xFF64748B);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(16));
        parent.addView(sub);
    }

    private void showCreatePassword() {
        LinearLayout root = base();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);

        addBranding(content);

        LinearLayout formCard = card();

        TextView title = new TextView(this);
        title.setText("🔐 إنشاء رمز حماية للتطبيق");
        title.setTextSize(18);
        title.setTextColor(0xFF0F172A);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(14));
        formCard.addView(title);

        password = new EditText(this);
        styleField(password, "أدخل كلمة المرور الجديدة");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        formCard.addView(password, new LinearLayout.LayoutParams(-1, dp(56)));

        View spacer1 = new View(this);
        formCard.addView(spacer1, new LinearLayout.LayoutParams(-1, dp(12)));

        EditText confirm = new EditText(this);
        styleField(confirm, "تأكيد كلمة المرور");
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        formCard.addView(confirm, new LinearLayout.LayoutParams(-1, dp(56)));

        message = text("", 14);
        message.setTextColor(0xFFDC2626);
        formCard.addView(message);

        Button save = button("حفظ كلمة المرور والدخول", 0xFF059669);
        formCard.addView(save, new LinearLayout.LayoutParams(-1, dp(52)));

        save.setOnClickListener(v -> {
            String p = password.getText().toString();
            String c = confirm.getText().toString();
            if (p.length() < 4) {
                message.setText("⚠️ كلمة المرور يجب أن تكون 4 أحرف/أرقام على الأقل");
                return;
            }
            if (!p.equals(c)) {
                message.setText("❌ كلمتا المرور غير متطابقتين");
                return;
            }
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            prefs.edit()
                    .putString(KEY_SALT, hex(salt))
                    .putString(KEY_HASH, hash(p, salt))
                    .putBoolean(KEY_BIOMETRIC, true)
                    .apply();
            showLogin();
        });

        content.addView(formCard);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void showLogin() {
        LinearLayout root = base();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);

        addBranding(content);

        LinearLayout loginCard = card();

        TextView title = new TextView(this);
        title.setText("مرحبًا بك، يرجى تأكيد الهوية");
        title.setTextSize(18);
        title.setTextColor(0xFF0F172A);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(10));
        loginCard.addView(title);

        message = text("جارٍ تشغيل التحقق بالبصمة...", 15);
        message.setTextColor(0xFF475569);
        loginCard.addView(message);

        password = new EditText(this);
        styleField(password, "أدخل كلمة المرور");
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setVisibility(View.GONE);
        loginCard.addView(password, new LinearLayout.LayoutParams(-1, dp(56)));

        View spacer = new View(this);
        spacer.setVisibility(View.GONE);
        loginCard.addView(spacer, new LinearLayout.LayoutParams(-1, dp(12)));

        Button enter = button("دخول بكلمة المرور", 0xFF2563EB);
        enter.setVisibility(View.GONE);
        loginCard.addView(enter, new LinearLayout.LayoutParams(-1, dp(52)));
        enter.setOnClickListener(v -> checkPassword());

        Button switchMethod = button("استخدام كلمة المرور بدلًا من البصمة", 0xFF64748B);
        switchMethod.setVisibility(View.VISIBLE);
        switchMethod.setTextSize(14);
        switchMethod.setMinHeight(dp(44));
        LinearLayout.LayoutParams smp = new LinearLayout.LayoutParams(-1, -2);
        smp.setMargins(0, dp(10), 0, 0);
        loginCard.addView(switchMethod, smp);
        switchMethod.setOnClickListener(v -> {
            if (biometricPrompt != null) {
                biometricPrompt.cancelAuthentication();
            }
            showPasswordOnly();
            switchMethod.setVisibility(View.GONE);
        });

        content.addView(loginCard);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);

        if (prefs.getBoolean(KEY_BIOMETRIC, true)) {
            startBiometric();
        } else {
            showPasswordOnly();
            switchMethod.setVisibility(View.GONE);
        }
    }

    private void showPasswordOnly() {
        message.setText("أدخل كلمة المرور للمتابعة");
        message.setTextColor(0xFF475569);
        if (password != null) {
            password.setVisibility(View.VISIBLE);
            password.requestFocus();
        }
        View parent = password != null ? (View) password.getParent() : null;
        if (parent instanceof LinearLayout) {
            LinearLayout l = (LinearLayout) parent;
            for (int i = 0; i < l.getChildCount(); i++) {
                View child = l.getChildAt(i);
                if (child instanceof Button && "دخول بكلمة المرور".equals(((Button) child).getText().toString())) {
                    child.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    private void startBiometric() {
        BiometricManager bm = BiometricManager.from(this);
        int can = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            showPasswordOnly();
            return;
        }

        biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                runOnUiThread(() -> openApp());
            }

            @Override
            public void onAuthenticationFailed() {
                runOnUiThread(() -> {
                    message.setText("لم يتم التعرف على البصمة. يمكنك إدخال كلمة المرور.");
                    message.setTextColor(0xFFD97706);
                    showPasswordOnly();
                });
            }

            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                runOnUiThread(() -> {
                    message.setText("تم التبديل إلى كلمة المرور: " + errString);
                    message.setTextColor(0xFF64748B);
                    showPasswordOnly();
                });
            }
        });

        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("مخزون كروت الكامل V24")
                .setSubtitle("المصادقة البيومترية")
                .setDescription("ضع إصبعك على مستشعر البصمة لفتح التطبيق")
                .setNegativeButtonText("استخدام كلمة المرور")
                .build();
        biometricPrompt.authenticate(info);
    }

    private void checkPassword() {
        String p = password.getText().toString();
        if (p.isEmpty()) {
            message.setText("⚠️ يرجى كتابة كلمة المرور");
            message.setTextColor(0xFFDC2626);
            return;
        }
        try {
            byte[] salt = fromHex(prefs.getString(KEY_SALT, ""));
            String expected = prefs.getString(KEY_HASH, "");
            if (MessageDigest.isEqual(hash(p, salt).getBytes(StandardCharsets.UTF_8), expected.getBytes(StandardCharsets.UTF_8))) {
                openApp();
            } else {
                message.setText("❌ كلمة المرور غير صحيحة، حاول مجددًا");
                message.setTextColor(0xFFDC2626);
                password.setText("");
            }
        } catch (Exception e) {
            message.setText("❌ تعذر التحقق من كلمة المرور");
            message.setTextColor(0xFFDC2626);
        }
    }

    private String hash(String value, byte[] salt) {
        try {
            javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(value.toCharArray(), salt, 120000, 256);
            byte[] out = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return hex(out);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte x : b) s.append(String.format("%02x", x));
        return s.toString();
    }

    private byte[] fromHex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        }
        return b;
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }
}
