package com.example.workercards;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.net.Uri;
import android.os.Build;

import androidx.documentfile.provider.DocumentFile;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BackupHelper {

    public static final String PREFS_DATA = "worker_cards_pro_v24_data";
    public static final String DATA_KEY = "data";
    public static final String KEY_CUSTOM_URI = "custom_backup_tree_uri";
    public static final String KEY_CUSTOM_NAME = "custom_backup_folder_name";

    public static final String KEY_LAST_STATUS = "last_backup_status"; // SUCCESS / FAILED
    public static final String KEY_LAST_TIME = "last_backup_time";
    public static final String KEY_LAST_ERROR = "last_backup_error";
    public static final String KEY_LAST_FILE = "last_backup_file_name";

    private static final String CHANNEL_ID = "backup_status_channel";

    public static Uri getCustomFolderUri(Context context) {
        SharedPreferences sp = context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE);
        String uriStr = sp.getString(KEY_CUSTOM_URI, null);
        if (uriStr == null || uriStr.trim().isEmpty()) return null;
        try {
            return Uri.parse(uriStr);
        } catch (Exception e) {
            return null;
        }
    }

    public static String getCustomFolderDisplayName(Context context) {
        SharedPreferences sp = context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE);
        String name = sp.getString(KEY_CUSTOM_NAME, null);
        if (name != null && !name.trim().isEmpty()) return name;

        Uri uri = getCustomFolderUri(context);
        if (uri == null) return "لم يتم اختيار مجلد بعد";

        try {
            DocumentFile df = DocumentFile.fromTreeUri(context, uri);
            if (df != null && df.getName() != null) {
                return df.getName();
            }
        } catch (Exception ignored) { }
        return uri.getLastPathSegment() != null ? uri.getLastPathSegment() : uri.toString();
    }

    public static boolean hasTreeUriPermission(Context context, Uri treeUri) {
        if (treeUri == null) return false;
        try {
            List<UriPermission> list = context.getContentResolver().getPersistedUriPermissions();
            for (UriPermission p : list) {
                if (p.getUri().equals(treeUri) && p.isWritePermission()) {
                    return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    public static boolean createBackup(Context context) {
        SharedPreferences settings = context.getSharedPreferences(StockSettings.PREFS, Context.MODE_PRIVATE);
        Uri treeUri = getCustomFolderUri(context);

        if (treeUri == null) {
            String err = "لم يتم تحديد مجلد لحفظ النسخ الاحتياطية. يرجى الدخول للإعدادات والضغط على «اختيار مسار النسخ الاحتياطي».";
            recordStatus(settings, false, err, null);
            showResultNotification(context, false, err);
            return false;
        }

        if (!hasTreeUriPermission(context, treeUri)) {
            String err = "فُقدت صلاحية الوصول إلى المجلد المختار. يرجى إعادة اختيار المجلد من شاشة الإعدادات لمنح الإذن مجددًا.";
            recordStatus(settings, false, err, null);
            showResultNotification(context, false, err);
            return false;
        }

        SharedPreferences dataPrefs = context.getSharedPreferences(PREFS_DATA, Context.MODE_PRIVATE);
        String json = dataPrefs.getString(DATA_KEY, "");
        if (json == null || json.trim().isEmpty()) {
            String err = "لا توجد بيانات مخزون أو عمال محفوظة لإنشاء نسخة احتياطية.";
            recordStatus(settings, false, err, null);
            showResultNotification(context, false, err);
            return false;
        }

        try {
            DocumentFile treeDoc = DocumentFile.fromTreeUri(context, treeUri);
            if (treeDoc == null || !treeDoc.exists() || !treeDoc.canWrite()) {
                String err = "المجلد المحدد غير متاح أو لا يملك صلاحية الكتابة. يرجى اختيار مجلد صالح من الإعدادات.";
                recordStatus(settings, false, err, null);
                showResultNotification(context, false, err);
                return false;
            }

            String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
            String fileName = "backup_" + stamp + ".json";

            DocumentFile backupFile = treeDoc.createFile("application/json", fileName);
            if (backupFile == null) {
                String err = "تعذر إنشاء ملف النسخة الاحتياطية داخل المجلد المختار. تحقق من مساحة التخزين وصلاحيات المجلد.";
                recordStatus(settings, false, err, null);
                showResultNotification(context, false, err);
                return false;
            }

            try (OutputStream out = context.getContentResolver().openOutputStream(backupFile.getUri())) {
                if (out == null) throw new Exception("openOutputStream returned null");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }

            if (backupFile.length() <= 0) {
                String err = "فشل في حفظ البيانات: ملف النسخة الاحتياطية فارغ.";
                recordStatus(settings, false, err, null);
                showResultNotification(context, false, err);
                return false;
            }

            // Retention: keep latest 30 backups in the chosen folder
            deleteOldBackups(treeDoc, 30);

            String folderName = getCustomFolderDisplayName(context);
            recordStatus(settings, true, null, fileName);
            showResultNotification(context, true, "تم حفظ النسخة بنجاح في مجلد: " + folderName + "\nالملف: " + fileName);
            return true;

        } catch (Exception ex) {
            String err = "حدث خطأ أثناء كتابة النسخة الاحتياطية: " + ex.getMessage();
            recordStatus(settings, false, err, null);
            showResultNotification(context, false, err);
            return false;
        }
    }

    private static void recordStatus(SharedPreferences sp, boolean success, String errorMsg, String fileName) {
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
        SharedPreferences.Editor ed = sp.edit();
        ed.putString(KEY_LAST_STATUS, success ? "SUCCESS" : "FAILED");
        ed.putString(KEY_LAST_TIME, now);
        if (success) {
            ed.putString(KEY_LAST_ERROR, "");
            ed.putString(KEY_LAST_FILE, fileName != null ? fileName : "");
        } else {
            ed.putString(KEY_LAST_ERROR, errorMsg != null ? errorMsg : "خطأ غير معروف");
        }
        ed.apply();
    }

    private static void deleteOldBackups(DocumentFile treeDoc, int maxKeep) {
        try {
            DocumentFile[] all = treeDoc.listFiles();
            List<DocumentFile> list = new ArrayList<>();
            for (DocumentFile f : all) {
                String name = f.getName();
                if (name != null && name.startsWith("backup_") && name.endsWith(".json")) {
                    list.add(f);
                }
            }
            if (list.size() <= maxKeep) return;

            DocumentFile[] arr = list.toArray(new DocumentFile[0]);
            Arrays.sort(arr, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            int toDelete = arr.length - maxKeep;
            for (int i = 0; i < toDelete; i++) {
                arr[i].delete();
            }
        } catch (Exception ignored) { }
    }

    public static boolean restoreBackupFromUri(Context context, Uri fileUri) throws Exception {
        try (InputStream in = context.getContentResolver().openInputStream(fileUri)) {
            if (in == null) throw new Exception("تعذر فتح ملف النسخة الاحتياطية للقراءة");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) b.write(buf, 0, n);

            String jsonStr = new String(b.toByteArray(), StandardCharsets.UTF_8);
            JSONObject parsed = new JSONObject(jsonStr);

            if (!parsed.has("stock") || !parsed.has("workers")) {
                throw new Exception("الملف لا يحتوي على بيانات المخزون والعمال المعتمدة");
            }

            SharedPreferences dataPrefs = context.getSharedPreferences(PREFS_DATA, Context.MODE_PRIVATE);
            dataPrefs.edit().putString(DATA_KEY, jsonStr).apply();
            return true;
        }
    }

    public static void showResultNotification(Context context, boolean success, String message) {
        try {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "حالة النسخ الاحتياطي",
                        success ? NotificationManager.IMPORTANCE_DEFAULT : NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("إشعارات نجاح أو فشل عمليات النسخ الاحتياطي");
                nm.createNotificationChannel(channel);
            }

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, CHANNEL_ID);
            } else {
                builder = new Notification.Builder(context);
            }

            builder.setSmallIcon(success ? android.R.drawable.ic_menu_save : android.R.drawable.ic_dialog_alert)
                    .setContentTitle(success ? "✅ تم إنشاء النسخة الاحتياطية" : "❌ تعذر إتمام النسخ الاحتياطي")
                    .setContentText(message)
                    .setStyle(new Notification.BigTextStyle().bigText(message))
                    .setAutoCancel(true)
                    .setPriority(success ? Notification.PRIORITY_DEFAULT : Notification.PRIORITY_HIGH);

            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
        } catch (Exception ignored) { }
    }
}
