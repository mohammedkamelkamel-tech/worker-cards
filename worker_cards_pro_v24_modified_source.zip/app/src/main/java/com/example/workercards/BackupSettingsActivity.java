package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.biometric.BiometricManager;
import androidx.documentfile.provider.DocumentFile;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

public class BackupSettingsActivity extends Activity {

    private static final int REQUEST_PICK_FOLDER = 2001;
    private static final int REQUEST_PICK_RESTORE_FILE = 2002;

    private TextView folderPathDisplay;
    private CheckBox autoBackupEnabled;
    private TextView timeDisplay;
    private TextView backupStatusInfo;

    // Security & Biometric fields
    private CheckBox biometricToggle;
    private TextView biometricSupportStatus;

    private final EditText[] globalThresholds = new EditText[4];
    private final int[] denominations = {100, 200, 250, 500};
    private final Map<String, EditText> workerThresholdInputs = new LinkedHashMap<>();

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private LinearLayout createSectionCard(String icon, String titleText, String subtitleText) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(20));
        card.setBackground(rounded(Color.WHITE, 18, 0xFFE2E8F0, 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(3));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(8));
        card.setLayoutParams(lp);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        headerRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView iconView = new TextView(this);
        iconView.setText(icon);
        iconView.setTextSize(20);
        iconView.setPadding(0, 0, dp(8), 0);
        headerRow.addView(iconView);

        TextView titleView = new TextView(this);
        titleView.setText(titleText);
        titleView.setTextSize(17);
        titleView.setTextColor(0xFF0F172A);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        headerRow.addView(titleView);

        card.addView(headerRow);

        if (subtitleText != null && !subtitleText.isEmpty()) {
            TextView subView = new TextView(this);
            subView.setText(subtitleText);
            subView.setTextSize(13);
            subView.setTextColor(0xFF64748B);
            subView.setGravity(Gravity.RIGHT);
            subView.setPadding(0, dp(4), 0, dp(12));
            card.addView(subView);
        } else {
            View divider = new View(this);
            divider.setBackgroundColor(0xFFF1F5F9);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(1));
            dlp.setMargins(0, dp(8), 0, dp(12));
            card.addView(divider, dlp);
        }

        return card;
    }

    private void styleField(EditText field) {
        field.setTextSize(15);
        field.setSingleLine(true);
        field.setGravity(Gravity.CENTER);
        field.setPadding(dp(12), dp(10), dp(12), dp(10));
        field.setTextColor(0xFF0F172A);
        field.setHintTextColor(0xFF94A3B8);
        field.setBackground(rounded(0xFFF8FAFC, 10, 0xFFCBD5E1, 1));
    }

    private Button createStyledButton(String text, int bgColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(48));
        b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setBackground(rounded(bgColor, 12, bgColor, 1));
        if (Build.VERSION.SDK_INT >= 21) b.setElevation(dp(2));
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF0F172A);
            getWindow().setNavigationBarColor(0xFF0F172A);
        }

        SharedPreferences p = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        SharedPreferences secPrefs = getSharedPreferences("app_security", MODE_PRIVATE);

        ScrollView pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(0xFFF8FAFC);

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(dp(16), dp(16), dp(16), dp(32));
        mainLayout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // Header Card (Dark Navy)
        LinearLayout headerCard = new LinearLayout(this);
        headerCard.setOrientation(LinearLayout.VERTICAL);
        headerCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        headerCard.setBackground(rounded(0xFF0F172A, 20, 0xFF0F172A, 1));
        if (Build.VERSION.SDK_INT >= 21) headerCard.setElevation(dp(4));

        LinearLayout topNav = new LinearLayout(this);
        topNav.setOrientation(LinearLayout.HORIZONTAL);
        topNav.setGravity(Gravity.CENTER_VERTICAL);
        topNav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        Button backButton = new Button(this);
        backButton.setText("← رجوع");
        backButton.setTextColor(Color.WHITE);
        backButton.setTextSize(14);
        backButton.setBackground(rounded(0x33FFFFFF, 10, 0x55FFFFFF, 1));
        backButton.setPadding(dp(12), dp(4), dp(12), dp(4));
        backButton.setMinHeight(dp(36));
        backButton.setOnClickListener(v -> finish());
        topNav.addView(backButton, new LinearLayout.LayoutParams(-2, dp(38)));

        TextView title = new TextView(this);
        title.setText("إعدادات النسخ والتنبيهات والأمان");
        title.setTextSize(19);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        topNav.addView(title, tlp);

        headerCard.addView(topNav);

        TextView subTitle = new TextView(this);
        subTitle.setText("تحديد مجلد النسخ، الجدولة التلقائية الموثوقة، تغيير كلمة المرور، وحدود التنبيهات المستقلة");
        subTitle.setTextSize(13);
        subTitle.setTextColor(0xFFCBD5E1);
        subTitle.setGravity(Gravity.CENTER);
        subTitle.setPadding(0, dp(10), 0, 0);
        headerCard.addView(subTitle);

        mainLayout.addView(headerCard);

        // ==========================================
        // 1. SECTION: اختيار مسار النسخ الاحتياطي يدويًا
        // ==========================================
        LinearLayout pathSection = createSectionCard("📁", "1. مسار النسخ الاحتياطي المختار",
                "المجلد المختار هنا هو المعتمد لكافة عمليات النسخ اليدوية والتلقائية الدورية");

        folderPathDisplay = new TextView(this);
        folderPathDisplay.setTextSize(14);
        folderPathDisplay.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        folderPathDisplay.setPadding(dp(14), dp(12), dp(14), dp(12));
        folderPathDisplay.setGravity(Gravity.RIGHT);
        updateFolderPathDisplay();
        pathSection.addView(folderPathDisplay);

        View fpSpacer = new View(this);
        pathSection.addView(fpSpacer, new LinearLayout.LayoutParams(-1, dp(10)));

        LinearLayout folderBtns = new LinearLayout(this);
        folderBtns.setOrientation(LinearLayout.VERTICAL);
        folderBtns.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        Button chooseFolderBtn = createStyledButton("📁 اختيار مسار مجلد النسخ الاحتياطي", 0xFF2563EB);
        chooseFolderBtn.setOnClickListener(v -> openFolderPicker());
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(-1, dp(48));
        folderBtns.addView(chooseFolderBtn, cbp);

        Button changeFolderBtn = createStyledButton("🔄 تغيير المجلد المعتمد للنسخ", 0xFF475569);
        changeFolderBtn.setOnClickListener(v -> openFolderPicker());
        LinearLayout.LayoutParams chbp = new LinearLayout.LayoutParams(-1, dp(44));
        chbp.setMargins(0, dp(8), 0, 0);
        folderBtns.addView(changeFolderBtn, chbp);

        pathSection.addView(folderBtns);

        mainLayout.addView(pathSection);

        // ==========================================
        // 2. SECTION: النسخ اليدوي والاستعادة
        // ==========================================
        LinearLayout manualOpsSection = createSectionCard("💾", "2. النسخ الاحتياطي اليدوي والاستعادة",
                "إنشاء نسخة فورية في المجلد المختار أو استعادة نسخة سابقة");

        LinearLayout opsGrid = new LinearLayout(this);
        opsGrid.setOrientation(LinearLayout.VERTICAL);
        opsGrid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        Button manualBackupBtn = createStyledButton("⚡ إنشاء نسخة احتياطية فورية الآن", 0xFF059669);
        manualBackupBtn.setOnClickListener(v -> performManualBackup());
        LinearLayout.LayoutParams mbp = new LinearLayout.LayoutParams(-1, dp(48));
        opsGrid.addView(manualBackupBtn, mbp);

        Button restoreBtn = createStyledButton("📥 استعادة نسخة احتياطية من ملف", 0xFF1E40AF);
        restoreBtn.setOnClickListener(v -> openRestorePicker());
        LinearLayout.LayoutParams rbp = new LinearLayout.LayoutParams(-1, dp(48));
        rbp.setMargins(0, dp(8), 0, 0);
        opsGrid.addView(restoreBtn, rbp);

        manualOpsSection.addView(opsGrid);

        mainLayout.addView(manualOpsSection);

        // ==========================================
        // 3. SECTION: النسخ الاحتياطي التلقائي الموثوق
        // ==========================================
        LinearLayout autoSection = createSectionCard("⏰", "3. النسخ الاحتياطي التلقائي المجدول",
                "إنشاء نسخ احتياطية تلقائية في الخلفية وفق الموعد المحدد وحفظها في المجلد المختار");

        autoBackupEnabled = new CheckBox(this);
        autoBackupEnabled.setText("تفعيل النسخ الاحتياطي التلقائي يوميًا في الخلفية");
        autoBackupEnabled.setTextSize(15);
        autoBackupEnabled.setTextColor(0xFF0F172A);
        autoBackupEnabled.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        autoBackupEnabled.setChecked(p.getBoolean(StockSettings.BACKUP_ENABLED, true));
        autoBackupEnabled.setPadding(dp(6), dp(6), dp(6), dp(6));
        autoSection.addView(autoBackupEnabled);

        int curHour = p.getInt(StockSettings.BACKUP_HOUR, 4);
        int curMinute = p.getInt(StockSettings.BACKUP_MINUTE, 0);

        timeDisplay = new TextView(this);
        timeDisplay.setText("🕒 وقت النسخ المجدول يوميًا: " + String.format("%02d:%02d", curHour, curMinute));
        timeDisplay.setTextSize(14);
        timeDisplay.setTextColor(0xFF1E293B);
        timeDisplay.setBackground(rounded(0xFFF1F5F9, 8, 0xFFE2E8F0, 1));
        timeDisplay.setPadding(dp(12), dp(10), dp(12), dp(10));
        timeDisplay.setGravity(Gravity.RIGHT);
        autoSection.addView(timeDisplay);

        View timeSpacer = new View(this);
        autoSection.addView(timeSpacer, new LinearLayout.LayoutParams(-1, dp(8)));

        Button setTimeBtn = createStyledButton("تعديل وقت النسخ اليومي", 0xFF0284C7);
        setTimeBtn.setTextSize(14);
        setTimeBtn.setMinHeight(dp(44));
        setTimeBtn.setOnClickListener(v -> {
            int h = p.getInt(StockSettings.BACKUP_HOUR, 4);
            int m = p.getInt(StockSettings.BACKUP_MINUTE, 0);
            new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                p.edit().putInt(StockSettings.BACKUP_HOUR, hourOfDay)
                        .putInt(StockSettings.BACKUP_MINUTE, minute).apply();
                timeDisplay.setText("🕒 وقت النسخ المجدول يوميًا: " + String.format("%02d:%02d", hourOfDay, minute));
                StockSettings.scheduleBackup(this);
                Toast.makeText(this, "تم تحديث وقت النسخ التلقائي", Toast.LENGTH_SHORT).show();
            }, h, m, true).show();
        });
        autoSection.addView(setTimeBtn);

        // Auto Backup Status Widget
        backupStatusInfo = new TextView(this);
        backupStatusInfo.setTextSize(13);
        backupStatusInfo.setPadding(dp(12), dp(10), dp(12), dp(10));
        backupStatusInfo.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams bslp = new LinearLayout.LayoutParams(-1, -2);
        bslp.setMargins(0, dp(10), 0, 0);
        backupStatusInfo.setLayoutParams(bslp);
        updateBackupStatusInfo();
        autoSection.addView(backupStatusInfo);

        mainLayout.addView(autoSection);

        // ==========================================
        // 4. SECTION: الأمان وكلمة المرور والبصمة
        // ==========================================
        LinearLayout securitySection = createSectionCard("🔐", "4. الأمان وكلمة المرور والبصمة",
                "التحكم في كلمة مرور الدخول وتفعيل المصادقة بالبصمة");

        // Biometrics Switch
        biometricToggle = new CheckBox(this);
        biometricToggle.setText("تفعيل تسجيل الدخول بالبصمة (Biometrics)");
        biometricToggle.setTextSize(15);
        biometricToggle.setTextColor(0xFF0F172A);
        biometricToggle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        biometricToggle.setChecked(secPrefs.getBoolean("biometric_enabled", true));
        biometricToggle.setPadding(dp(6), dp(6), dp(6), dp(6));
        securitySection.addView(biometricToggle);

        biometricSupportStatus = new TextView(this);
        biometricSupportStatus.setTextSize(12);
        biometricSupportStatus.setPadding(dp(8), dp(4), dp(8), dp(8));
        checkBiometricSupport();
        securitySection.addView(biometricSupportStatus);

        biometricToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            secPrefs.edit().putBoolean("biometric_enabled", isChecked).apply();
            Toast.makeText(this, isChecked ? "تم تفعيل المصادقة بالبصمة" : "تم تعطيل المصادقة بالبصمة", Toast.LENGTH_SHORT).show();
        });

        // Change Password Button
        Button changePwdBtn = createStyledButton("🔑 تغيير كلمة المرور الحالية", 0xFF6D28D9);
        changePwdBtn.setTextSize(14);
        changePwdBtn.setMinHeight(dp(46));
        changePwdBtn.setOnClickListener(v -> showChangePasswordDialog());
        securitySection.addView(changePwdBtn);

        mainLayout.addView(securitySection);

        // ==========================================
        // 5. SECTION: حدود تنبيه المخزون العام
        // ==========================================
        LinearLayout globalStockSection = createSectionCard("🔔", "5. حدود تنبيه المخزون العام",
                "إرسال إشعار تنبيهي عندما ينخفض رصيد أي فئة بالمخزون العام إلى الحد المحدد أو أقل");

        LinearLayout gridGeneral = new LinearLayout(this);
        gridGeneral.setOrientation(LinearLayout.VERTICAL);
        gridGeneral.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        for (int r = 0; r < denominations.length; r += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            for (int col = r; col < Math.min(r + 2, denominations.length); col++) {
                final int denom = denominations[col];
                final int index = col;

                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setPadding(dp(10), dp(10), dp(10), dp(10));
                cell.setBackground(rounded(0xFFF8FAFC, 12, 0xFFE2E8F0, 1));

                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
                cp.setMargins(dp(4), dp(4), dp(4), dp(4));

                TextView lab = new TextView(this);
                lab.setText("فئة " + denom);
                lab.setTextSize(14);
                lab.setTextColor(0xFF1E3A8A);
                lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                lab.setGravity(Gravity.CENTER);
                lab.setPadding(0, 0, 0, dp(6));
                cell.addView(lab);

                globalThresholds[index] = new EditText(this);
                globalThresholds[index].setInputType(2);
                styleField(globalThresholds[index]);
                globalThresholds[index].setText(String.valueOf(p.getInt("threshold_" + denom,
                        p.getInt(StockSettings.DEFAULT_THRESHOLD, 10))));
                cell.addView(globalThresholds[index]);

                row.addView(cell, cp);
            }
            gridGeneral.addView(row);
        }
        globalStockSection.addView(gridGeneral);

        mainLayout.addView(globalStockSection);

        // ==========================================
        // 6. SECTION: حدود التنبيه الخاصة بكل عامل
        // ==========================================
        LinearLayout workersSection = createSectionCard("👥", "6. حدود التنبيه المستقلة لكل عامل",
                "لكل عامل حد تنبيه خاص به لكل فئة، ولا يؤثر تعديل عامل على العمال الآخرين");

        try {
            SharedPreferences dataPrefs = getSharedPreferences(BackupHelper.PREFS_DATA, MODE_PRIVATE);
            JSONObject appData = new JSONObject(dataPrefs.getString(BackupHelper.DATA_KEY, "{}"));
            JSONObject workers = appData.optJSONObject("workers");

            if (workers == null || workers.length() == 0) {
                TextView emptyWorkers = new TextView(this);
                emptyWorkers.setText("لم يتم إضافة أي عامل حتى الآن. يرجى إضافة عمال من الشاشة الرئيسية لتخصيص حدود تنبيههم هنا.");
                emptyWorkers.setTextSize(14);
                emptyWorkers.setTextColor(0xFF64748B);
                emptyWorkers.setPadding(dp(8), dp(12), dp(8), dp(12));
                emptyWorkers.setGravity(Gravity.CENTER);
                workersSection.addView(emptyWorkers);
            } else {
                Iterator<String> names = workers.keys();
                while (names.hasNext()) {
                    String workerName = names.next();
                    JSONObject worker = workers.optJSONObject(workerName);

                    LinearLayout workerCard = new LinearLayout(this);
                    workerCard.setOrientation(LinearLayout.VERTICAL);
                    workerCard.setPadding(dp(14), dp(14), dp(14), dp(14));
                    workerCard.setBackground(rounded(0xFFF1F5F9, 14, 0xFFCBD5E1, 1));
                    LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
                    wlp.setMargins(0, dp(6), 0, dp(6));
                    workerCard.setLayoutParams(wlp);

                    LinearLayout nameHeader = new LinearLayout(this);
                    nameHeader.setOrientation(LinearLayout.HORIZONTAL);
                    nameHeader.setGravity(Gravity.CENTER_VERTICAL);
                    nameHeader.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

                    TextView nameLabel = new TextView(this);
                    nameLabel.setText("👤 " + workerName);
                    nameLabel.setTextSize(16);
                    nameLabel.setTextColor(0xFF0F172A);
                    nameLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                    nameHeader.addView(nameLabel, new LinearLayout.LayoutParams(0, -2, 1f));

                    String phone = worker != null ? worker.optString("phone", "") : "";
                    if (!phone.isEmpty()) {
                        TextView phoneBadge = new TextView(this);
                        phoneBadge.setText("📱 " + phone);
                        phoneBadge.setTextSize(12);
                        phoneBadge.setTextColor(0xFF0284C7);
                        nameHeader.addView(phoneBadge);
                    }
                    workerCard.addView(nameHeader);

                    TextView workerHint = new TextView(this);
                    workerHint.setText("حد التنبيه للكروت المخصصة لهذا العامل:");
                    workerHint.setTextSize(12);
                    workerHint.setTextColor(0xFF64748B);
                    workerHint.setPadding(0, dp(4), 0, dp(8));
                    workerHint.setGravity(Gravity.RIGHT);
                    workerCard.addView(workerHint);

                    LinearLayout wGrid = new LinearLayout(this);
                    wGrid.setOrientation(LinearLayout.VERTICAL);
                    wGrid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

                    for (int r = 0; r < denominations.length; r += 2) {
                        LinearLayout wRow = new LinearLayout(this);
                        wRow.setOrientation(LinearLayout.HORIZONTAL);
                        wRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

                        for (int col = r; col < Math.min(r + 2, denominations.length); col++) {
                            final int denom = denominations[col];
                            LinearLayout wCell = new LinearLayout(this);
                            wCell.setOrientation(LinearLayout.VERTICAL);
                            wCell.setPadding(dp(8), dp(8), dp(8), dp(8));
                            wCell.setBackground(rounded(Color.WHITE, 10, 0xFFE2E8F0, 1));

                            LinearLayout.LayoutParams wcp = new LinearLayout.LayoutParams(0, -2, 1f);
                            wcp.setMargins(dp(3), dp(3), dp(3), dp(3));

                            TextView dLabel = new TextView(this);
                            dLabel.setText("فئة " + denom + " ريال");
                            dLabel.setTextSize(13);
                            dLabel.setTextColor(0xFF1E3A8A);
                            dLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                            dLabel.setGravity(Gravity.CENTER);
                            dLabel.setPadding(0, 0, 0, dp(4));
                            wCell.addView(dLabel);

                            EditText wInput = new EditText(this);
                            wInput.setInputType(InputType.TYPE_CLASS_NUMBER);
                            styleField(wInput);
                            wInput.setTextSize(15);

                            int savedLimit = worker != null ? worker.optInt("threshold_" + denom,
                                    p.getInt("threshold_" + denom, 10)) : 10;
                            wInput.setText(String.valueOf(savedLimit));

                            wCell.addView(wInput);
                            wRow.addView(wCell, wcp);

                            workerThresholdInputs.put(workerName + "|" + denom, wInput);
                        }
                        wGrid.addView(wRow);
                    }
                    workerCard.addView(wGrid);
                    workersSection.addView(workerCard);
                }
            }
        } catch (Exception ex) {
            TextView err = new TextView(this);
            err.setText("تعذر قراءة قائمة العمال من قاعدة البيانات.");
            err.setTextColor(0xFFDC2626);
            workersSection.addView(err);
        }

        mainLayout.addView(workersSection);

        // ==========================================
        // SAVE BUTTON (Emerald Green Primary Action)
        // ==========================================
        Button saveAllButton = createStyledButton("💾  حفظ كافة الإعدادات والحدود والجدولة", 0xFF059669);
        saveAllButton.setTextSize(17);
        saveAllButton.setMinHeight(dp(54));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, dp(54));
        slp.setMargins(0, dp(12), 0, dp(16));
        saveAllButton.setLayoutParams(slp);
        saveAllButton.setOnClickListener(v -> saveSettings());
        mainLayout.addView(saveAllButton);

        pageScroll.addView(mainLayout);
        setContentView(pageScroll);
    }

    private void updateFolderPathDisplay() {
        if (folderPathDisplay == null) return;
        Uri uri = BackupHelper.getCustomFolderUri(this);
        if (uri == null) {
            folderPathDisplay.setText("⚠️ لم يتم تحديد مجلد للنسخ بعد. يرجى الضغط على «اختيار مجلد» أدناه.");
            folderPathDisplay.setTextColor(0xFFD97706);
            folderPathDisplay.setBackground(rounded(0xFFFFFBEB, 10, 0xFFFDE68A, 1));
        } else {
            boolean hasPerm = BackupHelper.hasTreeUriPermission(this, uri);
            String name = BackupHelper.getCustomFolderDisplayName(this);
            if (hasPerm) {
                folderPathDisplay.setText("📍 مجلد النسخ المعتمد: " + name + "\n(صلاحية الوصول دائمة ومفعلة ✓)");
                folderPathDisplay.setTextColor(0xFF065F46);
                folderPathDisplay.setBackground(rounded(0xFFECFDF5, 10, 0xFFA7F3D0, 1));
            } else {
                folderPathDisplay.setText("❌ المجلد: " + name + "\n(فُقدت صلاحية الوصول! يرجى إعادة اختيار المجلد)");
                folderPathDisplay.setTextColor(0xFFDC2626);
                folderPathDisplay.setBackground(rounded(0xFFFEF2F2, 10, 0xFFFCA5A5, 1));
            }
        }
    }

    private void updateBackupStatusInfo() {
        if (backupStatusInfo == null) return;
        SharedPreferences sp = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        String status = sp.getString(BackupHelper.KEY_LAST_STATUS, "");
        String time = sp.getString(BackupHelper.KEY_LAST_TIME, "");
        String err = sp.getString(BackupHelper.KEY_LAST_ERROR, "");
        String fileName = sp.getString(BackupHelper.KEY_LAST_FILE, "");

        if (status.isEmpty()) {
            backupStatusInfo.setText("ℹ️ حالة النسخ التلقائي: جاهز للعمل وفق الجدولة.");
            backupStatusInfo.setTextColor(0xFF475569);
            backupStatusInfo.setBackground(rounded(0xFFF1F5F9, 8, 0xFFE2E8F0, 1));
        } else if ("SUCCESS".equals(status)) {
            backupStatusInfo.setText("✅ آخر نسخة احتياطية ناجحة: " + time + "\nالملف: " + fileName);
            backupStatusInfo.setTextColor(0xFF065F46);
            backupStatusInfo.setBackground(rounded(0xFFECFDF5, 8, 0xFFA7F3D0, 1));
        } else {
            backupStatusInfo.setText("❌ آخر محاولة نسخ فشلت في: " + time + "\nالسبب: " + err);
            backupStatusInfo.setTextColor(0xFF991B1B);
            backupStatusInfo.setBackground(rounded(0xFFFEF2F2, 8, 0xFFFCA5A5, 1));
        }
    }

    private void checkBiometricSupport() {
        BiometricManager bm = BiometricManager.from(this);
        int can = bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (can == BiometricManager.BIOMETRIC_SUCCESS) {
            biometricSupportStatus.setText("✅ مستشعر البصمة مدعوم ومسجل على هذا الهاتف.");
            biometricSupportStatus.setTextColor(0xFF059669);
            biometricToggle.setEnabled(true);
        } else if (can == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
            biometricSupportStatus.setText("⚠️ مستشعر البصمة متوفر ولكن لا توجد بصمات مسجلة في إعدادات الهاتف.");
            biometricSupportStatus.setTextColor(0xFFD97706);
            biometricToggle.setEnabled(false);
            biometricToggle.setChecked(false);
        } else {
            biometricSupportStatus.setText("ℹ️ هذا الجهاز لا يدعم المصادقة البيومترية، تسجيل الدخول يعتمد على كلمة المرور.");
            biometricSupportStatus.setTextColor(0xFF64748B);
            biometricToggle.setEnabled(false);
            biometricToggle.setChecked(false);
        }
    }

    private void openFolderPicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_PICK_FOLDER);
        } catch (Exception ex) {
            Toast.makeText(this, "تعذر فتح منتقي المجلدات: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void openRestorePicker() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("application/json");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, REQUEST_PICK_RESTORE_FILE);
        } catch (Exception ex) {
            Toast.makeText(this, "تعذر فتح منتقي الملفات: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQUEST_PICK_FOLDER) {
            try {
                final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, takeFlags);

                DocumentFile df = DocumentFile.fromTreeUri(this, uri);
                String folderName = df != null && df.getName() != null ? df.getName() : uri.getLastPathSegment();

                SharedPreferences p = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
                p.edit()
                        .putString(BackupHelper.KEY_CUSTOM_URI, uri.toString())
                        .putString(BackupHelper.KEY_CUSTOM_NAME, folderName)
                        .apply();

                updateFolderPathDisplay();
                Toast.makeText(this, "تم اعتماد المجلد بنجاح: " + folderName, Toast.LENGTH_LONG).show();

            } catch (Exception e) {
                new AlertDialog.Builder(this)
                        .setTitle("خطأ في الصلاحيات")
                        .setMessage("تعذر تثبيت الصلاحية الدائمة للمجلد المختار: " + e.getMessage())
                        .setPositiveButton("إغلاق", null)
                        .show();
            }
        } else if (requestCode == REQUEST_PICK_RESTORE_FILE) {
            try {
                boolean success = BackupHelper.restoreBackupFromUri(this, uri);
                if (success) {
                    new AlertDialog.Builder(this)
                            .setTitle("تمت الاستعادة بنجاح")
                            .setMessage("تم استعادة كافة بيانات المخزون والعمال من ملف النسخة الاحتياطية بنجاح.")
                            .setPositiveButton("موافق", (d, w) -> finish())
                            .show();
                }
            } catch (Exception ex) {
                new AlertDialog.Builder(this)
                        .setTitle("فشل استعادة النسخة")
                        .setMessage("حدث خطأ أثناء قراءة ملف النسخة: " + ex.getMessage())
                        .setPositiveButton("إغلاق", null)
                        .show();
            }
        }
    }

    private void performManualBackup() {
        Uri folderUri = BackupHelper.getCustomFolderUri(this);
        if (folderUri == null) {
            new AlertDialog.Builder(this)
                    .setTitle("مجلد النسخ غير محدد")
                    .setMessage("يرجى الضغط على «اختيار مجلد النسخ الاحتياطي» أولاً واختيار المجلد الذي ترغب في حفظ النسخ بداخله.")
                    .setPositiveButton("اختيار الآن", (d, w) -> openFolderPicker())
                    .setNegativeButton("إلغاء", null)
                    .show();
            return;
        }

        boolean ok = BackupHelper.createBackup(this);
        updateBackupStatusInfo();
        if (ok) {
            Toast.makeText(this, "✅ تم حفظ النسخة الاحتياطية بنجاح في المجلد المحدد", Toast.LENGTH_SHORT).show();
        } else {
            SharedPreferences sp = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
            String err = sp.getString(BackupHelper.KEY_LAST_ERROR, "خطأ غير معروف");
            new AlertDialog.Builder(this)
                    .setTitle("تعذر حفظ النسخة")
                    .setMessage(err)
                    .setPositiveButton("إغلاق", null)
                    .show();
        }
    }

    private void showChangePasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔑 تغيير كلمة المرور");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(16), dp(20), dp(16));
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        final EditText curPass = new EditText(this);
        curPass.setHint("كلمة المرور الحالية");
        curPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleField(curPass);
        layout.addView(curPass, new LinearLayout.LayoutParams(-1, dp(50)));

        View s1 = new View(this);
        layout.addView(s1, new LinearLayout.LayoutParams(-1, dp(8)));

        final EditText newPass = new EditText(this);
        newPass.setHint("كلمة المرور الجديدة (4 خانات على الأقل)");
        newPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleField(newPass);
        layout.addView(newPass, new LinearLayout.LayoutParams(-1, dp(50)));

        View s2 = new View(this);
        layout.addView(s2, new LinearLayout.LayoutParams(-1, dp(8)));

        final EditText confirmPass = new EditText(this);
        confirmPass.setHint("تأكيد كلمة المرور الجديدة");
        confirmPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleField(confirmPass);
        layout.addView(confirmPass, new LinearLayout.LayoutParams(-1, dp(50)));

        CheckBox toggleVisibility = new CheckBox(this);
        toggleVisibility.setText("إظهار كلمات المرور");
        toggleVisibility.setTextSize(13);
        toggleVisibility.setPadding(dp(4), dp(4), dp(4), dp(4));
        toggleVisibility.setOnCheckedChangeListener((btn, checked) -> {
            int type = checked
                    ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
                    : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            curPass.setInputType(type);
            newPass.setInputType(type);
            confirmPass.setInputType(type);
        });
        layout.addView(toggleVisibility);

        builder.setView(layout);
        builder.setNegativeButton("إلغاء", null);
        builder.setPositiveButton("تأكيد التغيير", null);

        final AlertDialog dialog = builder.create();
        dialog.setOnShowListener(d -> {
            Button submit = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            submit.setOnClickListener(v -> {
                String c = curPass.getText().toString();
                String np = newPass.getText().toString();
                String cp = confirmPass.getText().toString();

                SharedPreferences sec = getSharedPreferences("app_security", MODE_PRIVATE);
                String savedHash = sec.getString("password_hash", "");
                String savedSalt = sec.getString("password_salt", "");

                // Verify current password
                try {
                    byte[] salt = fromHex(savedSalt);
                    if (!MessageDigest.isEqual(hash(c, salt).getBytes(StandardCharsets.UTF_8), savedHash.getBytes(StandardCharsets.UTF_8))) {
                        curPass.setError("كلمة المرور الحالية غير صحيحة");
                        return;
                    }
                } catch (Exception ex) {
                    curPass.setError("خطأ في التحقق من كلمة المرور");
                    return;
                }

                if (np.length() < 4) {
                    newPass.setError("كلمة المرور يجب أن تكون 4 أحرف/أرقام على الأقل");
                    return;
                }

                if (!np.equals(cp)) {
                    confirmPass.setError("كلمتا المرور غير متطابقتين");
                    return;
                }

                byte[] newSaltBytes = new byte[16];
                new SecureRandom().nextBytes(newSaltBytes);
                sec.edit()
                        .putString("password_salt", hex(newSaltBytes))
                        .putString("password_hash", hash(np, newSaltBytes))
                        .apply();

                Toast.makeText(this, "✅ تم تغيير كلمة المرور بنجاح", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private void saveSettings() {
        int[] generalLimits = new int[denominations.length];
        Map<String, Integer> perWorkerLimits = new LinkedHashMap<>();
        SharedPreferences dataPrefs = getSharedPreferences(BackupHelper.PREFS_DATA, MODE_PRIVATE);
        JSONObject appData;
        JSONObject workersObj;

        try {
            for (int i = 0; i < denominations.length; i++) {
                String raw = globalThresholds[i].getText().toString().trim();
                if (raw.isEmpty()) raw = "0";
                if (!raw.matches("\\d+")) {
                    globalThresholds[i].setError("أدخل رقمًا صحيحًا غير سالب");
                    showErrorDialog("خطأ في الإدخال", "يرجى إدخال أرقام صحيحة غير سالبة في حدود المخزون العام لفئة " + denominations[i]);
                    return;
                }
                generalLimits[i] = Integer.parseInt(raw);
            }

            appData = new JSONObject(dataPrefs.getString(BackupHelper.DATA_KEY, "{}"));
            workersObj = appData.optJSONObject("workers");

            for (Map.Entry<String, EditText> entry : workerThresholdInputs.entrySet()) {
                String[] parts = entry.getKey().split("\\|", 2);
                if (parts.length != 2) continue;
                String wName = parts[0];
                String raw = entry.getValue().getText().toString().trim();
                if (raw.isEmpty()) raw = "0";
                if (!raw.matches("\\d+")) {
                    entry.getValue().setError("أدخل رقمًا صحيحًا");
                    showErrorDialog("خطأ في الإدخال", "يرجى التحقق من حد التنبيه للعامل «" + wName + "» فئة " + parts[1]);
                    return;
                }
                perWorkerLimits.put(entry.getKey(), Integer.parseInt(raw));
            }

            if (workersObj != null) {
                for (Map.Entry<String, Integer> entry : perWorkerLimits.entrySet()) {
                    String[] parts = entry.getKey().split("\\|", 2);
                    String wName = parts[0];
                    String denomStr = parts[1];
                    if (workersObj.has(wName)) {
                        workersObj.getJSONObject(wName).put("threshold_" + denomStr, entry.getValue());
                    }
                }
            }
        } catch (Exception ex) {
            showErrorDialog("تعذر حفظ الإعدادات", "حدث خطأ أثناء معالجة البيانات المدخلة: " + ex.getMessage());
            return;
        }

        SharedPreferences p = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = p.edit();
        editor.putBoolean(StockSettings.BACKUP_ENABLED, autoBackupEnabled.isChecked());

        for (int i = 0; i < denominations.length; i++) {
            editor.putInt("threshold_" + denominations[i], generalLimits[i]);
        }
        editor.apply();

        if (workersObj != null) {
            dataPrefs.edit().putString(BackupHelper.DATA_KEY, appData.toString()).apply();
        }

        StockSettings.scheduleBackup(this);
        updateBackupStatusInfo();
        Toast.makeText(this, "✅ تم حفظ جميع الإعدادات والحدود والجدولة بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void showErrorDialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("إغلاق", null)
                .show();
    }

    private String hash(String value, byte[] salt) {
        try {
            javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(value.toCharArray(), salt, 120000, 256);
            byte[] out = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return hex(out);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte x : b) s.append(String.format("%02x", x));
        return s.toString();
    }

    private byte[] fromHex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) {
            b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        }
        return b;
    }
}
