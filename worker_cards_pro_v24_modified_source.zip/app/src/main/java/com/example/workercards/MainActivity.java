package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.text.TextPaint;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    public static final String PREFS = "worker_cards_pro_v24_data";
    private final int[] DENOMS = {100, 200, 250, 500};

    private SharedPreferences prefs;
    private JSONObject data;
    private String selectedWorker = "";
    private LinearLayout workersContainer;
    private EditText[] stockInputs = new EditText[4];
    private TextView[] stockBadges = new TextView[4];
    private EditText messageInput;
    private TextView selectedTextBanner;
    private TextView statsStockTotal;
    private TextView statsWorkersCount;
    private TextView statsAlertBadge;
    private Button undoButton;
    private boolean reloadAfterSettings;

    // Structured item for invoice
    public static class InvoiceRow {
        public String shopName;
        public int denomination;
        public int price;
        public int quantity;
        public int total;

        public InvoiceRow(String shopName, int denomination, int quantity) {
            this.shopName = shopName;
            this.denomination = denomination;
            this.price = salePriceForDenomination(denomination); // سعر البيع الفعلي للفئة
            this.quantity = quantity;
            this.total = this.price * this.quantity;
        }
    }

    private static int salePriceForDenomination(int denomination) {
        switch (denomination) {
            case 100: return 85;
            case 200: return 180;
            case 250: return 225;
            case 500: return 450;
            default: return denomination;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(0xFF0F172A);
            getWindow().setNavigationBarColor(0xFFF8FAFC);
        }

        StockSettings.ensureNotificationChannel(this);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
        }

        StockSettings.scheduleBackup(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadData();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs == null) return;
        loadData();
        updateStockInputsFromData();
        renderWorkers();
        updateSelectedText();
        updateSummaryStats();
        updateUndoButtonState();
        reloadAfterSettings = false;
    }

    private void loadData() {
        try {
            String saved = prefs.getString("data", "");
            if (saved == null || saved.trim().isEmpty()) {
                data = new JSONObject();
                JSONObject stock = new JSONObject();
                for (int denom : DENOMS) stock.put(String.valueOf(denom), 0);
                data.put("stock", stock);
                data.put("workers", new JSONObject());
            } else {
                data = new JSONObject(saved);
            }
            if (data.optJSONObject("stock") == null) data.put("stock", new JSONObject());
            if (data.optJSONObject("workers") == null) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = new JSONObject();
        }
    }

    private void saveData() {
        try {
            JSONObject latest = new JSONObject(prefs.getString("data", "{}"));
            JSONObject latestWorkers = latest.optJSONObject("workers");
            JSONObject currentWorkers = data.optJSONObject("workers");
            if (latestWorkers != null && currentWorkers != null) {
                Iterator<String> names = currentWorkers.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    JSONObject current = currentWorkers.optJSONObject(name);
                    JSONObject saved = latestWorkers.optJSONObject(name);
                    if (current == null || saved == null) continue;
                    for (int denom : DENOMS) {
                        String key = "threshold_" + denom;
                        if (saved.has(key)) current.put(key, saved.optInt(key, 10));
                        else current.remove(key);
                    }
                }
            }
        } catch (Exception ignored) { }
        prefs.edit().putString("data", data.toString()).apply();
        updateSummaryStats();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private Button createButton(String text, int color, int textColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(48));
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackground(rounded(color, 12, color, 1));
        if (Build.VERSION.SDK_INT >= 21) b.setElevation(dp(2));
        return b;
    }

    private Button createButton(String text, int color) {
        return createButton(text, color, Color.WHITE);
    }

    private EditText createNumberInput(int value) {
        EditText e = new EditText(this);
        e.setText(String.valueOf(value));
        e.setTextSize(16);
        e.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        e.setTextColor(0xFF0F172A);
        e.setGravity(Gravity.CENTER);
        e.setInputType(2);
        e.setSingleLine(true);
        e.setPadding(dp(8), dp(8), dp(8), dp(8));
        e.setBackground(rounded(0xFFF8FAFC, 10, 0xFFCBD5E1, 1));
        return e;
    }

    private LinearLayout createSectionCard(String titleText, String subtitleText) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(18));
        l.setBackground(rounded(Color.WHITE, 18, 0xFFE2E8F0, 1));
        if (Build.VERSION.SDK_INT >= 21) l.setElevation(dp(3));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(6), 0, dp(10));
        l.setLayoutParams(p);

        if (titleText != null) {
            TextView t = new TextView(this);
            t.setText(titleText);
            t.setTextSize(18);
            t.setTextColor(0xFF0F172A);
            t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            t.setGravity(Gravity.RIGHT);
            t.setPadding(0, 0, 0, dp(2));
            l.addView(t);
        }

        if (subtitleText != null) {
            TextView s = new TextView(this);
            s.setText(subtitleText);
            s.setTextSize(13);
            s.setTextColor(0xFF64748B);
            s.setGravity(Gravity.RIGHT);
            s.setPadding(0, 0, 0, dp(10));
            l.addView(s);
        }

        return l;
    }

    private LinearLayout createRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return r;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF8FAFC);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(32));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // ==========================================
        // 1. HERO HEADER (Dark Navy Elegance)
        // ==========================================
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(20), dp(18), dp(20), dp(20));
        hero.setBackground(rounded(0xFF0F172A, 22, 0xFF0F172A, 1));
        if (Build.VERSION.SDK_INT >= 21) hero.setElevation(dp(5));

        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, -2);
        heroParams.setMargins(0, 0, 0, dp(12));
        content.addView(hero, heroParams);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.workercards.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("شعار شبكة الكامل");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(80));
        logoParams.setMargins(0, 0, 0, dp(8));
        hero.addView(logo, logoParams);

        TextView header = new TextView(this);
        header.setText("إدارة كروت الكامل V24");
        header.setTextSize(22);
        header.setTextColor(Color.WHITE);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.setGravity(Gravity.CENTER);
        hero.addView(header);

        TextView sub = new TextView(this);
        sub.setText("النظام المتكامل لإدارة المخزون، توزيع الحصص، والخصم التلقائي");
        sub.setTextSize(13);
        sub.setTextColor(0xFFCBD5E1);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, 0);
        hero.addView(sub);

        // ==========================================
        // 2. SUMMARY / DASHBOARD WIDGET
        // ==========================================
        LinearLayout statsCard = new LinearLayout(this);
        statsCard.setOrientation(LinearLayout.HORIZONTAL);
        statsCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        statsCard.setBackground(rounded(Color.WHITE, 16, 0xFFE2E8F0, 1));
        if (Build.VERSION.SDK_INT >= 21) statsCard.setElevation(dp(3));
        statsCard.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(-1, -2);
        scp.setMargins(0, 0, 0, dp(12));
        content.addView(statsCard, scp);

        // Total Stock Pill
        LinearLayout stat1 = new LinearLayout(this);
        stat1.setOrientation(LinearLayout.VERTICAL);
        stat1.setGravity(Gravity.CENTER);
        stat1.setBackground(rounded(0xFFF1F5F9, 12, 0xFFE2E8F0, 1));
        stat1.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams s1p = new LinearLayout.LayoutParams(0, -2, 1f);
        s1p.setMargins(dp(3), 0, dp(3), 0);

        TextView stat1Title = new TextView(this);
        stat1Title.setText("إجمالي المخزون العام");
        stat1Title.setTextSize(11);
        stat1Title.setTextColor(0xFF64748B);
        stat1.addView(stat1Title);

        statsStockTotal = new TextView(this);
        statsStockTotal.setText("0 كرت");
        statsStockTotal.setTextSize(16);
        statsStockTotal.setTextColor(0xFF0F172A);
        statsStockTotal.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stat1.addView(statsStockTotal);
        statsCard.addView(stat1, s1p);

        // Total Workers Pill
        LinearLayout stat2 = new LinearLayout(this);
        stat2.setOrientation(LinearLayout.VERTICAL);
        stat2.setGravity(Gravity.CENTER);
        stat2.setBackground(rounded(0xFFF1F5F9, 12, 0xFFE2E8F0, 1));
        stat2.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams s2p = new LinearLayout.LayoutParams(0, -2, 1f);
        s2p.setMargins(dp(3), 0, dp(3), 0);

        TextView stat2Title = new TextView(this);
        stat2Title.setText("العمال المسجلون");
        stat2Title.setTextSize(11);
        stat2Title.setTextColor(0xFF64748B);
        stat2.addView(stat2Title);

        statsWorkersCount = new TextView(this);
        statsWorkersCount.setText("0 عامل");
        statsWorkersCount.setTextSize(16);
        statsWorkersCount.setTextColor(0xFF2563EB);
        statsWorkersCount.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stat2.addView(statsWorkersCount);
        statsCard.addView(stat2, s2p);

        // Stock Health Badge
        LinearLayout stat3 = new LinearLayout(this);
        stat3.setOrientation(LinearLayout.VERTICAL);
        stat3.setGravity(Gravity.CENTER);
        stat3.setBackground(rounded(0xFFECFDF5, 12, 0xFFA7F3D0, 1));
        stat3.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams s3p = new LinearLayout.LayoutParams(0, -2, 1f);
        s3p.setMargins(dp(3), 0, dp(3), 0);

        TextView stat3Title = new TextView(this);
        stat3Title.setText("حالة المخزون");
        stat3Title.setTextSize(11);
        stat3Title.setTextColor(0xFF065F46);
        stat3.addView(stat3Title);

        statsAlertBadge = new TextView(this);
        statsAlertBadge.setText("مستقر");
        statsAlertBadge.setTextSize(14);
        statsAlertBadge.setTextColor(0xFF059669);
        statsAlertBadge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stat3.addView(statsAlertBadge);
        statsCard.addView(stat3, s3p);

        // ==========================================
        // 3. SETTINGS NAVIGATION BAR (Clean & Prominent)
        // (تم نقل أزرار تصدير واستعادة النسخ إلى داخل الإعدادات)
        // ==========================================
        Button settingsBtn = createButton("⚙  إعدادات النسخ والتنبيهات والأمان", 0xFF6D28D9);
        settingsBtn.setTextSize(15);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(50));
        sp.setMargins(0, 0, 0, dp(12));
        settingsBtn.setLayoutParams(sp);
        settingsBtn.setOnClickListener(v -> {
            reloadAfterSettings = true;
            startActivity(new Intent(this, BackupSettingsActivity.class));
        });
        content.addView(settingsBtn);

        // ==========================================
        // 4. GENERAL STOCK (المخزون العام)
        // ==========================================
        LinearLayout stockCard = createSectionCard("📦  المخزون العام",
                "أدخل الكميات المتوفرة في المخزون الرئيسي واضغط حفظ لحمايتها وتحديث التنبيهات");

        LinearLayout stockGrid = new LinearLayout(this);
        stockGrid.setOrientation(LinearLayout.VERTICAL);
        stockGrid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        for (int r = 0; r < DENOMS.length; r += 2) {
            LinearLayout row = createRow();
            for (int c = r; c < Math.min(r + 2, DENOMS.length); c++) {
                final int denom = DENOMS[c];
                final int index = c;

                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(dp(10), dp(10), dp(10), dp(12));
                cell.setBackground(rounded(0xFFF8FAFC, 14, 0xFFE2E8F0, 1));

                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
                cp.setMargins(dp(4), dp(4), dp(4), dp(4));

                TextView dTitle = new TextView(this);
                dTitle.setText("فئة " + denom);
                dTitle.setTextSize(16);
                dTitle.setTextColor(0xFF0F172A);
                dTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                cell.addView(dTitle);

                stockBadges[index] = new TextView(this);
                stockBadges[index].setTextSize(11);
                stockBadges[index].setPadding(dp(8), dp(2), dp(8), dp(2));
                stockBadges[index].setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
                bp.setMargins(0, dp(2), 0, dp(6));
                cell.addView(stockBadges[index], bp);

                int val = data.optJSONObject("stock") != null ? data.optJSONObject("stock").optInt(String.valueOf(denom), 0) : 0;
                stockInputs[index] = createNumberInput(val);
                cell.addView(stockInputs[index], new LinearLayout.LayoutParams(-1, dp(48)));

                row.addView(cell, cp);
            }
            stockGrid.addView(row);
        }
        stockCard.addView(stockGrid);

        View spacer = new View(this);
        stockCard.addView(spacer, new LinearLayout.LayoutParams(-1, dp(10)));

        Button saveStockBtn = createButton("💾  حفظ المخزون العام", 0xFF059669);
        saveStockBtn.setOnClickListener(v -> saveGeneralStock());
        stockCard.addView(saveStockBtn);

        content.addView(stockCard);

        // ==========================================
        // 5. WORKERS SECTION (إدارة العمال)
        // ==========================================
        LinearLayout workersCard = createSectionCard("👥  إدارة العمال وحصص الكروت",
                "كل عامل يمتلك رصيدًا مستقلًا لكل فئة. يمكنك تعديل الرصيد، التغذية، أو الخصم بدقة");

        Button addWorkerBtn = createButton("＋  إضافة عامل جديد", 0xFF2563EB);
        addWorkerBtn.setOnClickListener(v -> showAddWorkerDialog());
        workersCard.addView(addWorkerBtn);

        selectedTextBanner = new TextView(this);
        selectedTextBanner.setTextSize(14);
        selectedTextBanner.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selectedTextBanner.setPadding(dp(12), dp(10), dp(12), dp(10));
        selectedTextBanner.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams selParams = new LinearLayout.LayoutParams(-1, -2);
        selParams.setMargins(0, dp(10), 0, dp(8));
        workersCard.addView(selectedTextBanner, selParams);

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        workersContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        workersCard.addView(workersContainer);

        content.addView(workersCard);

        // ==========================================
        // 6. MESSAGE DEDUCTION & CALCULATION (رسالة الخصم)
        // ==========================================
        LinearLayout msgCard = createSectionCard("📨  رسالة التوزيع والخصم الفوري",
                "اختر العامل، ثم الصق الرسالة كاملة. سيتم فحص كل مجموعة وتوليد الفاتورة والخصم");

        LinearLayout hintBox = new LinearLayout(this);
        hintBox.setOrientation(LinearLayout.VERTICAL);
        hintBox.setBackground(rounded(0xFFEFF6FF, 12, 0xFFBFDBFE, 1));
        hintBox.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView hintTitle = new TextView(this);
        hintTitle.setText("💡 صيغة أسطر التقرير:");
        hintTitle.setTextSize(13);
        hintTitle.setTextColor(0xFF1E3A8A);
        hintTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hintBox.addView(hintTitle);

        TextView hintDesc = new TextView(this);
        hintDesc.setText("اسم المحل / العميل يليه 4 أرقام مفصولة بشرطات:\n(فئة 100 - فئة 200 - فئة 250 - فئة 500)\nمثال:\nبقالة النور\n10-5-2-0\nسوبرماركت الأمل\n0-10-15-5");
        hintDesc.setTextSize(12);
        hintDesc.setTextColor(0xFF1E40AF);
        hintDesc.setGravity(Gravity.RIGHT);
        hintBox.addView(hintDesc);
        msgCard.addView(hintBox);

        View mSpacer = new View(this);
        msgCard.addView(mSpacer, new LinearLayout.LayoutParams(-1, dp(10)));

        messageInput = new EditText(this);
        messageInput.setTextSize(15);
        messageInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        messageInput.setHint("الصق رسالة العامل هنا بالصيغة الموضحة أعلاه...");
        messageInput.setMinLines(5);
        messageInput.setInputType(1 | 0x00008000);
        messageInput.setBackground(rounded(0xFFF8FAFC, 12, 0xFFCBD5E1, 1));
        messageInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        msgCard.addView(messageInput, new LinearLayout.LayoutParams(-1, dp(150)));

        View bSpacer = new View(this);
        msgCard.addView(bSpacer, new LinearLayout.LayoutParams(-1, dp(12)));

        Button calcBtn = createButton("✓  تحقق ثم احسب واخصم وأنشئ الفاتورة", 0xFF2563EB);
        calcBtn.setTextSize(16);
        calcBtn.setMinHeight(dp(52));
        calcBtn.setOnClickListener(v -> calculateAndDeduct());
        msgCard.addView(calcBtn);

        View uSpacer = new View(this);
        msgCard.addView(uSpacer, new LinearLayout.LayoutParams(-1, dp(8)));

        undoButton = createButton("↶  التراجع عن آخر عملية", 0xFFDC2626);
        undoButton.setTextSize(14);
        undoButton.setMinHeight(dp(44));
        undoButton.setOnClickListener(v -> undoLastOperation());
        msgCard.addView(undoButton);

        content.addView(msgCard);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);

        updateStockInputsFromData();
        renderWorkers();
        updateSelectedText();
        updateSummaryStats();
        updateUndoButtonState();
    }

    private void updateStockInputsFromData() {
        JSONObject stock = data != null ? data.optJSONObject("stock") : null;
        SharedPreferences alertPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
        for (int i = 0; i < DENOMS.length; i++) {
            int denom = DENOMS[i];
            int val = stock != null ? stock.optInt(String.valueOf(denom), 0) : 0;
            if (stockInputs[i] != null) {
                stockInputs[i].setText(String.valueOf(val));
            }
            int threshold = alertPrefs.getInt("threshold_" + denom, 10);
            if (stockBadges[i] != null) {
                if (val == 0) {
                    stockBadges[i].setText("🚨 نفد تمامًا");
                    stockBadges[i].setTextColor(0xFFDC2626);
                    stockBadges[i].setBackground(rounded(0xFFFEE2E2, 6, 0xFFFCA5A5, 1));
                } else if (val <= threshold) {
                    stockBadges[i].setText("⚠️ منخفض (" + val + ")");
                    stockBadges[i].setTextColor(0xFFD97706);
                    stockBadges[i].setBackground(rounded(0xFFFEF3C7, 6, 0xFFFDE68A, 1));
                } else {
                    stockBadges[i].setText("✅ متاح (" + val + ")");
                    stockBadges[i].setTextColor(0xFF059669);
                    stockBadges[i].setBackground(rounded(0xFFD1FAE5, 6, 0xFFA7F3D0, 1));
                }
            }
        }
    }

    private void updateSummaryStats() {
        if (statsStockTotal == null || data == null) return;
        JSONObject stock = data.optJSONObject("stock");
        int totalCards = 0;
        boolean hasWarning = false;
        SharedPreferences alertPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);

        if (stock != null) {
            for (int denom : DENOMS) {
                int val = stock.optInt(String.valueOf(denom), 0);
                totalCards += val;
                int threshold = alertPrefs.getInt("threshold_" + denom, 10);
                if (val <= threshold) hasWarning = true;
            }
        }
        statsStockTotal.setText(totalCards + " كرت");

        JSONObject workers = data.optJSONObject("workers");
        int countWorkers = workers != null ? workers.length() : 0;
        statsWorkersCount.setText(countWorkers + " عامل");

        if (statsAlertBadge != null) {
            if (hasWarning) {
                statsAlertBadge.setText("⚠️ يحتاج تغذية");
                statsAlertBadge.setTextColor(0xFFD97706);
            } else {
                statsAlertBadge.setText("✅ آمن ومستقر");
                statsAlertBadge.setTextColor(0xFF059669);
            }
        }
    }

    private void updateUndoButtonState() {
        if (undoButton == null) return;
        boolean available = prefs != null && prefs.getBoolean("last_undo_available", false);
        undoButton.setEnabled(available);
        undoButton.setAlpha(available ? 1.0f : 0.45f);
    }

    private void saveGeneralStock() {
        try {
            int[] values = new int[DENOMS.length];
            for (int i = 0; i < DENOMS.length; i++) {
                String raw = stockInputs[i].getText().toString().trim();
                if (raw.isEmpty()) raw = "0";
                if (!raw.matches("\\d+")) {
                    stockInputs[i].setError("أدخل عددًا صحيحًا غير سالب");
                    showErrorDialog("تعذر حفظ المخزون العام", "يرجى إدخال أعداد صحيحة غير سالبة لجميع الفئات.");
                    return;
                }
                values[i] = Integer.parseInt(raw);
            }
            JSONObject stock = data.getJSONObject("stock");
            for (int i = 0; i < DENOMS.length; i++) stock.put(String.valueOf(DENOMS[i]), values[i]);
            saveData();
            updateStockInputsFromData();
            checkAndNotifyStock("المخزون العام", stock);
            showSuccessToast("تم حفظ وتحديث المخزون العام بنجاح");
        } catch (Exception e) {
            showErrorDialog("خطأ", "حدث خطأ غير متوقع أثناء حفظ المخزون: " + e.getMessage());
        }
    }

    private void showAddWorkerDialog() {
        final EditText nameInput = new EditText(this);
        nameInput.setHint("اكتب اسم العامل (مثال: محمد علي)");
        nameInput.setTextSize(16);
        nameInput.setGravity(Gravity.RIGHT);
        nameInput.setSingleLine(true);
        nameInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        nameInput.setBackground(rounded(0xFFF8FAFC, 10, 0xFFCBD5E1, 1));

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("إضافة عامل جديد")
                .setMessage("سيتم إنشاء سجل جديد للعامل مع رصيد صفر لجميع الفئات.")
                .setView(nameInput)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إضافة العامل", null)
                .create();

        d.setOnShowListener(dialogInterface -> {
            Button btn = d.getButton(AlertDialog.BUTTON_POSITIVE);
            btn.setOnClickListener(v -> {
                String n = nameInput.getText().toString().trim();
                if (n.isEmpty()) {
                    nameInput.setError("يرجى كتابة اسم العامل");
                    return;
                }
                try {
                    JSONObject workers = data.getJSONObject("workers");
                    if (workers.has(n)) {
                        selectedWorker = n;
                        saveData();
                        renderWorkers();
                        updateSelectedText();
                        showSuccessToast("العامل موجود مسبقًا وتم اختياره: " + n);
                        d.dismiss();
                        return;
                    }
                    JSONObject w = new JSONObject();
                    for (int den : DENOMS) w.put(String.valueOf(den), 0);
                    workers.put(n, w);
                    selectedWorker = n;
                    saveData();
                    renderWorkers();
                    updateSelectedText();
                    showSuccessToast("تمت إضافة العامل «" + n + "» بنجاح");
                    d.dismiss();
                } catch (Exception e) {
                    showErrorDialog("خطأ", "تعذر إضافة العامل: " + e.getMessage());
                }
            });
        });
        d.show();
    }

    private void renderWorkers() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            JSONArray names = workers.names();
            if (names == null || names.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("لا يوجد عمال مسجلون حاليًا. اضغط «إضافة عامل جديد» للبدء.");
                empty.setTextSize(14);
                empty.setTextColor(0xFF64748B);
                empty.setGravity(Gravity.CENTER);
                empty.setPadding(dp(8), dp(16), dp(8), dp(16));
                workersContainer.addView(empty);
                return;
            }
            for (int x = 0; x < names.length(); x++) {
                String name = names.getString(x);
                JSONObject w = workers.getJSONObject(name);
                addWorkerCard(name, w);
            }
        } catch (Exception ignored) { }
    }

    private void addWorkerCard(String name, JSONObject w) {
        boolean isSelected = selectedWorker.equals(name);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(isSelected ? 0xFFF0FDF4 : 0xFFF8FAFC, 16,
                isSelected ? 0xFF86EFAC : 0xFFE2E8F0, isSelected ? 2 : 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(2));

        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.setMargins(0, dp(6), 0, dp(8));
        card.setLayoutParams(clp);

        // Header: Worker Name + Selection Badge
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView nameTv = new TextView(this);
        nameTv.setText("👤 " + name);
        nameTv.setTextSize(17);
        nameTv.setTextColor(0xFF0F172A);
        nameTv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        topRow.addView(nameTv, new LinearLayout.LayoutParams(0, -2, 1f));

        if (isSelected) {
            TextView selBadge = new TextView(this);
            selBadge.setText("العامل المختار ✓");
            selBadge.setTextSize(12);
            selBadge.setTextColor(0xFF065F46);
            selBadge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            selBadge.setBackground(rounded(0xFFDCFCE7, 8, 0xFF86EFAC, 1));
            selBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
            topRow.addView(selBadge);
        }
        card.addView(topRow);

        // Phone Input
        EditText phoneInput = new EditText(this);
        phoneInput.setHint("رقم هاتف العامل للواتساب (مثال: +967...)");
        phoneInput.setTextSize(14);
        phoneInput.setSingleLine(true);
        phoneInput.setInputType(3);
        phoneInput.setText(w.optString("phone", ""));
        phoneInput.setBackground(rounded(Color.WHITE, 8, 0xFFCBD5E1, 1));
        phoneInput.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams pip = new LinearLayout.LayoutParams(-1, dp(44));
        pip.setMargins(0, dp(8), 0, dp(8));
        card.addView(phoneInput, pip);

        // 4 Category Inputs & Statuses
        LinearLayout catGrid = new LinearLayout(this);
        catGrid.setOrientation(LinearLayout.HORIZONTAL);
        catGrid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        final EditText[] workerInputs = new EditText[DENOMS.length];
        for (int i = 0; i < DENOMS.length; i++) {
            final int denom = DENOMS[i];
            int val = w.optInt(String.valueOf(denom), 0);
            int threshold = w.optInt("threshold_" + denom, 10);

            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(dp(4), dp(6), dp(4), dp(6));
            cell.setBackground(rounded(Color.WHITE, 10, val <= threshold ? 0xFFFCA5A5 : 0xFFE2E8F0, 1));

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            cp.setMargins(dp(2), 0, dp(2), 0);

            TextView dLab = new TextView(this);
            dLab.setText("فئة " + denom);
            dLab.setTextSize(12);
            dLab.setTextColor(0xFF475569);
            dLab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            cell.addView(dLab);

            workerInputs[i] = createNumberInput(val);
            workerInputs[i].setTextSize(14);
            workerInputs[i].setPadding(dp(4), dp(6), dp(4), dp(6));
            cell.addView(workerInputs[i]);

            catGrid.addView(cell, cp);
        }
        card.addView(catGrid);

        View btnSpacer = new View(this);
        card.addView(btnSpacer, new LinearLayout.LayoutParams(-1, dp(10)));

        // Action Buttons Row 1: Save Stock + Add Quantities
        LinearLayout actRow1 = createRow();

        Button saveWorkerBtn = createButton("💾 حفظ المخزون", 0xFF059669);
        saveWorkerBtn.setTextSize(13);
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        sp1.setMargins(dp(2), 0, dp(2), 0);
        saveWorkerBtn.setLayoutParams(sp1);
        saveWorkerBtn.setOnClickListener(v -> {
            try {
                JSONObject nw = new JSONObject();
                for (int i = 0; i < DENOMS.length; i++) {
                    String raw = workerInputs[i].getText().toString().trim();
                    if (raw.isEmpty()) raw = "0";
                    if (!raw.matches("\\d+")) {
                        workerInputs[i].setError("أدخل رقمًا صحيحًا");
                        showErrorDialog("خطأ", "يجب إدخال أرقام صحيحة غير سالبة لكل فئات كروت العامل.");
                        return;
                    }
                    nw.put(String.valueOf(DENOMS[i]), Integer.parseInt(raw));
                }
                nw.put("phone", phoneInput.getText().toString().trim());
                for (int denom : DENOMS) {
                    String tKey = "threshold_" + denom;
                    if (w.has(tKey)) nw.put(tKey, w.optInt(tKey, 10));
                }
                data.getJSONObject("workers").put(name, nw);
                saveData();
                renderWorkers();
                checkAndNotifyStock("مخزون العامل " + name, nw);
                showSuccessToast("تم حفظ رصيد العامل «" + name + "» بنجاح");
            } catch (Exception ex) {
                showErrorDialog("خطأ", "تعذر حفظ مخزون العامل: " + ex.getMessage());
            }
        });
        actRow1.addView(saveWorkerBtn);

        Button addStockBtn = createButton("＋ إضافة كميات", 0xFF0284C7);
        addStockBtn.setTextSize(13);
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(0, dp(44), 1f);
        sp2.setMargins(dp(2), 0, dp(2), 0);
        addStockBtn.setLayoutParams(sp2);
        addStockBtn.setOnClickListener(v -> showAddStockDialog(name));
        actRow1.addView(addStockBtn);

        card.addView(actRow1);

        View rSpacer = new View(this);
        card.addView(rSpacer, new LinearLayout.LayoutParams(-1, dp(6)));

        // Action Buttons Row 2: Select Worker + Delete Worker
        LinearLayout actRow2 = createRow();

        Button selectBtn = createButton(isSelected ? "العامل المختار ✓" : "اختيار للخصم",
                isSelected ? 0xFF065F46 : 0xFF2563EB);
        selectBtn.setTextSize(13);
        LinearLayout.LayoutParams selLp = new LinearLayout.LayoutParams(0, dp(44), 1.2f);
        selLp.setMargins(dp(2), 0, dp(2), 0);
        selectBtn.setLayoutParams(selLp);
        selectBtn.setOnClickListener(v -> {
            selectedWorker = name;
            updateSelectedText();
            renderWorkers();
            showSuccessToast("تم اختيار العامل: " + name);
        });
        actRow2.addView(selectBtn);

        Button deleteBtn = createButton("حذف", 0xFFDC2626);
        deleteBtn.setTextSize(13);
        LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(0, dp(44), 0.8f);
        delLp.setMargins(dp(2), 0, dp(2), 0);
        deleteBtn.setLayoutParams(delLp);
        deleteBtn.setOnClickListener(v -> confirmDelete(name));
        actRow2.addView(deleteBtn);

        card.addView(actRow2);

        workersContainer.addView(card);
    }

    private void updateSelectedText() {
        if (selectedTextBanner != null) {
            if (selectedWorker.isEmpty()) {
                selectedTextBanner.setText("⚠️ لم يتم اختيار أي عامل لتنفيذ عمليات الخصم");
                selectedTextBanner.setTextColor(0xFFD97706);
                selectedTextBanner.setBackground(rounded(0xFFFFFBEB, 10, 0xFFFDE68A, 1));
            } else {
                selectedTextBanner.setText("العامل المختار للخصم حاليًا:  «" + selectedWorker + "»  ✓");
                selectedTextBanner.setTextColor(0xFF1E40AF);
                selectedTextBanner.setBackground(rounded(0xFFEFF6FF, 10, 0xFFBFDBFE, 1));
            }
        }
    }

    private void showAddStockDialog(String name) {
        try {
            JSONObject worker = data.getJSONObject("workers").getJSONObject(name);
            JSONObject general = data.getJSONObject("stock");

            Dialog screen = new Dialog(this);
            screen.requestWindowFeature(Window.FEATURE_NO_TITLE);

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setPadding(dp(20), dp(18), dp(20), dp(20));
            root.setBackgroundColor(0xFFF8FAFC);
            root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            TextView heading = new TextView(this);
            heading.setText("إضافة وتغذية كروت للعامل");
            heading.setTextSize(20);
            heading.setTextColor(0xFF0F172A);
            heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            root.addView(heading);

            TextView workerLabel = new TextView(this);
            workerLabel.setText("👤 العامل: " + name);
            workerLabel.setTextSize(16);
            workerLabel.setTextColor(0xFF2563EB);
            workerLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            workerLabel.setPadding(0, dp(4), 0, dp(6));
            root.addView(workerLabel);

            TextView note = new TextView(this);
            note.setText("أدخل الكميات الجديدة المضافة فقط. ستُضاف إلى رصيد العامل وتُخصم من المخزون العام تلقائيًا.");
            note.setTextSize(13);
            note.setTextColor(0xFF64748B);
            note.setGravity(Gravity.RIGHT);
            note.setPadding(0, 0, 0, dp(12));
            root.addView(note);

            ScrollView scroll = new ScrollView(this);
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);

            EditText[] adds = new EditText[4];

            for (int i = 0; i < 4; i++) {
                int denom = DENOMS[i];
                LinearLayout categoryCard = new LinearLayout(this);
                categoryCard.setOrientation(LinearLayout.VERTICAL);
                categoryCard.setPadding(dp(12), dp(10), dp(12), dp(12));
                categoryCard.setBackground(rounded(Color.WHITE, 12, 0xFFE2E8F0, 1));
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
                clp.setMargins(0, dp(4), 0, dp(6));
                categoryCard.setLayoutParams(clp);

                TextView label = new TextView(this);
                label.setText("فئة " + denom + " كرت");
                label.setTextSize(15);
                label.setTextColor(0xFF0F172A);
                label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                categoryCard.addView(label);

                int wVal = worker.optInt(String.valueOf(denom), 0);
                int gVal = general.optInt(String.valueOf(denom), 0);

                TextView avail = new TextView(this);
                avail.setText("رصيد العامل الحالي: " + wVal + " كرت  |  المتاح بالمخزون العام: " + gVal + " كرت");
                avail.setTextSize(12);
                avail.setTextColor(0xFF475569);
                avail.setPadding(0, dp(2), 0, dp(6));
                categoryCard.addView(avail);

                adds[i] = createNumberInput(0);
                adds[i].setHint("الكمية المضافة الجديدة فقط");
                categoryCard.addView(adds[i], new LinearLayout.LayoutParams(-1, dp(48)));

                panel.addView(categoryCard);
            }
            scroll.addView(panel);
            root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

            LinearLayout actions = createRow();
            Button cancel = createButton("إلغاء", 0xFF64748B);
            cancel.setOnClickListener(v -> screen.dismiss());
            Button apply = createButton("تأكيد الإضافة والتغذية", 0xFF059669);

            actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 1f));
            View spacer = new View(this);
            actions.addView(spacer, new LinearLayout.LayoutParams(dp(8), dp(48)));
            actions.addView(apply, new LinearLayout.LayoutParams(0, dp(48), 1.5f));
            root.addView(actions);

            apply.setOnClickListener(v -> {
                try {
                    JSONObject currentWorker = data.getJSONObject("workers").getJSONObject(name);
                    JSONObject stock = data.getJSONObject("stock");
                    JSONObject oldWorker = new JSONObject(currentWorker.toString());
                    JSONObject oldStock = new JSONObject(stock.toString());

                    int[] amounts = new int[4];
                    boolean any = false;

                    for (int i = 0; i < 4; i++) {
                        String key = String.valueOf(DENOMS[i]);
                        String raw = adds[i].getText().toString().trim();
                        if (raw.isEmpty()) raw = "0";
                        if (!raw.matches("\\d+")) {
                            adds[i].setError("أدخل رقمًا صحيحًا");
                            showErrorDialog("خطأ في الكمية", "يرجى إدخال أرقام صحيحة غير سالبة لجميع الفئات.");
                            return;
                        }
                        amounts[i] = Integer.parseInt(raw);
                        any |= amounts[i] > 0;

                        if (amounts[i] > stock.optInt(key, 0)) {
                            adds[i].setError("المخزون العام لا يكفي (المتاح " + stock.optInt(key, 0) + ")");
                            showErrorDialog("المخزون العام غير كافٍ",
                                    "تعذر إتمام الإضافة: رصيد فئة " + key + " بالمخزون العام هو " + stock.optInt(key, 0) +
                                            " كرت، بينما طلبت إضافة " + amounts[i] + " كرت. لم يتم تغيير أي رصيد.");
                            return;
                        }
                    }

                    if (!any) {
                        showErrorDialog("تنبيه", "يرجى إدخال كمية مضافة أكبر من الصفر في فئة واحدة على الأقل.");
                        return;
                    }

                    for (int i = 0; i < 4; i++) {
                        String key = String.valueOf(DENOMS[i]);
                        currentWorker.put(key, currentWorker.optInt(key, 0) + amounts[i]);
                        stock.put(key, stock.optInt(key, 0) - amounts[i]);
                    }

                    saveData();

                    prefs.edit()
                            .putString("last_undo_worker", name)
                            .putString("last_undo_worker_json", oldWorker.toString())
                            .putString("last_undo_stock_json", oldStock.toString())
                            .putBoolean("last_undo_available", true)
                            .apply();

                    renderWorkers();
                    updateStockInputsFromData();
                    updateUndoButtonState();
                    checkAndNotifyStock("مخزون العامل " + name, currentWorker);
                    checkAndNotifyStock("المخزون العام", stock);

                    showSuccessToast("تمت إضافة الكروت بنجاح وخصمها من المخزون العام");
                    screen.dismiss();

                    int prevTotal = 0, addTotal = 0, finalTotal = 0;
                    List<String[]> catRows = new ArrayList<>();

                    for (int i = 0; i < 4; i++) {
                        int oldVal = oldWorker.optInt(String.valueOf(DENOMS[i]), 0);
                        int addVal = amounts[i];
                        int newVal = currentWorker.optInt(String.valueOf(DENOMS[i]), 0);

                        prevTotal += oldVal;
                        addTotal += addVal;
                        finalTotal += newVal;

                        catRows.add(new String[]{
                                "فئة " + DENOMS[i],
                                String.valueOf(oldVal),
                                "+" + addVal,
                                String.valueOf(newVal)
                        });
                    }

                    List<String> summaryLines = new ArrayList<>();
                    summaryLines.add("إجمالي الرصيد السابق: " + prevTotal + " كرت");
                    summaryLines.add("إجمالي الكميات المضافة: " + addTotal + " كرت");
                    summaryLines.add("إجمالي الرصيد النهائي بعد الإضافة: " + finalTotal + " كرت");

                    sendWorkerReportImage(name, "إضافة وتغذية كروت", catRows, null, summaryLines, 0xFF059669);

                } catch (Exception ex) {
                    showErrorDialog("خطأ", "تعذر إتمام الإضافة: " + ex.getMessage());
                }
            });

            screen.setContentView(root);
            if (screen.getWindow() != null) {
                screen.getWindow().setLayout(-1, -1);
            }
            screen.show();
        } catch (Exception ex) {
            showErrorDialog("خطأ", "تعذر فتح نافذة إضافة الكروت.");
        }
    }

    private void confirmDelete(String name) {
        if (name.equals(selectedWorker)) selectedWorker = "";
        new AlertDialog.Builder(this)
                .setTitle("تأكيد حذف العامل")
                .setMessage("هل تريد بالتأكيد حذف العامل «" + name + "» وكافة بيانات مخزونه نهائيًا؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف نهائي", (d, w) -> {
                    try {
                        data.getJSONObject("workers").remove(name);
                        saveData();
                        renderWorkers();
                        updateSelectedText();
                        showSuccessToast("تم حذف العامل «" + name + "»");
                    } catch (Exception e) {
                        showErrorDialog("خطأ", "تعذر حذف العامل: " + e.getMessage());
                    }
                }).show();
    }

    private void calculateAndDeduct() {
        String name = selectedWorker;
        if (name == null || name.trim().isEmpty()) {
            showErrorDialog("لم يتم اختيار عامل", "يرجى اختيار العامل المراد الخصم من رصيده أولًا بالضغط على زر «اختيار للخصم» في بطاقة العامل.");
            return;
        }

        String rawText = messageInput.getText().toString();
        if (rawText.trim().isEmpty()) {
            showErrorDialog("الرسالة فارغة", "يرجى لصق رسالة العامل التي تحتوي على تفاصيل المجموعات والكميات.");
            return;
        }

        int[] totalUsed = {0, 0, 0, 0};
        int groupCount = 0;
        String currentCustomer = null;
        Set<String> seenNames = new HashSet<>();
        StringBuilder errors = new StringBuilder();

        List<InvoiceRow> invoiceRows = new ArrayList<>();
        String[] lines = rawText.split("\\r?\\n", -1);
        Pattern valuesPattern = Pattern.compile("^(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)$");
        Pattern malformedValuesPattern = Pattern.compile("^\\d+(?:\\s*-\\s*\\d+){1,3}$");

        for (int li = 0; li < lines.length; li++) {
            String rawLine = lines[li].trim();
            String line = rawLine.replace("……", "").replace("...", "").replace("......", "").trim();
            if (line.isEmpty()) continue;

            Matcher vm = valuesPattern.matcher(line);
            if (vm.matches()) {
                if (currentCustomer == null || currentCustomer.trim().isEmpty()) {
                    errors.append("السطر ").append(li + 1).append(": توجد أرقام كروت دون كتابة اسم المحل أو العميل قبلها.\n");
                    continue;
                }
                int[] row = new int[4];
                try {
                    for (int i = 0; i < 4; i++) {
                        row[i] = Integer.parseInt(vm.group(i + 1));
                        if (row[i] < 0) throw new NumberFormatException();
                        totalUsed[i] = Math.addExact(totalUsed[i], row[i]);

                        // Add distinct row for each non-zero denomination for this shop
                        if (row[i] > 0) {
                            invoiceRows.add(new InvoiceRow(currentCustomer, DENOMS[i], row[i]));
                        }
                    }
                } catch (Exception ex) {
                    errors.append("السطر ").append(li + 1).append(" (").append(currentCustomer).append("): أرقام الكميات غير صالحة.\n");
                    continue;
                }
                groupCount++;
                currentCustomer = null;
            } else {
                if (malformedValuesPattern.matcher(line).matches()) {
                    errors.append("السطر ").append(li + 1).append(": صيغة أرقام غير مكتملة. يجب إدخال 4 أرقام مفصولة بشرطات (مثل: 10-20-5-0). المدخل: ").append(line).append("\n");
                    continue;
                }
                if (currentCustomer != null) {
                    errors.append("السطر ").append(li + 1).append(": الاسم «").append(line)
                            .append("» ورد قبل تسجيل أرقام الاسم السابق «").append(currentCustomer).append("».\n");
                }
                currentCustomer = line;
                if (seenNames.contains(currentCustomer)) {
                    errors.append("السطر ").append(li + 1).append(": الاسم «").append(currentCustomer).append("» مكرر في الرسالة.\n");
                } else {
                    seenNames.add(currentCustomer);
                }
            }
        }

        if (currentCustomer != null) {
            errors.append("الاسم «").append(currentCustomer).append("» في نهاية الرسالة ليس له أرقام كميات.\n");
        }

        if (groupCount == 0 && errors.length() == 0) {
            errors.append("لم يتم العثور على أي مجموعة مطابقة. يجب كتابة اسم المحل يليه 4 أرقام مثل: 10-5-0-2.\n");
        }

        if (errors.length() > 0) {
            showErrorDialog("تم رفض الرسالة بالكامل (لم يتم الخصم)", errors.toString());
            return;
        }

        try {
            JSONObject workers = data.getJSONObject("workers");
            JSONObject w = workers.getJSONObject(name);
            JSONObject stock = data.getJSONObject("stock");

            // Check availability
            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                int wb = w.optInt(k, 0);
                int sb = stock.optInt(k, 0);

                if (totalUsed[i] > wb) {
                    showErrorDialog("رصيد العامل غير كافٍ",
                            "رصيد العامل «" + name + "» غير كافٍ في فئة " + k + ".\n"
                                    + "المطلوب خصمه: " + totalUsed[i] + " كرت\n"
                                    + "المتوفر برصيد العامل: " + wb + " كرت.\nلم يتم إجراء أي خصم.");
                    return;
                }
                if (totalUsed[i] > sb) {
                    showErrorDialog("المخزون العام غير كافٍ",
                            "المخزون العام غير كافٍ في فئة " + k + ".\n"
                                    + "المطلوب خصمه: " + totalUsed[i] + " كرت\n"
                                    + "المتوفر بالمخزون العام: " + sb + " كرت.\nلم يتم إجراء أي خصم.");
                    return;
                }
            }

            JSONObject oldWorker = new JSONObject(w.toString());
            JSONObject oldStock = new JSONObject(stock.toString());

            // Deduct
            for (int i = 0; i < 4; i++) {
                String k = String.valueOf(DENOMS[i]);
                w.put(k, w.optInt(k, 0) - totalUsed[i]);
                stock.put(k, stock.optInt(k, 0) - totalUsed[i]);
            }

            saveData();

            prefs.edit()
                    .putString("last_undo_worker", name)
                    .putString("last_undo_worker_json", oldWorker.toString())
                    .putString("last_undo_stock_json", oldStock.toString())
                    .putBoolean("last_undo_available", true)
                    .apply();

            renderWorkers();
            updateStockInputsFromData();
            updateUndoButtonState();
            checkAndNotifyStock("مخزون العامل " + name, w);
            checkAndNotifyStock("المخزون العام", stock);

            showSuccessToast("تم التحقق والخصم بنجاح من رصيد العامل والمخزون العام");

            // Build Comprehensive Deduction Report
            List<String[]> catRows = new ArrayList<>();
            int totalUsedSum = 0;
            int totalWorkerRemaining = 0;

            for (int i = 0; i < 4; i++) {
                int used = totalUsed[i];
                int rem = w.optInt(String.valueOf(DENOMS[i]), 0);
                totalUsedSum += used;
                totalWorkerRemaining += rem;

                catRows.add(new String[]{
                        "فئة " + DENOMS[i],
                        String.valueOf(oldWorker.optInt(String.valueOf(DENOMS[i]), 0)),
                        "-" + used,
                        String.valueOf(rem)
                });
            }

            long totalMoney = 0;
            for (InvoiceRow r : invoiceRows) {
                totalMoney += r.total;
            }

            NumberFormat nf = NumberFormat.getInstance(Locale.US);

            List<String> summaryLines = new ArrayList<>();
            summaryLines.add("عدد المحلات الموزع عليها: " + groupCount + " محلات");
            summaryLines.add("إجمالي الكروت المخصومة: " + totalUsedSum + " كرت");
            summaryLines.add("إجمالي المبلغ المالي للفاتورة: " + nf.format(totalMoney) + " ريال");
            summaryLines.add("إجمالي رصيد العامل المتبقي: " + totalWorkerRemaining + " كرت");

            sendWorkerReportImage(name, "فاتورة توزيع وخصم كروت", catRows, invoiceRows, summaryLines, 0xFF2563EB);

        } catch (Exception e) {
            showErrorDialog("خطأ", "حدث خطأ غير متوقع أثناء إتمام الخصم: " + e.getMessage());
        }
    }

    private void undoLastOperation() {
        if (!prefs.getBoolean("last_undo_available", false)) {
            showErrorDialog("تنبيه", "لا توجد أي عملية سابقة قابلة للتراجع.");
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("التراجع عن آخر عملية")
                .setMessage("سيتم استعادة رصيد العامل والمخزون العام كما كانا قبل العملية الأخيرة تمامًا. هل ترغب في المتابعة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("نعم، تراجع", (d, which) -> {
                    try {
                        String n = prefs.getString("last_undo_worker", "");
                        JSONObject oldW = new JSONObject(prefs.getString("last_undo_worker_json", "{}"));
                        JSONObject oldS = new JSONObject(prefs.getString("last_undo_stock_json", "{}"));
                        JSONObject workers = data.getJSONObject("workers");

                        if (!workers.has(n)) throw new Exception("worker missing");
                        workers.put(n, oldW);
                        data.put("stock", oldS);
                        saveData();

                        prefs.edit()
                                .putBoolean("last_undo_available", false)
                                .remove("last_undo_worker_json")
                                .remove("last_undo_stock_json")
                                .apply();

                        renderWorkers();
                        updateStockInputsFromData();
                        updateUndoButtonState();
                        checkAndNotifyStock("مخزون العامل " + n, oldW);
                        checkAndNotifyStock("المخزون العام", oldS);

                        showSuccessToast("تم التراجع عن آخر عملية واستعادة الأرصدة السابقة بنجاح");
                    } catch (Exception ex) {
                        showErrorDialog("خطأ", "تعذر التراجع عن العملية: " + ex.getMessage());
                    }
                }).show();
    }

    private void sendWorkerReportImage(String workerName, String operationTitle,
                                       List<String[]> categoryRows,
                                       List<InvoiceRow> invoiceRows,
                                       List<String> summaryLines,
                                       int operationColor) {
        try {
            JSONObject workerObj = data.getJSONObject("workers").getJSONObject(workerName);
            String phone = workerObj.optString("phone", "").trim();
            String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

            Bitmap bitmap = generateReportBitmap(workerName, phone, operationTitle, stamp,
                    categoryRows, invoiceRows, summaryLines, operationColor);

            // Keep a persistent local copy before opening the share sheet.
            File docs = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (docs == null) docs = getFilesDir();
            File dir = new File(docs, "تقارير التوزيع");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد حفظ التقارير");

            String safeStamp = new SimpleDateFormat("yyyy-MM-dd - HH-mm", Locale.US).format(new Date());
            File file = new File(dir, "تقرير توزيع الكروت لهذا اليوم - " + safeStamp + ".pdf");
            PdfDocument pdf = new PdfDocument();
            try {
                int pageWidth = 595;
                int pageHeight = Math.max(1, (int) Math.ceil(bitmap.getHeight() * (pageWidth / (double) bitmap.getWidth())));
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
                PdfDocument.Page page = pdf.startPage(pageInfo);
                RectF dst = new RectF(0, 0, pageWidth, pageHeight);
                page.getCanvas().drawBitmap(bitmap, null, dst, null);
                pdf.finishPage(page);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    pdf.writeTo(out);
                    out.flush();
                }
            } finally {
                pdf.close();
                bitmap.recycle();
            }

            Uri uri = FileProvider.getUriForFile(this, "com.alkamel.workercards.pro24.fileprovider", file);

            // Construct unambiguous text for sharing
            NumberFormat nf = NumberFormat.getInstance(Locale.US);
            StringBuilder shareText = new StringBuilder();
            shareText.append("📋 *").append(operationTitle).append("*\n");
            shareText.append("👤 *العامل:* ").append(workerName).append("\n");
            if (!phone.isEmpty()) shareText.append("📱 *الهاتف:* ").append(phone).append("\n");
            shareText.append("🕒 *التاريخ:* ").append(stamp).append("\n");
            shareText.append("━━━━━━━━━━━━━━━━━━━\n");

            if (invoiceRows != null && !invoiceRows.isEmpty()) {
                shareText.append("🏪 *تفاصيل التوزيع على المحلات:*\n\n");
                Map<String, List<InvoiceRow>> grouped = new LinkedHashMap<>();
                for (InvoiceRow r : invoiceRows) {
                    if (!grouped.containsKey(r.shopName)) grouped.put(r.shopName, new ArrayList<>());
                    grouped.get(r.shopName).add(r);
                }
                int grandCards = 0;
                long grandMoney = 0;
                for (Map.Entry<String, List<InvoiceRow>> entry : grouped.entrySet()) {
                    shareText.append("📍 *محل: ").append(entry.getKey()).append("*\n");
                    int shopCards = 0;
                    long shopMoney = 0;
                    for (InvoiceRow ir : entry.getValue()) {
                        shareText.append("  • فئة ").append(ir.denomination).append(" ريال: ")
                                .append(ir.quantity).append(" كرت\n");
                        shopCards += ir.quantity;
                        shopMoney += ir.total;
                    }
                    grandCards += shopCards;
                    grandMoney += shopMoney;
                    shareText.append("  ↳ إجمالي المحل: ").append(shopCards).append(" كرت (")
                            .append(nf.format(shopMoney)).append(" ريال)\n\n");
                }
                shareText.append("━━━━━━━━━━━━━━━━━━━\n");
                shareText.append("📊 *إجمالي التوزيع العام:*\n");
                shareText.append("• إجمالي الكروت الموزعة: ").append(grandCards).append(" كرت\n");
                shareText.append("• إجمالي المبلغ المالي: ").append(nf.format(grandMoney)).append(" ريال\n");
            }

            if (summaryLines != null) {
                for (String sl : summaryLines) {
                    shareText.append("• ").append(sl).append("\n");
                }
            }

            AlertDialog.Builder shareDialog = new AlertDialog.Builder(this);
            shareDialog.setTitle("تم إنشاء الفاتورة بنجاح");
            shareDialog.setMessage("العامل: " + workerName + "\nالعملية: " + operationTitle + "\nالتاريخ: " + stamp +
                    (phone.isEmpty() ? "\n\n⚠️ لم يتم تسجيل رقم هاتف للعامل؛ يمكنك مشاركة الصورة عبر التطبيقات المتاحة." : "\nرقم الهاتف: " + phone));

            final String finalText = shareText.toString();
            shareDialog.setPositiveButton("📤 مشاركة الفاتورة عبر واتساب", (dialog, which) -> {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("application/pdf");
                shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
                shareIntent.putExtra(Intent.EXTRA_TEXT, finalText);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                String jidPhone = phone.replaceAll("[^0-9]", "");
                if (!jidPhone.isEmpty()) {
                    shareIntent.putExtra("jid", jidPhone + "@s.whatsapp.net");
                }

                try {
                    shareIntent.setPackage("com.whatsapp");
                    startActivity(shareIntent);
                } catch (Exception e1) {
                    try {
                        shareIntent.setPackage("com.whatsapp.w4b");
                        startActivity(shareIntent);
                    } catch (Exception e2) {
                        shareIntent.setPackage(null);
                        startActivity(Intent.createChooser(shareIntent, "مشاركة تقرير التوزيع PDF"));
                    }
                }
            });

            shareDialog.setNegativeButton("تم", null);
            shareDialog.show();

        } catch (Exception ex) {
            showErrorDialog("خطأ", "تعذر تجهيز تقرير PDF: " + ex.getMessage());
        }
    }

    private Bitmap generateReportBitmap(String workerName, String phone, String operationTitle, String stamp,
                                        List<String[]> categoryRows,
                                        List<InvoiceRow> invoiceRows,
                                        List<String> summaryLines,
                                        int operationColor) {
        int width = 960;
        int padding = 36;
        NumberFormat nf = NumberFormat.getInstance(Locale.US);

        TextPaint titlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        titlePaint.setColor(Color.WHITE);
        titlePaint.setTextSize(32);
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        TextPaint subPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        subPaint.setColor(0xFFCBD5E1);
        subPaint.setTextSize(17);

        TextPaint bodyPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        bodyPaint.setColor(0xFF0F172A);
        bodyPaint.setTextSize(20);

        TextPaint boldBodyPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        boldBodyPaint.setColor(0xFF0F172A);
        boldBodyPaint.setTextSize(20);
        boldBodyPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        TextPaint headerColPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        headerColPaint.setColor(0xFF1E3A8A);
        headerColPaint.setTextSize(18);
        headerColPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        // Group invoice rows by shop name
        Map<String, List<InvoiceRow>> shopMap = new LinkedHashMap<>();
        int totalCardsSum = 0;
        long totalMoneySum = 0;
        if (invoiceRows != null) {
            for (InvoiceRow r : invoiceRows) {
                if (!shopMap.containsKey(r.shopName)) shopMap.put(r.shopName, new ArrayList<>());
                shopMap.get(r.shopName).add(r);
                totalCardsSum += r.quantity;
                totalMoneySum += r.total;
            }
        }

        // Estimate canvas height dynamically
        int estimatedHeight = 180 + 120 + 60 + (categoryRows.size() * 52) + 80;
        if (!shopMap.isEmpty()) {
            estimatedHeight += 70; // Section title
            for (List<InvoiceRow> sList : shopMap.values()) {
                estimatedHeight += 52 + (sList.size() * 46) + 38; // Shop header + items + shop total
            }
            estimatedHeight += 120; // Grand total card
        }
        if (summaryLines != null) {
            estimatedHeight += (summaryLines.size() * 42) + 60;
        }
        estimatedHeight += 90; // Footer

        Bitmap bitmap = Bitmap.createBitmap(width, Math.max(900, estimatedHeight), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        canvas.drawColor(0xFFF8FAFC);

        // Header Background
        Paint headerBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        headerBg.setColor(0xFF0F172A);
        canvas.drawRect(0, 0, width, 150, headerBg);

        // App Title in Header
        canvas.drawText("مخزون كروت الكامل V24", padding, 64, titlePaint);
        canvas.drawText("فاتورة توزيع الكروت والعمليات المعتمدة", padding, 102, subPaint);

        // Operation Tag Badge (Top Right)
        Paint tagPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        tagPaint.setColor(operationColor);
        RectF tagRect = new RectF(width - 320, 42, width - padding, 104);
        canvas.drawRoundRect(tagRect, 14, 14, tagPaint);

        TextPaint tagTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tagTextPaint.setColor(Color.WHITE);
        tagTextPaint.setTextSize(20);
        tagTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tagTextPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(operationTitle, tagRect.centerX(), tagRect.centerY() + 7, tagTextPaint);

        int currentY = 175;

        // Info Card
        Paint cardBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBg.setColor(Color.WHITE);
        Paint cardBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
        cardBorder.setColor(0xFFE2E8F0);
        cardBorder.setStyle(Paint.Style.STROKE);
        cardBorder.setStrokeWidth(2);

        RectF infoRect = new RectF(padding, currentY, width - padding, currentY + 95);
        canvas.drawRoundRect(infoRect, 16, 16, cardBg);
        canvas.drawRoundRect(infoRect, 16, 16, cardBorder);

        canvas.drawText("👤 العامل: " + workerName, padding + 20, currentY + 38, boldBodyPaint);
        canvas.drawText("📱 الهاتف: " + (phone.isEmpty() ? "غير مسجل" : phone), padding + 20, currentY + 74, bodyPaint);
        canvas.drawText("🕒 التاريخ: " + stamp, width - padding - 360, currentY + 38, bodyPaint);

        currentY += 120;

        // Table 1: Balances Overview
        Paint tableHeadBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        tableHeadBg.setColor(0xFFEFF6FF);
        RectF tableHeadRect = new RectF(padding, currentY, width - padding, currentY + 46);
        canvas.drawRoundRect(tableHeadRect, 10, 10, tableHeadBg);

        int col1 = padding + 16;
        int col2 = padding + 230;
        int col3 = padding + 450;
        int col4 = padding + 670;

        canvas.drawText("الفئة", col1, currentY + 30, headerColPaint);
        canvas.drawText("الرصيد السابق", col2, currentY + 30, headerColPaint);
        canvas.drawText("العملية", col3, currentY + 30, headerColPaint);
        canvas.drawText("الرصيد النهائي", col4, currentY + 30, headerColPaint);

        currentY += 52;

        Paint rowLine = new Paint(Paint.ANTI_ALIAS_FLAG);
        rowLine.setColor(0xFFE2E8F0);
        rowLine.setStrokeWidth(1);

        for (int i = 0; i < categoryRows.size(); i++) {
            String[] row = categoryRows.get(i);
            canvas.drawText(row[0], col1, currentY + 28, boldBodyPaint);
            canvas.drawText(row[1] + " كرت", col2, currentY + 28, bodyPaint);

            TextPaint changePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            changePaint.setTextSize(20);
            changePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            changePaint.setColor(row[2].startsWith("+") ? 0xFF059669 : 0xFFDC2626);
            canvas.drawText(row[2] + " كرت", col3, currentY + 28, changePaint);

            canvas.drawText(row[3] + " كرت", col4, currentY + 28, boldBodyPaint);

            currentY += 42;
            canvas.drawLine(padding, currentY, width - padding, currentY, rowLine);
            currentY += 6;
        }

        // ==========================================
        // DETAILED DISTRIBUTION PER SHOP WITH DISTINCT DENOMINATION COLORS
        // (محل تلو الآخر مع تمييز فئات الكروت: 100 أحمر، 200 بنفسجي، 250 أخضر، 500 ذهبي)
        // ==========================================
        if (!shopMap.isEmpty()) {
            currentY += 24;

            TextPaint sectionPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            sectionPaint.setColor(0xFF0F172A);
            sectionPaint.setTextSize(22);
            sectionPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("📋 تفاصيل التوزيع على المحلات (موضحة بدقة لكل فئة):", padding, currentY, sectionPaint);
            currentY += 32;

            for (Map.Entry<String, List<InvoiceRow>> entry : shopMap.entrySet()) {
                String sName = entry.getKey();
                List<InvoiceRow> items = entry.getValue();

                // Shop Header Bar
                Paint sHeadBg = new Paint(Paint.ANTI_ALIAS_FLAG);
                sHeadBg.setColor(0xFF1E293B); // Dark Slate
                RectF sHeadRect = new RectF(padding, currentY, width - padding, currentY + 42);
                canvas.drawRoundRect(sHeadRect, 10, 10, sHeadBg);

                TextPaint sTitlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                sTitlePaint.setColor(Color.WHITE);
                sTitlePaint.setTextSize(19);
                sTitlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                canvas.drawText("🏪 المحل: " + sName, padding + 16, currentY + 28, sTitlePaint);

                currentY += 50;

                int shopCards = 0;
                long shopMoney = 0;

                for (InvoiceRow ir : items) {
                    shopCards += ir.quantity;
                    shopMoney += ir.total;

                    // Denomination Color: 100=Red, 200=Purple, 250=Green, 500=Gold/Amber
                    int denomColor;
                    int denomBg;
                    if (ir.denomination == 100) {
                        denomColor = 0xFFDC2626; // Red
                        denomBg = 0xFFFEF2F2;
                    } else if (ir.denomination == 200) {
                        denomColor = 0xFF7C3AED; // Purple
                        denomBg = 0xFFF5F3FF;
                    } else if (ir.denomination == 250) {
                        denomColor = 0xFF059669; // Green
                        denomBg = 0xFFECFDF5;
                    } else {
                        denomColor = 0xFF0284C7; // Sky blue
                        denomBg = 0xFFE0F2FE;
                    }

                    // Background line for denomination item
                    Paint rowBg = new Paint(Paint.ANTI_ALIAS_FLAG);
                    rowBg.setColor(Color.WHITE);
                    RectF rowRect = new RectF(padding, currentY, width - padding, currentY + 42);
                    canvas.drawRoundRect(rowRect, 8, 8, rowBg);
                    canvas.drawRoundRect(rowRect, 8, 8, cardBorder);

                    // Denomination Pill
                    Paint pillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    pillPaint.setColor(denomColor);
                    RectF pillRect = new RectF(padding + 12, currentY + 6, padding + 170, currentY + 36);
                    canvas.drawRoundRect(pillRect, 8, 8, pillPaint);

                    TextPaint pillText = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                    pillText.setColor(Color.WHITE);
                    pillText.setTextSize(17);
                    pillText.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                    pillText.setTextAlign(Paint.Align.CENTER);
                    canvas.drawText("فئة " + ir.denomination + " ريال", pillRect.centerX(), pillRect.centerY() + 6, pillText);

                    // Distinct Quantity (bold, large)
                    TextPaint qtyPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                    qtyPaint.setColor(0xFF0F172A);
                    qtyPaint.setTextSize(20);
                    qtyPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                    canvas.drawText(":  " + ir.quantity + " كرت", padding + 185, currentY + 28, qtyPaint);

                    // Unit Price
                    TextPaint pricePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                    pricePaint.setColor(0xFF475569);
                    pricePaint.setTextSize(17);
                    canvas.drawText("(سعر الكرت: " + nf.format(ir.price) + " ريال)", padding + 380, currentY + 28, pricePaint);

                    // Total for line
                    TextPaint lineTotalPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                    lineTotalPaint.setColor(0xFF0F172A);
                    lineTotalPaint.setTextSize(19);
                    lineTotalPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                    canvas.drawText("الإجمالي: " + nf.format(ir.total) + " ريال", width - padding - 260, currentY + 28, lineTotalPaint);

                    currentY += 46;
                }

                // Subtotal row for shop
                Paint shopSubBg = new Paint(Paint.ANTI_ALIAS_FLAG);
                shopSubBg.setColor(0xFFF1F5F9);
                RectF subRect = new RectF(padding + 16, currentY, width - padding - 16, currentY + 34);
                canvas.drawRoundRect(subRect, 6, 6, shopSubBg);

                TextPaint subTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                subTextPaint.setColor(0xFF334155);
                subTextPaint.setTextSize(16);
                subTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                canvas.drawText("↳ مجموع كروت المحل: " + shopCards + " كرت  |  المبلغ الإجمالي للمحل: " + nf.format(shopMoney) + " ريال",
                        padding + 28, currentY + 23, subTextPaint);

                currentY += 46;
            }

            // Grand Total Card for All Shops
            currentY += 8;
            Paint grandBg = new Paint(Paint.ANTI_ALIAS_FLAG);
            grandBg.setColor(0xFFECFDF5); // Soft Emerald
            Paint grandBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
            grandBorder.setColor(0xFFA7F3D0);
            grandBorder.setStyle(Paint.Style.STROKE);
            grandBorder.setStrokeWidth(2);

            RectF grandRect = new RectF(padding, currentY, width - padding, currentY + 68);
            canvas.drawRoundRect(grandRect, 14, 14, grandBg);
            canvas.drawRoundRect(grandRect, 14, 14, grandBorder);

            TextPaint grandTitle = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            grandTitle.setColor(0xFF065F46);
            grandTitle.setTextSize(20);
            grandTitle.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("📊 إجمالي التوزيع لكافة المحلات:", padding + 20, currentY + 30, grandTitle);

            TextPaint grandStats = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            grandStats.setColor(0xFF047857);
            grandStats.setTextSize(18);
            grandStats.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("عدد المحلات: " + shopMap.size() + "  |  إجمالي الكروت: " + totalCardsSum + " كرت  |  المبلغ المالي: " + nf.format(totalMoneySum) + " ريال",
                    padding + 20, currentY + 56, grandStats);

            currentY += 84;
        }

        // Summary Lines Card
        if (summaryLines != null && !summaryLines.isEmpty()) {
            currentY += 12;
            RectF sumRect = new RectF(padding, currentY, width - padding, currentY + (summaryLines.size() * 38) + 22);
            Paint sumBg = new Paint(Paint.ANTI_ALIAS_FLAG);
            sumBg.setColor(0xFFEFF6FF);
            Paint sumBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
            sumBorder.setColor(0xFFBFDBFE);
            sumBorder.setStyle(Paint.Style.STROKE);
            sumBorder.setStrokeWidth(2);
            canvas.drawRoundRect(sumRect, 14, 14, sumBg);
            canvas.drawRoundRect(sumRect, 14, 14, sumBorder);

            int sY = currentY + 34;
            for (String line : summaryLines) {
                TextPaint sPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                sPaint.setColor(0xFF1E3A8A);
                sPaint.setTextSize(20);
                sPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                canvas.drawText("✔ " + line, padding + 20, sY, sPaint);
                sY += 38;
            }
            currentY = (int) sumRect.bottom + 20;
        }

        // Footer
        TextPaint footerPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        footerPaint.setColor(0xFF94A3B8);
        footerPaint.setTextSize(15);
        footerPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("تم إنشاء هذه الفاتورة آليًا بواسطة تطبيق إدارة كروت الكامل V24", width / 2f, currentY + 28, footerPaint);

        return bitmap;
    }

    private void showSuccessToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showErrorDialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("إغلاق", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void checkAndNotifyStock(String categoryPrefix, JSONObject stock) {
        try {
            SharedPreferences alertPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
            for (int denom : DENOMS) {
                String key = String.valueOf(denom);
                int threshold;
                if (categoryPrefix.startsWith("مخزون العامل ")) {
                    String workerName = categoryPrefix.substring("مخزون العامل ".length());
                    threshold = stock.optInt("threshold_" + denom,
                            alertPrefs.getInt("threshold_" + denom, 10));
                } else {
                    threshold = alertPrefs.getInt("threshold_" + denom, 10);
                }
                int remaining = stock.optInt(key, 0);
                Intent alert = new Intent(this, StockAlertReceiver.class);
                alert.setAction(StockAlertReceiver.ACTION);
                alert.putExtra(StockAlertReceiver.EXTRA_CATEGORY, categoryPrefix + " - فئة " + denom);
                alert.putExtra(StockAlertReceiver.EXTRA_REMAINING, remaining);
                alert.putExtra(StockAlertReceiver.EXTRA_THRESHOLD, threshold);
                sendBroadcast(alert);
            }
        } catch (Exception ignored) { }
    }
}
