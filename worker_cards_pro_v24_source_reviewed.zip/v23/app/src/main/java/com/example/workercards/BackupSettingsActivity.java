package com.example.workercards;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class BackupSettingsActivity extends Activity {

    private CheckBox enabled;
    private TextView timeText;
    private final EditText[] thresholds = new EditText[4];
    private final int[] denominations = {100, 200, 250, 500};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);

        android.content.SharedPreferences p =
                getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32,32,32,32);

        TextView title = new TextView(this);
        title.setText("إعدادات النسخ والتنبيهات");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView location = new TextView(this);
        location.setText("📁 مكان النسخ: الذاكرة الداخلية / مخزون كروت الكامل");
        location.setTextSize(15);
        location.setPadding(0, 12, 0, 12);
        box.addView(location);

        TextView accessStatus = new TextView(this);
        accessStatus.setText(
                BackupHelper.hasRootStorageAccess()
                        ? "✅ الوصول إلى الذاكرة الداخلية مفعّل"
                        : "⚠️ يجب السماح للتطبيق بالوصول إلى الذاكرة الداخلية حتى يتم إنشاء المجلد مباشرة."
        );
        accessStatus.setTextSize(15);
        accessStatus.setPadding(0, 8, 0, 8);
        box.addView(accessStatus);

        Button access = new Button(this);
        access.setText("📂 السماح بحفظ النسخ في الذاكرة الداخلية");
        access.setOnClickListener(v -> {
            BackupHelper.openStorageAccessSettings(this);
        });
        box.addView(access);

        Button testBackup = new Button(this);
        testBackup.setText("🧪 اختبار النسخ الآن");
        testBackup.setOnClickListener(v -> {
            BackupHelper.createBackup(this);
        });
        box.addView(testBackup);

        enabled = new CheckBox(this);
        enabled.setText("تفعيل النسخ الاحتياطي التلقائي يوميًا");
        enabled.setChecked(p.getBoolean(StockSettings.BACKUP_ENABLED, true));
        box.addView(enabled);

        timeText = new TextView(this);
        timeText.setText("وقت النسخ: " + String.format("%02d:%02d",
                p.getInt(StockSettings.BACKUP_HOUR,4),
                p.getInt(StockSettings.BACKUP_MINUTE,0)));
        timeText.setTextSize(18);
        timeText.setPadding(0,24,0,24);
        box.addView(timeText);

        Button choose = new Button(this);
        choose.setText("تحديد وقت النسخ");
        choose.setOnClickListener(v -> {
            int h = p.getInt(StockSettings.BACKUP_HOUR,4);
            int m = p.getInt(StockSettings.BACKUP_MINUTE,0);
            new TimePickerDialog(this, (view, hour, minute) -> {
                p.edit().putInt(StockSettings.BACKUP_HOUR,hour)
                        .putInt(StockSettings.BACKUP_MINUTE,minute).apply();
                timeText.setText("وقت النسخ: " + String.format("%02d:%02d",hour,minute));
                StockSettings.scheduleBackup(this);
            }, h, m, true).show();
        });
        box.addView(choose);

        TextView t = new TextView(this);
        t.setText("حدود تنبيه المخزون لكل فئة (تنبيه عند الحد أو أقل):");
        t.setTextSize(17);
        t.setPadding(0, 16, 0, 6);
        box.addView(t);
        for (int i=0; i<denominations.length; i++) {
            TextView label = new TextView(this);
            label.setText("فئة " + denominations[i]);
            label.setTextSize(15);
            box.addView(label);
            thresholds[i] = new EditText(this);
            thresholds[i].setInputType(2);
            thresholds[i].setHint("الحد الأدنى لهذه الفئة");
            thresholds[i].setText(String.valueOf(p.getInt("threshold_" + denominations[i], p.getInt(StockSettings.DEFAULT_THRESHOLD, 10))));
            box.addView(thresholds[i]);
        }

        Button save = new Button(this);
        save.setText("حفظ الإعدادات");
        save.setOnClickListener(v -> {
            android.content.SharedPreferences.Editor editor = p.edit().putBoolean(StockSettings.BACKUP_ENABLED, enabled.isChecked());
            try {
                for (int i=0; i<denominations.length; i++) {
                    String raw = thresholds[i].getText().toString().trim();
                    int n = raw.isEmpty() ? 0 : Integer.parseInt(raw);
                    if (n < 0) { thresholds[i].setError("أدخل صفرًا أو رقمًا أكبر"); return; }
                    editor.putInt("threshold_" + denominations[i], n);
                }
            } catch (Exception ex) { Toast.makeText(this, "تحقق من حدود التنبيه المدخلة", Toast.LENGTH_SHORT).show(); return; }
            editor.apply();
            StockSettings.scheduleBackup(this);
            Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show();
        });
        box.addView(save);

        setContentView(box);
    }
}
