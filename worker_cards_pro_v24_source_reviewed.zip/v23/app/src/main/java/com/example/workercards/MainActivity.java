package com.example.workercards;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.Paint;
import androidx.core.content.FileProvider;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS = "worker_cards_pro_v24_data";
    private static final int CREATE_BACKUP = 1001;
    private static final int RESTORE_BACKUP = 1002;
    private final int[] DENOMS = {100, 200, 250, 500};

    private SharedPreferences prefs;
    private JSONObject data;
    private String selectedWorker = "";
    private LinearLayout workersContainer;
    private EditText[] stockInputs = new EditText[4];
    private EditText messageInput;
    private TextView resultText;
    private TextView selectedText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StockSettings.ensureNotificationChannel(this);
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
        }
        StockSettings.scheduleBackup(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadData();
        buildUi();
    }

    private void loadData() {
        try {
            String saved = prefs.getString("data", "");
            if (saved.isEmpty()) {
                // Start with an empty inventory. Never seed a real stock ledger with demo balances.
                data = new JSONObject();
                JSONObject stock = new JSONObject();
                for (int denom : DENOMS) stock.put(String.valueOf(denom), 0);
                data.put("stock", stock);
                data.put("workers", new JSONObject());
            } else {
                data = new JSONObject(saved);
            }
            if (data.optJSONObject("stock") == null) data.put("stock", new JSONObject());
            if (data.optJSONObject("workers") == null) data.put("workers", new JSONObject());
        } catch (Exception e) {
            data = new JSONObject();
        }
    }

    private void saveData() {
        // Any successful data mutation invalidates an older undo snapshot.
        // The operation that created a new snapshot stores it immediately after saveData().
        prefs.edit().putString("data", data.toString()).putBoolean("last_undo_available", false).apply();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(0xFF222222);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(17);
        b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(50));
        b.setBackgroundColor(color);
        return b;
    }

    private EditText numberInput(int value) {
        EditText e = new EditText(this);
        e.setText(String.valueOf(value));
        e.setTextSize(18);
        e.setGravity(Gravity.CENTER);
        e.setInputType(2);
        e.setSingleLine(true);
        e.setPadding(dp(4), dp(8), dp(4), dp(8));
        e.setIncludeFontPadding(true);
        return e;
    }

    private LinearLayout box() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(10), dp(10), dp(10), dp(10));
        l.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(5), dp(6), dp(5), dp(6));
        l.setLayoutParams(p);
        return l;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return r;
    }

    private void addCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(62), 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(v, p);
    }

    // Larger cell used for denomination label + amount so neither is clipped at the top.
    private void addCategoryCell(LinearLayout row, View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(118), 1f);
        p.setMargins(dp(3), dp(7), dp(3), dp(7));
        row.addView(v, p);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F6F8);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(5), dp(5), dp(5), dp(12));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.example.workercards.R.drawable.app_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setContentDescription("شعار شبكة الكامل");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(190));
        logoParams.setMargins(dp(8), dp(4), dp(8), dp(0));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(logo, logoParams);

        TextView header = title("إدارة كروت العامل", 30);
        header.setGravity(Gravity.CENTER);
        content.addView(header, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView sub = new TextView(this);
        sub.setText("تطبيق Android أصلي لإدارة المخزون والعمال والخصم");
        sub.setTextSize(18); sub.setTextColor(0xFF666666);
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,0,0,dp(10));
        content.addView(sub);

        // Backup
        LinearLayout backup = box();
        backup.addView(title("النسخ الاحتياطي والاستعادة", 25));
        TextView info = new TextView(this);
        info.setText("النسخ التلقائية تحفظ مباشرة في الذاكرة الداخلية داخل مجلد «مخزون كروت الكامل»، واسم الملف يحتوي على تاريخ ووقت النسخ.");
        info.setTextSize(16); info.setTextColor(0xFF666666);
        info.setGravity(Gravity.RIGHT); info.setPadding(0,0,0,dp(6));
        backup.addView(info);
        LinearLayout br = row();
        Button export = button("تصدير نسخة", 0xFF16833A);
        Button restore = button("استعادة نسخة", 0xFF1976D2);
        addCell(br, export); addCell(br, restore);
        backup.addView(br);
        export.setOnClickListener(v -> exportBackup());
        restore.setOnClickListener(v -> restoreBackup());
        content.addView(backup);

        Button settingsButton = button("⚙ إعدادات النسخ والتنبيهات", 0xFF7B1FA2);
        settingsButton.setOnClickListener(v ->
                startActivity(new Intent(this, BackupSettingsActivity.class)));
        content.addView(settingsButton);

        // General stock
        LinearLayout stockBox = box();
        stockBox.addView(title("المخزون العام", 27));
        LinearLayout r1 = row(), r2 = row();
        for (int i = 0; i < 4; i++) {
            int val = data.optJSONObject("stock").optInt(String.valueOf(DENOMS[i]), 0);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(18); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            lab.setGravity(Gravity.CENTER);
            stockInputs[i] = numberInput(val);
            cell.addView(lab);
            cell.addView(stockInputs[i], new LinearLayout.LayoutParams(-1, dp(58)));
            if (i < 2) addCategoryCell(r1, cell); else addCategoryCell(r2, cell);
        }
        stockBox.addView(r1); stockBox.addView(r2);
        Button saveStock = button("حفظ المخزون العام", 0xFF16833A);
        saveStock.setOnClickListener(v -> saveGeneralStock());
        stockBox.addView(saveStock);
        content.addView(stockBox);

        // Workers
        LinearLayout workerBox = box();
        workerBox.addView(title("العمال ومخزون الكروت الخاص بهم", 27));
        TextView wi = new TextView(this);
        wi.setText("كل عامل له مخزون مستقل من كروت 100 و200 و250 و500. يمكنك إضافة عامل وتعديل مخزونه وحفظه في أي وقت.");
        wi.setTextSize(16); wi.setTextColor(0xFF666666); wi.setGravity(Gravity.RIGHT);
        workerBox.addView(wi);

        Button addWorker = button("＋ إضافة عامل جديد", 0xFF1976D2);
        addWorker.setOnClickListener(v -> showAddWorkerDialog());
        workerBox.addView(addWorker);

        selectedText = new TextView(this);
        selectedText.setTextSize(18); selectedText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selectedText.setTextColor(0xFF1976D2); selectedText.setPadding(dp(5),dp(10),dp(5),dp(5));
        selectedText.setGravity(Gravity.RIGHT);
        workerBox.addView(selectedText);

        workersContainer = new LinearLayout(this);
        workersContainer.setOrientation(LinearLayout.VERTICAL);
        workersContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        workerBox.addView(workersContainer);
        content.addView(workerBox);

        // Message
        LinearLayout msgBox = box();
        msgBox.addView(title("رسالة العامل", 27));
        TextView hint = new TextView(this);
        hint.setText("اختر العامل، ثم الصق الرسالة كاملة. سيتم جمع كل الأسطر بصيغة:\n100-200-250-500\n\nمثال:\n1-2-3-4\n2-1-0-3");
        hint.setTextSize(17); hint.setTextColor(0xFF666666); hint.setGravity(Gravity.RIGHT);
        msgBox.addView(hint);
        messageInput = new EditText(this);
        messageInput.setTextSize(18);
        messageInput.setGravity(Gravity.TOP | Gravity.RIGHT);
        messageInput.setHint("الصق رسالة العامل هنا");
        messageInput.setMinLines(7);
        messageInput.setInputType(1 | 0x00008000);
        msgBox.addView(messageInput, new LinearLayout.LayoutParams(-1, dp(190)));
        Button calc = button("تحقق ثم احسب وخصم", 0xFF1976D2);
        calc.setOnClickListener(v -> calculateAndDeduct());
        msgBox.addView(calc);
        Button undo = button("↶ تراجع عن آخر عملية", 0xFFC62828);
        undo.setOnClickListener(v -> undoLastOperation());
        msgBox.addView(undo);
        content.addView(msgBox);

        LinearLayout resultBox = box();
        resultBox.addView(title("النتيجة", 25));
        resultText = new TextView(this);
        resultText.setText("—");
        resultText.setTextSize(17); resultText.setGravity(Gravity.RIGHT);
        resultText.setPadding(dp(5),dp(5),dp(5),dp(5));
        resultBox.addView(resultText);
        content.addView(resultBox);

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        renderWorkers();
        updateSelectedText();
    }

    private void saveGeneralStock() {
        try {
            JSONObject stock = data.getJSONObject("stock");
            for (int i=0;i<4;i++) stock.put(String.valueOf(DENOMS[i]), Math.max(0, parse(stockInputs[i])));
            saveData();
            checkAndNotifyStock("المخزون العام", data.getJSONObject("stock"));
            result("تم حفظ المخزون العام بنجاح.", true);
        } catch(Exception e) { result("حدث خطأ أثناء حفظ المخزون.", false); }
    }

    private int parse(EditText e) {
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch(Exception ex) { return 0; }
    }

    private void showAddWorkerDialog() {
        final EditText name = new EditText(this);
        name.setHint("مثال: أحمد محمد");
        name.setTextSize(18);
        name.setGravity(Gravity.RIGHT);
        name.setSingleLine(true);
        name.setPadding(dp(10),dp(5),dp(10),dp(5));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("إضافة عامل جديد")
                .setMessage("اكتب اسم العامل. سيتم إنشاء مخزون 0 لكل الفئات.")
                .setView(name)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إضافة", null)
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("اكتب اسم العامل"); return; }
            try {
                JSONObject workers = data.getJSONObject("workers");
                if (workers.has(n)) {
                    selectedWorker = n;
                    saveData(); renderWorkers(); updateSelectedText();
                    result("العامل موجود مسبقًا، تم اختياره: " + n, true);
                    d.dismiss();
                    return;
                }
                JSONObject w = new JSONObject();
                for (int den : DENOMS) w.put(String.valueOf(den), 0);
                workers.put(n, w);
                selectedWorker = n;
                saveData(); renderWorkers(); updateSelectedText();
                result("تمت إضافة العامل «" + n + "» ومخزونه جاهز للتعبئة.", true);
                d.dismiss();
            } catch(Exception e) { result("تعذر إضافة العامل.", false); }
        }));
        d.show();
    }

    private void renderWorkers() {
        if (workersContainer == null) return;
        workersContainer.removeAllViews();
        try {
            JSONObject workers = data.getJSONObject("workers");
            JSONArray names = workers.names();
            if (names == null || names.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("لا يوجد عمال. اضغط «إضافة عامل جديد».");
                empty.setTextSize(17); empty.setPadding(dp(5),dp(12),dp(5),dp(12));
                workersContainer.addView(empty);
                return;
            }
            for (int x=0; x<names.length(); x++) {
                String name = names.getString(x);
                JSONObject w = workers.getJSONObject(name);
                addWorkerCard(name, w);
            }
        } catch(Exception ignored) {}
    }

    private void addWorkerCard(String name, JSONObject w) {
        LinearLayout card = box();
        card.setPadding(dp(10),dp(10),dp(10),dp(10));

        TextView nameTv = title(name, 23);
        card.addView(nameTv);
        EditText phoneInput = new EditText(this);
        phoneInput.setHint("رقم هاتف العامل (واتساب)");
        phoneInput.setSingleLine(true);
        phoneInput.setInputType(3);
        phoneInput.setText(w.optString("phone", ""));
        card.addView(phoneInput, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView thresholdLabel = title("حد التنبيه لكل فئة عند هذا العامل", 17);
        card.addView(thresholdLabel);
        EditText[] workerThresholds = new EditText[4];
        LinearLayout tr1 = row(), tr2 = row();
        for (int i=0;i<4;i++) {
            LinearLayout tc = new LinearLayout(this); tc.setOrientation(LinearLayout.VERTICAL); tc.setGravity(Gravity.CENTER);
            TextView tl = new TextView(this); tl.setText("حد " + DENOMS[i]); tl.setGravity(Gravity.CENTER); tc.addView(tl);
            workerThresholds[i] = numberInput(w.optInt("threshold_" + DENOMS[i], 10));
            tc.addView(workerThresholds[i], new LinearLayout.LayoutParams(-1, dp(48)));
            if (i<2) addCategoryCell(tr1, tc); else addCategoryCell(tr2, tc);
        }
        card.addView(tr1); card.addView(tr2);

        Button use = button(selectedWorker.equals(name) ? "✓ العامل المختار" : "اختيار هذا العامل", 0xFF1976D2);
        use.setOnClickListener(v -> {
            selectedWorker = name;
            updateSelectedText();
            renderWorkers();
            result("تم اختيار العامل: " + name, true);
        });
        card.addView(use);

        LinearLayout rr1 = row(), rr2 = row();
        for (int i=0;i<4;i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            TextView lab = new TextView(this);
            lab.setText("فئة " + DENOMS[i]);
            lab.setTextSize(16); lab.setTypeface(Typeface.DEFAULT, Typeface.BOLD); lab.setGravity(Gravity.CENTER);
            lab.setIncludeFontPadding(true);
            lab.setPadding(0, dp(12), 0, dp(8));
            EditText inp = numberInput(w.optInt(String.valueOf(DENOMS[i]),0));
            cell.addView(lab);
            cell.addView(inp, new LinearLayout.LayoutParams(-1,dp(58)));
            cell.setTag(inp);
            if(i<2) addCategoryCell(rr1,cell); else addCategoryCell(rr2,cell);
        }
        card.addView(rr1); card.addView(rr2);

        Button save = button("حفظ مخزون هذا العامل", 0xFF16833A);
        save.setOnClickListener(v -> {
            try {
                LinearLayout[] rows = {rr1, rr2};
                JSONObject nw = new JSONObject();
                int idx=0;
                for(LinearLayout row: rows) {
                    for(int j=0;j<row.getChildCount();j++) {
                        LinearLayout cell=(LinearLayout)row.getChildAt(j);
                        EditText inp=(EditText)cell.getTag();
                        nw.put(String.valueOf(DENOMS[idx++]), Math.max(0,parse(inp)));
                    }
                }
                nw.put("phone", phoneInput.getText().toString().trim());
                for (int i=0;i<4;i++) {
                    int threshold = parse(workerThresholds[i]);
                    if (threshold < 0) { workerThresholds[i].setError("الحد لا يمكن أن يكون سالبًا"); return; }
                    nw.put("threshold_" + DENOMS[i], threshold);
                }
                data.getJSONObject("workers").put(name,nw);
                saveData(); renderWorkers();
                result("تم حفظ مخزون العامل «"+name+"».",true);
            } catch(Exception e) { result("تعذر حفظ مخزون العامل.",false); }
        });
        card.addView(save);

        Button addStock = button("＋ إضافة كميات جديدة لهذا العامل", 0xFF00897B);
        addStock.setOnClickListener(v -> showAddStockDialog(name));
        card.addView(addStock);

        LinearLayout actions = row();
        Button del = button("حذف العامل", 0xFFC62828);
        del.setOnClickListener(v -> confirmDelete(name));
        addCell(actions, del);
        Button choose = button("اختيار العامل", 0xFF1976D2);
        choose.setOnClickListener(v -> {
            selectedWorker=name; updateSelectedText(); renderWorkers();
            result("تم اختيار العامل: "+name,true);
        });
        addCell(actions, choose);
        card.addView(actions);

        workersContainer.addView(card);
    }

    private void showAddStockDialog(String name) {
        try {
            JSONObject worker = data.getJSONObject("workers").getJSONObject(name);
            LinearLayout panel = new LinearLayout(this);
            panel.setPadding(dp(16), dp(8), dp(16), dp(8));
            panel.setOrientation(LinearLayout.VERTICAL);
            EditText[] adds = new EditText[4];
            TextView[] totals = new TextView[4];
            for (int i=0;i<4;i++) {
                TextView label = new TextView(this);
                label.setText("فئة " + DENOMS[i] + " — الرصيد الحالي: " + worker.optInt(String.valueOf(DENOMS[i]),0));
                panel.addView(label);
                adds[i] = new EditText(this); adds[i].setInputType(2); adds[i].setHint("الكمية الجديدة التي أضيفها فقط");
                adds[i].setText("0"); panel.addView(adds[i]);
            }
            new AlertDialog.Builder(this).setTitle("إضافة كروت للعامل: " + name).setView(panel)
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("إضافة وحفظ", (d, which) -> {
                        try {
                            JSONObject w = data.getJSONObject("workers").getJSONObject(name);
                            JSONObject stock = data.getJSONObject("stock");
                            JSONObject oldW = new JSONObject(w.toString());
                            JSONObject oldS = new JSONObject(stock.toString());
                            int[] amounts = new int[4];
                            for (int i=0;i<4;i++) {
                                String key = String.valueOf(DENOMS[i]);
                                String raw = adds[i].getText().toString().trim();
                                amounts[i] = raw.isEmpty()?0:Integer.parseInt(raw);
                                if (amounts[i] < 0) throw new IllegalArgumentException("negative");
                                if (amounts[i] > stock.optInt(key, 0)) {
                                    result("المخزون العام غير كافٍ في فئة " + key + "؛ المطلوب " + amounts[i] + " والمتوفر " + stock.optInt(key,0) + ". لم يتم حفظ أي تغيير.", false);
                                    return;
                                }
                                Math.addExact(w.optInt(key,0), amounts[i]);
                            }
                            for (int i=0;i<4;i++) {
                                String key = String.valueOf(DENOMS[i]);
                                w.put(key, Math.addExact(w.optInt(key,0), amounts[i]));
                                stock.put(key, stock.optInt(key,0) - amounts[i]);
                            }
                            saveData();
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                    .putString("last_undo_worker", name)
                                    .putString("last_undo_worker_json", oldW.toString())
                                    .putString("last_undo_stock_json", oldS.toString())
                                    .putBoolean("last_undo_available", true).apply();
                            renderWorkers(); checkAndNotifyStock("مخزون العامل " + name, w); checkAndNotifyStock("المخزون العام", stock);
                            result("تمت إضافة الكميات وجمعها مع الرصيد السابق للعامل " + name + " بنجاح.", true);
                            sendWorkerReport(name, "إضافة كروت", "تمت إضافة كميات جديدة للعامل " + name + "\n" + buildWorkerBalanceText(w));
                        } catch (Exception ex) { result("تعذرت الإضافة: تحقق من الكميات المدخلة. لم تُحفظ العملية.", false); }
                    }).show();
        } catch (Exception ex) { result("تعذر فتح شاشة الإضافة.", false); }
    }

    private void confirmDelete(String name) {
        if (name.equals(selectedWorker)) selectedWorker = "";
        new AlertDialog.Builder(this)
                .setTitle("حذف العامل")
                .setMessage("هل تريد حذف «"+name+"» ومخزونه؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d,w) -> {
                    try {
                        data.getJSONObject("workers").remove(name);
                        saveData(); renderWorkers(); updateSelectedText();
                        result("تم حذف العامل.", true);
                    } catch(Exception e) { result("تعذر حذف العامل.", false); }
                }).show();
    }

    private void updateSelectedText() {
        if (selectedText != null)
            selectedText.setText(selectedWorker.isEmpty() ? "العامل المختار: لا يوجد" : "العامل المختار: " + selectedWorker);
    }

    private void calculateAndDeduct() {
        String name = selectedWorker;
        if (name.isEmpty()) { result("اختر العامل أولًا.", false); return; }
        String text = messageInput.getText().toString();
        if (text.trim().isEmpty()) { result("التقرير فارغ. لم يتم إجراء أي تغيير.", false); return; }

        int[] used = {0,0,0,0};
        int count = 0;
        String currentCustomer = null;
        Set<String> seenNames = new HashSet<>();
        StringBuilder errors = new StringBuilder();
        StringBuilder verticalUsed = new StringBuilder();
        String[] lines = text.split("\\r?\n", -1);
        Pattern valuesPattern = Pattern.compile("^(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)\\s*-\\s*(\\d+)$");
        Pattern malformedValuesPattern = Pattern.compile("^\\d+(?:\\s*-\\s*\\d+){1,3}$");

        for (int li=0; li<lines.length; li++) {
            String raw = lines[li].trim();
            String line = raw.replace("……", "").replace("...", "").replace("......", "").trim();
            if (line.isEmpty()) continue;
            Matcher vm = valuesPattern.matcher(line);
            if (vm.matches()) {
                if (currentCustomer == null || currentCustomer.trim().isEmpty()) {
                    errors.append("السطر ").append(li+1).append(": توجد كميات دون اسم عامل/عميل قبلها.\n");
                    continue;
                }
                int[] row = new int[4];
                try {
                    for (int i=0;i<4;i++) {
                        row[i] = Integer.parseInt(vm.group(i+1));
                        if (row[i] < 0) throw new NumberFormatException();
                        used[i] = Math.addExact(used[i], row[i]);
                    }
                } catch (Exception ex) {
                    errors.append("السطر ").append(li+1).append(" (").append(currentCustomer).append("): كمية غير صالحة أو كبيرة جدًا.\n");
                    continue;
                }
                count++;
                verticalUsed.append("<b>").append(android.text.Html.escapeHtml(currentCustomer)).append("</b><br>");
                verticalUsed.append("100 : ").append(row[0]).append("<br>200 : ").append(row[1])
                        .append("<br>250 : ").append(row[2]).append("<br>500 : ").append(row[3]).append("<br><br>");
                currentCustomer = null;
            } else {
                if (malformedValuesPattern.matcher(line).matches()) {
                    errors.append("السطر ").append(li+1).append(": صيغة الكميات ناقصة؛ يجب إدخال أربع قيم بالضبط مفصولة بشرطات، مثل 40-10-10-0. القيمة المدخلة: ").append(line).append("\n");
                    continue;
                }
                if (currentCustomer != null) {
                    errors.append("السطر ").append(li+1).append(": اسم جديد «").append(line)
                            .append("» ظهر قبل إدخال كميات الاسم السابق «").append(currentCustomer).append("».\n");
                }
                currentCustomer = line;
                if (seenNames.contains(currentCustomer)) {
                    errors.append("السطر ").append(li+1).append(": الاسم «").append(currentCustomer).append("» مكرر.\n");
                } else seenNames.add(currentCustomer);
            }
        }
        if (currentCustomer != null) errors.append("لم توجد كميات من أربع قيم بعد الاسم «").append(currentCustomer).append("» في نهاية التقرير.\n");
        if (count == 0 && errors.length() == 0) errors.append("لم أجد أي مجموعة صحيحة. يجب كتابة اسم ثم أربعة أرقام مثل 40-10-10-0.\n");
        if (errors.length() > 0) {
            result("<b>تم رفض التقرير كاملًا، ولم يتم الخصم.</b><br><br>" + android.text.Html.escapeHtml(errors.toString()).toString().replace("\n", "<br>"), false);
            return;
        }

        try {
            JSONObject workers=data.getJSONObject("workers");
            JSONObject w=workers.getJSONObject(name);
            JSONObject stock=data.getJSONObject("stock");
            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                int wb=w.optInt(k,0), sb=stock.optInt(k,0);
                if(used[i]>wb) { result("رصيد العامل غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+wb+"، ولم يتم الخصم.",false); return; }
                if(used[i]>sb) { result("المخزون العام غير كافٍ في فئة "+k+"؛ المطلوب "+used[i]+" والمتوفر "+sb+"، ولم يتم الخصم.",false); return; }
            }
            JSONObject oldWorker = new JSONObject(w.toString());
            JSONObject oldStock = new JSONObject(stock.toString());
            for(int i=0;i<4;i++) {
                String k=String.valueOf(DENOMS[i]);
                w.put(k,w.optInt(k,0)-used[i]);
                stock.put(k,stock.optInt(k,0)-used[i]);
            }
            saveData();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString("last_undo_worker", name)
                    .putString("last_undo_worker_json", oldWorker.toString())
                    .putString("last_undo_stock_json", oldStock.toString())
                    .putBoolean("last_undo_available", true).apply();
            renderWorkers();
            checkAndNotifyStock("مخزون العامل " + name, w);
            checkAndNotifyStock("المخزون العام", stock);
            StringBuilder out=new StringBuilder("تم الخصم بنجاح<br><br><b>الكروت المستخدمة:</b><br><br>");
            out.append(verticalUsed).append("عدد المجموعات: ").append(count).append("<br><br><b>الإجمالي:</b><br>");
            for(int i=0;i<4;i++) out.append(DENOMS[i]).append(" : ").append(used[i]).append("<br>");
            result(out.toString(),true);
            sendWorkerReport(name, "عملية خصم وتوزيع", "تم الخصم بنجاح\n" + out.toString().replace("<br>", "\n").replace("<b>", "").replace("</b>", ""));
        } catch(Exception e) { result("حدث خطأ أثناء الخصم؛ لم تكتمل العملية.",false); }
    }

    private String buildWorkerBalanceText(JSONObject worker) {
        StringBuilder b = new StringBuilder("الرصيد الحالي بعد العملية:\n");
        for (int denom : DENOMS) b.append("فئة ").append(denom).append(": ").append(worker.optInt(String.valueOf(denom),0)).append(" كرت\n");
        return b.toString();
    }

    private void sendWorkerReport(String workerName, String operation, String body) {
        try {
            String phone = data.getJSONObject("workers").getJSONObject(workerName).optString("phone", "").replaceAll("[^0-9+]", "").trim();
            if (phone.isEmpty()) { result("تم حفظ العملية، لكن لم يُرسل التقرير لأن رقم هاتف العامل غير مسجل.", false); return; }
            File dir = new File(getCacheDir(), "reports");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("reports directory");
            File file = new File(dir, "worker_report_" + System.currentTimeMillis() + ".pdf");
            PdfDocument pdf = new PdfDocument();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG); paint.setTextSize(16); paint.setColor(0xFF222222); paint.setTextAlign(Paint.Align.RIGHT);
            String[] lines = ("مخزون كروت الكامل برو v24\nالعامل: " + workerName + "\nالعملية: " + operation + "\nالتاريخ: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(new java.util.Date()) + "\n\n" + body).split("\n");
            int pageNo = 1; int y = 55;
            PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());
            android.graphics.Canvas canvas = page.getCanvas();
            for (String line : lines) {
                if (y > 790) { pdf.finishPage(page); pageNo++; page = pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); canvas = page.getCanvas(); y = 55; }
                canvas.drawText(line.length() > 68 ? line.substring(0,68) : line, 560, y, paint); y += 28;
            }
            pdf.finishPage(page);
            try (FileOutputStream out = new FileOutputStream(file)) { pdf.writeTo(out); }
            pdf.close();
            Uri uri = FileProvider.getUriForFile(this, "com.alkamel.workercards.pro24.fileprovider", file);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf"); share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, "تقرير " + operation + " للعامل " + workerName);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { share.setPackage("com.whatsapp"); startActivity(share); }
            catch (Exception noWhatsApp) { share.setPackage(null); startActivity(Intent.createChooser(share, "إرسال تقرير العامل")); }
        } catch (Exception ex) {
            result("تم حفظ العملية، لكن تعذر تجهيز تقرير PDF أو فتح واتساب. تحقق من رقم العامل والتطبيق.", false);
        }
    }

    private void undoLastOperation() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("last_undo_available", false)) {
            result("لا توجد عملية قابلة للتراجع.", false); return;
        }
        new AlertDialog.Builder(this).setTitle("التراجع عن آخر عملية")
                .setMessage("سيتم استعادة رصيد العامل والمخزون العام كما كانا قبل آخر عملية إضافة أو خصم. لا يمكن التراجع عنها مرة ثانية. هل تريد المتابعة؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("تراجع", (d, which) -> {
                    try {
                        String n = p.getString("last_undo_worker", "");
                        JSONObject oldW = new JSONObject(p.getString("last_undo_worker_json", "{}"));
                        JSONObject oldS = new JSONObject(p.getString("last_undo_stock_json", "{}"));
                        JSONObject workers = data.getJSONObject("workers");
                        if (!workers.has(n)) throw new Exception("worker missing");
                        workers.put(n, oldW); data.put("stock", oldS);
                        saveData();
                        p.edit().putBoolean("last_undo_available", false)
                                .remove("last_undo_worker_json").remove("last_undo_stock_json").apply();
                        renderWorkers(); checkAndNotifyStock("مخزون العامل " + n, oldW); checkAndNotifyStock("المخزون العام", oldS);
                        result("تم التراجع عن آخر عملية واستعادة الأرصدة.", true);
                    } catch(Exception ex) { result("تعذر التراجع؛ لم يتم تغيير البيانات.", false); }
                }).show();
    }

    private void result(String text, boolean ok) {
        if(resultText==null)return;
        resultText.setText(android.text.Html.fromHtml(text));
        resultText.setTextColor(ok?0xFF16833A:0xFFC62828);
    }

    private void checkAndNotifyStock(String categoryPrefix, JSONObject stock) {
        try {
            SharedPreferences alertPrefs = getSharedPreferences(StockSettings.PREFS, MODE_PRIVATE);
            for (int denom : DENOMS) {
                String key = String.valueOf(denom);
                int threshold;
                if (categoryPrefix.startsWith("مخزون العامل ")) {
                    threshold = stock.optInt("threshold_" + denom,
                            alertPrefs.getInt("threshold_" + denom, alertPrefs.getInt(StockSettings.DEFAULT_THRESHOLD, 10)));
                } else {
                    threshold = alertPrefs.getInt("threshold_" + denom, alertPrefs.getInt(StockSettings.DEFAULT_THRESHOLD, 10));
                }
                int remaining = stock.optInt(key, 0);
                Intent alert = new Intent(this, StockAlertReceiver.class);
                alert.setAction(StockAlertReceiver.ACTION);
                alert.putExtra(StockAlertReceiver.EXTRA_CATEGORY, categoryPrefix + " - فئة " + denom);
                alert.putExtra(StockAlertReceiver.EXTRA_REMAINING, remaining);
                alert.putExtra(StockAlertReceiver.EXTRA_THRESHOLD, threshold);
                sendBroadcast(alert);
            }
        } catch (Exception ignored) {}
    }

    private void exportBackup() {
        try {
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"نسخة_احتياطية_كروت_العامل.json");
            startActivityForResult(i,CREATE_BACKUP);
        } catch(Exception e){ result("تعذر فتح حفظ النسخة.",false); }
    }

    private void restoreBackup() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/json");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,RESTORE_BACKUP);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent intent) {
        super.onActivityResult(requestCode,resultCode,intent);
        if(resultCode!=RESULT_OK || intent==null || intent.getData()==null)return;
        Uri uri=intent.getData();
        try {
            if(requestCode==CREATE_BACKUP) {
                OutputStream out=getContentResolver().openOutputStream(uri);
                out.write(data.toString(2).getBytes(StandardCharsets.UTF_8)); out.close();
                result("تم تصدير النسخة الاحتياطية بنجاح.",true);
            } else if(requestCode==RESTORE_BACKUP) {
                InputStream in=getContentResolver().openInputStream(uri);
                ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] buf=new byte[4096]; int n;
                while((n=in.read(buf))!=-1)b.write(buf,0,n);
                in.close();
                JSONObject restored=new JSONObject(new String(b.toByteArray(),StandardCharsets.UTF_8));
                if(restored.optJSONObject("stock")==null || restored.optJSONObject("workers")==null)
                    throw new Exception("invalid");
                data=restored; selectedWorker="";
                saveData(); buildUi();
                result("تمت استعادة البيانات بنجاح.",true);
            }
        } catch(Exception e) { result("ملف النسخة الاحتياطية غير صالح أو تعذر قراءته.",false); }
    }
}
